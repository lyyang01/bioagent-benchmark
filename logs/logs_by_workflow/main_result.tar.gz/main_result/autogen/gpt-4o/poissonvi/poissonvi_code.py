
import os

# Define the data path
data_path = '/mnt/data00/share_data/agent_benchmark/poissonvi/atac_pbmc_5k.untar/filtered_peak_bc_matrix'

# List the contents of the directory
files = os.listdir(data_path)
print("Files in the directory:", files)


import scanpy as sc
import pandas as pd
from scipy.io import mmread
from scipy.sparse import csr_matrix

# Define the data path
data_path = '/mnt/data00/share_data/agent_benchmark/poissonvi/atac_pbmc_5k.untar/filtered_peak_bc_matrix'

# Load the matrix
matrix = mmread(f"{data_path}/matrix.mtx").T  # Transpose to match the AnnData format
matrix = csr_matrix(matrix)

# Load barcodes
barcodes = pd.read_csv(f"{data_path}/barcodes.tsv", header=None, sep='\t')
barcodes.columns = ['barcode']

# Load peaks
peaks = pd.read_csv(f"{data_path}/peaks.bed", header=None, sep='\t')
peaks['peak'] = peaks.apply(lambda row: f"{row[0]}:{row[1]}-{row[2]}", axis=1)

# Create AnnData object
adata = sc.AnnData(X=matrix, obs=barcodes, var=pd.DataFrame(index=peaks['peak']))

# Check the loaded data
print(adata)


import scanpy as sc

# Filter out cells with very few counts
sc.pp.filter_cells(adata, min_counts=1000)  # Assumption: cells with fewer than 1000 counts are low quality

# Filter out peaks with very few counts
sc.pp.filter_genes(adata, min_counts=10)  # Assumption: peaks with fewer than 10 counts are not informative

# Normalize the data
sc.pp.normalize_total(adata, target_sum=1e4)  # Normalize counts per cell to a total of 10,000

# Log-transform the data
sc.pp.log1p(adata)  # Log-transform to stabilize variance

# Check the preprocessed data
print(adata)
