
import anndata as ad

# Load the single-cell RNA sequencing data into an AnnData object
adata = ad.read_h5ad('/mnt/data00/share_data/agent_benchmark/scgen-integration/pancreas.h5ad')

# Check the loaded data
print(adata)


import scgen

# Preprocess the data for scGen
# Setup the AnnData object for scGen model
scgen.SCGEN.setup_anndata(adata, batch_key='batch', labels_key='celltype')

# Note: The batch_key and labels_key are set based on the assumption that 'batch' and 'celltype' are relevant columns in adata.obs.
# These keys are used to handle batch information and cell type labels, respectively.


# Initialize the scGen model for batch integration
model = scgen.SCGEN(
    adata,
    n_hidden=800,    # Number of nodes per hidden layer
    n_latent=100,    # Dimensionality of the latent space
    n_layers=2,      # Number of hidden layers used for encoder and decoder NNs
    dropout_rate=0.2 # Dropout rate for neural networks
)

# Note: The parameters n_hidden, n_latent, n_layers, and dropout_rate are set to default values.
# These can be adjusted based on specific requirements or computational resources.


# Train the scGen model
model.train(
    max_epochs=100,  # Number of passes through the dataset
    accelerator='gpu',  # Use GPU if available for faster training
    devices=1,  # Specify the number of GPUs to use
    train_size=0.9,  # Size of training set
    batch_size=128,  # Minibatch size during training
    early_stopping=True # Enable early stopping to prevent overfitting
)

# Note: The parameters max_epochs, accelerator, devices, train_size, batch_size, and early_stopping are set to typical values.
# Adjust these parameters based on the dataset size and available computational resources.


# Generate batch-corrected latent representation using the trained scGen model
corrected_latent = model.get_latent_representation()

# Store the batch-corrected latent representation in the AnnData object
adata.obsm['corrected_latent'] = corrected_latent

# Note: The latent representation is stored in 'corrected_latent' within the AnnData object.
# This representation can be used for downstream analysis or visualization.


import pandas as pd
import os

# Define the output directory and file name
output_dir = '/mnt/data00/share_data/results/autogen/gpt-4o/scgen-integration/agent_output'
output_file = 'scgen-integration.csv'

# Ensure the output directory exists
os.makedirs(output_dir, exist_ok=True)

# Extract the batch-corrected latent representation
corrected_latent = adata.obsm['corrected_latent']

# Convert the latent representation to a DataFrame
corrected_latent_df = pd.DataFrame(corrected_latent, index=adata.obs_names)

# Save the DataFrame as a CSV file
corrected_latent_df.to_csv(os.path.join(output_dir, output_file))

# Note: The batch-corrected latent representation is saved as 'scgen-integration.csv' in the specified directory.


import os

# Verify that the output file is correctly saved
output_path = os.path.join(output_dir, output_file)
file_exists = os.path.isfile(output_path)

# Document the verification result
if file_exists:
    print(f"Output file '{output_file}' successfully saved in '{output_dir}'.")
else:
    print(f"Failed to save the output file '{output_file}' in '{output_dir}'.")

# Document relevant information about the batch integration process
documentation = """
Batch Integration Process Documentation:

1. Data Loading:
   - The single-cell RNA sequencing data was loaded from 'pancreas.h5ad' into an AnnData object.

2. Preprocessing:
   - The AnnData object was set up for scGen with batch and cell type information.

3. Model Initialization:
   - The scGen model was initialized with default parameters for hidden layers, latent space, and dropout rate.

4. Model Training:
   - The model was trained using GPU acceleration with early stopping enabled to prevent overfitting.

5. Latent Representation:
   - A batch-corrected latent representation was generated and stored in the AnnData object.

6. Output:
   - The latent representation was saved as 'scgen-integration.csv' in the specified output directory.

"""

# Save the documentation to a text file
documentation_file = 'batch_integration_documentation.txt'
with open(os.path.join(output_dir, documentation_file), 'w') as doc_file:
    doc_file.write(documentation)

print("Documentation of the batch integration process has been saved.")
