
import scanpy as sc

# Load the scRNA-seq data into an AnnData object
scRNA_seq_data_path = '/mnt/data00/share_data/agent_benchmark/stereoscope/hca_heart_LV_stereoscope_subset_raw_ctl201217-2.h5ad'
sc_adata = sc.read_h5ad(scRNA_seq_data_path)

# Check the loaded data
print(sc_adata)


import scanpy as sc

# Load the spatial transcriptomics data using the Visium dataset 'V1_Human_Heart'
st_adata = sc.datasets.visium_sge("V1_Human_Heart")

# Check the loaded spatial data
print(st_adata)


import scanpy as sc
import numpy as np

# Preprocess scRNA-seq data
# Normalize the data
sc.pp.normalize_total(sc_adata, target_sum=1e4)
sc.pp.log1p(sc_adata)

# Handle NaN values by replacing them with zeros
sc_adata.X = np.nan_to_num(sc_adata.X)

# Identify highly variable genes
sc.pp.highly_variable_genes(sc_adata, min_mean=0.0125, max_mean=3, min_disp=0.5)
sc_adata = sc_adata[:, sc_adata.var.highly_variable]

# Scale the data
sc.pp.scale(sc_adata, max_value=10)

# Preprocess spatial data
# Normalize the spatial data
sc.pp.normalize_total(st_adata, target_sum=1e4)
sc.pp.log1p(st_adata)

# Make gene names unique in spatial data
st_adata.var_names_make_unique()

# Handle NaN values by replacing them with zeros
st_adata.X = np.nan_to_num(st_adata.X)

# Ensure the spatial data has the same genes as the scRNA-seq data
common_genes = sc_adata.var_names.intersection(st_adata.var_names)
st_adata = st_adata[:, common_genes]

# Scale the spatial data
sc.pp.scale(st_adata, max_value=10)

# Check the preprocessed data
print(f"scRNA-seq data shape: {sc_adata.shape}")
print(f"Spatial data shape: {st_adata.shape}")


import scvi
from scvi.external import RNAStereoscope, SpatialStereoscope

# Setup and train the RNA model
RNAStereoscope.setup_anndata(sc_adata)
rna_model = RNAStereoscope(sc_adata)
rna_model.train(max_epochs=400, lr=0.01, accelerator='gpu', devices='auto', batch_size=128)

# Setup and train the Spatial model using the trained RNA model
SpatialStereoscope.setup_anndata(st_adata)
spatial_model = SpatialStereoscope.from_rna_model(st_adata, rna_model)
spatial_model.train(max_epochs=400, lr=0.01, accelerator='gpu', devices='auto', batch_size=128)

# Get the estimated cell type proportions
cell_type_proportions = spatial_model.get_proportions(keep_noise=False)

# Store the results in the spatial AnnData object
st_adata.obsm['deconvolution'] = cell_type_proportions

# Save the results to a CSV file
output_path = '/mnt/data00/share_data/results/autogen/gpt-4o/stereoscope/agent_output/stereoscope.csv'
cell_type_proportions.to_csv(output_path)

print("Deconvolution results saved successfully.")


import pandas as pd

# Load the saved deconvolution results
output_path = '/mnt/data00/share_data/results/autogen/gpt-4o/stereoscope/agent_output/stereoscope.csv'
deconvolution_results = pd.read_csv(output_path, index_col=0)

# Display the first few rows of the results to verify
print(deconvolution_results.head())

# Check the shape of the results to ensure it matches the expected dimensions
print(f"Deconvolution results shape: {deconvolution_results.shape}")
