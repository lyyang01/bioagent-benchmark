
import anndata
import pandas as pd

# Load the single-cell RNA-seq data
sce_data_path = '/mnt/data00/share_data/agent_benchmark/cellassign/sce_follicular.h5ad'
sce_data = anndata.read_h5ad(sce_data_path)

# Load the marker gene matrix
marker_gene_matrix_path = '/mnt/data00/share_data/agent_benchmark/cellassign/fl_celltype.csv'
marker_gene_matrix = pd.read_csv(marker_gene_matrix_path)

# Display the loaded data for verification
print(sce_data)
print(marker_gene_matrix.head())


# Convert observation and variable names to string to avoid categorical issues
sce_data.obs.index = sce_data.obs.index.astype(str)
sce_data.var.index = sce_data.var.index.astype(str)

# Ensure unique observation and variable names
sce_data.obs_names_make_unique()
sce_data.var_names_make_unique()

# Check the data after making names unique
print(sce_data)
