
import anndata
import pandas as pd

# Load the single-cell RNA-seq data
sce_data_path = '/mnt/data00/share_data/agent_benchmark/cellassign/sce_follicular.h5ad'
sce_data = anndata.read_h5ad(sce_data_path)

# Load the marker gene matrix
marker_gene_matrix_path = '/mnt/data00/share_data/agent_benchmark/cellassign/fl_celltype.csv'
marker_gene_matrix = pd.read_csv(marker_gene_matrix_path)

# Display the loaded data for verification
print(sce_data)
print(marker_gene_matrix.head())


# Ensure unique observation and variable names
sce_data.obs_names_make_unique()
sce_data.var_names_make_unique()

# Check the data after making names unique
print(sce_data)


# Convert observation names to string to avoid categorical issues
sce_data.obs.index = sce_data.obs.index.astype(str)

# Ensure unique observation and variable names
sce_data.obs_names_make_unique()
sce_data.var_names_make_unique()

# Check the data after making names unique
print(sce_data)


# Convert observation and variable names to string to avoid categorical issues
sce_data.obs.index = sce_data.obs.index.astype(str)
sce_data.var.index = sce_data.var.index.astype(str)

# Ensure unique observation and variable names
sce_data.obs_names_make_unique()
sce_data.var_names_make_unique()

# Check the data after making names unique
print(sce_data)


from scvi.external import CellAssign

# Step 1: Setup the AnnData object
# Assuming 'size_factor' is a column in obs that contains size factors
CellAssign.setup_anndata(sce_data, size_factor_key='size_factor')

# Step 2: Initialize the CellAssign model
# The marker gene matrix should have genes as index and cell types as columns
cellassign_model = CellAssign(sce_data, cell_type_markers=marker_gene_matrix)

# Step 3: Train the model
cellassign_model.train(
    max_epochs=400,  # Number of epochs
    lr=0.003,        # Learning rate
    accelerator='auto',  # Use GPU if available
    devices='auto',  # Automatically select devices
    batch_size=1024, # Batch size
    early_stopping=True,  # Enable early stopping
    early_stopping_patience=15  # Patience for early stopping
)

# Step 4: Predict cell types
predictions = cellassign_model.predict()

# Store the predictions in the AnnData object
sce_data.obs['cellassign_predictions'] = predictions

# Save the results to a CSV file
output_path = '/mnt/data00/share_data/results/autogen/gpt-4o/cellassign/agent_output/cellassign.csv'
sce_data.obs['cellassign_predictions'].to_csv(output_path)


# Ensure the marker gene matrix has genes as index
marker_gene_matrix.set_index('Gene', inplace=True)

# Subset the AnnData object to include only the genes present in the marker gene matrix
common_genes = sce_data.var_names.intersection(marker_gene_matrix.index)
sce_data = sce_data[:, common_genes].copy()

# Re-initialize the CellAssign model with the subsetted data
cellassign_model = CellAssign(sce_data, cell_type_markers=marker_gene_matrix.loc[common_genes])

# Train the model
cellassign_model.train(
    max_epochs=400,  # Number of epochs
    lr=0.003,        # Learning rate
    accelerator='auto',  # Use GPU if available
    devices='auto',  # Automatically select devices
    batch_size=1024, # Batch size
    early_stopping=True,  # Enable early stopping
    early_stopping_patience=15  # Patience for early stopping
)

# Predict cell types
predictions = cellassign_model.predict()

# Store the predictions in the AnnData object
sce_data.obs['cellassign_predictions'] = predictions

# Save the results to a CSV file
output_path = '/mnt/data00/share_data/results/autogen/gpt-4o/cellassign/agent_output/cellassign.csv'
sce_data.obs['cellassign_predictions'].to_csv(output_path)


from scvi.external import CellAssign

# Ensure the marker gene matrix has genes as index
marker_gene_matrix.set_index('Gene', inplace=True)

# Subset the AnnData object to include only the genes present in the marker gene matrix
common_genes = sce_data.var_names.intersection(marker_gene_matrix.index)
sce_data = sce_data[:, common_genes]

# Step 1: Setup the AnnData object
# Assuming 'size_factor' is a column in obs that contains size factors
CellAssign.setup_anndata(sce_data, size_factor_key='size_factor')

# Step 2: Initialize the CellAssign model
cellassign_model = CellAssign(sce_data, cell_type_markers=marker_gene_matrix.loc[common_genes])

# Step 3: Train the model
cellassign_model.train(
    max_epochs=400,  # Number of epochs
    lr=0.003,        # Learning rate
    accelerator='auto',  # Use GPU if available
    devices='auto',  # Automatically select devices
    batch_size=1024, # Batch size
    early_stopping=True,  # Enable early stopping
    early_stopping_patience=15  # Patience for early stopping
)

# Step 4: Predict cell types
predictions = cellassign_model.predict()

# Store the predictions in the AnnData object
sce_data.obs['cellassign_predictions'] = predictions

# Save the results to a CSV file
output_path = '/mnt/data00/share_data/results/autogen/gpt-4o/cellassign/agent_output/cellassign.csv'
sce_data.obs['cellassign_predictions'].to_csv(output_path)


# Check the structure of the marker gene matrix
print(marker_gene_matrix.head())

# If genes are already the index, we don't need to set them again
# Otherwise, adjust the column name used for setting the index
if 'Gene' in marker_gene_matrix.columns:
    marker_gene_matrix.set_index('Gene', inplace=True)
else:
    # Assuming the first column contains gene names if not explicitly labeled
    marker_gene_matrix.set_index(marker_gene_matrix.columns[0], inplace=True)

# Subset the AnnData object to include only the genes present in the marker gene matrix
common_genes = sce_data.var_names.intersection(marker_gene_matrix.index)
sce_data = sce_data[:, common_genes]

# Step 1: Setup the AnnData object
CellAssign.setup_anndata(sce_data, size_factor_key='size_factor')

# Step 2: Initialize the CellAssign model
cellassign_model = CellAssign(sce_data, cell_type_markers=marker_gene_matrix.loc[common_genes])

# Step 3: Train the model
cellassign_model.train(
    max_epochs=400,  # Number of epochs
    lr=0.003,        # Learning rate
    accelerator='auto',  # Use GPU if available
    devices='auto',  # Automatically select devices
    batch_size=1024, # Batch size
    early_stopping=True,  # Enable early stopping
    early_stopping_patience=15  # Patience for early stopping
)

# Step 4: Predict cell types
predictions = cellassign_model.predict()

# Store the predictions in the AnnData object
sce_data.obs['cellassign_predictions'] = predictions

# Save the results to a CSV file
output_path = '/mnt/data00/share_data/results/autogen/gpt-4o/cellassign/agent_output/cellassign.csv'
sce_data.obs['cellassign_predictions'].to_csv(output_path)


from scvi.external import CellAssign

# Ensure the marker gene matrix has genes as index
print(marker_gene_matrix.head())  # Check the structure of the marker gene matrix

# If genes are already the index, we don't need to set them again
# Otherwise, adjust the column name used for setting the index
if 'Gene' in marker_gene_matrix.columns:
    marker_gene_matrix.set_index('Gene', inplace=True)
else:
    # Assuming the first column contains gene names if not explicitly labeled
    marker_gene_matrix.set_index(marker_gene_matrix.columns[0], inplace=True)

# Subset the AnnData object to include only the genes present in the marker gene matrix
common_genes = sce_data.var_names.intersection(marker_gene_matrix.index)
sce_data = sce_data[:, common_genes].copy()  # Make a copy to avoid view issues

# Step 1: Setup the AnnData object
CellAssign.setup_anndata(sce_data, size_factor_key='size_factor')

# Step 2: Initialize the CellAssign model
cellassign_model = CellAssign(sce_data, cell_type_markers=marker_gene_matrix.loc[common_genes])

# Step 3: Train the model
cellassign_model.train(
    max_epochs=400,  # Number of epochs
    lr=0.003,        # Learning rate
    accelerator='auto',  # Use GPU if available
    devices='auto',  # Automatically select devices
    batch_size=1024, # Batch size
    early_stopping=True,  # Enable early stopping
    early_stopping_patience=15  # Patience for early stopping
)

# Step 4: Predict cell types
predictions = cellassign_model.predict()

# Store the predictions in the AnnData object
sce_data.obs['cellassign_predictions'] = predictions

# Save the results to a CSV file
output_path = '/mnt/data00/share_data/results/autogen/gpt-4o/cellassign/agent_output/cellassign.csv'
sce_data.obs['cellassign_predictions'].to_csv(output_path)


from scvi.external import CellAssign

# Check the structure of the marker gene matrix
print(marker_gene_matrix.head())

# If genes are already the index, we don't need to set them again
# Otherwise, adjust the column name used for setting the index
if 'Gene' in marker_gene_matrix.columns:
    marker_gene_matrix.set_index('Gene', inplace=True)
else:
    # Assuming the first column contains gene names if not explicitly labeled
    marker_gene_matrix.set_index(marker_gene_matrix.columns[0], inplace=True)

# Subset the AnnData object to include only the genes present in the marker gene matrix
common_genes = sce_data.var_names.intersection(marker_gene_matrix.index)

# Check if there are common genes
if len(common_genes) == 0:
    raise ValueError("No common genes found between the AnnData object and the marker gene matrix.")

sce_data = sce_data[:, common_genes].copy()  # Make a copy to avoid view issues

# Step 1: Setup the AnnData object
CellAssign.setup_anndata(sce_data, size_factor_key='size_factor')

# Step 2: Initialize the CellAssign model
cellassign_model = CellAssign(sce_data, cell_type_markers=marker_gene_matrix.loc[common_genes])

# Step 3: Train the model
cellassign_model.train(
    max_epochs=400,  # Number of epochs
    lr=0.003,        # Learning rate
    accelerator='auto',  # Use GPU if available
    devices='auto',  # Automatically select devices
    batch_size=1024, # Batch size
    early_stopping=True,  # Enable early stopping
    early_stopping_patience=15  # Patience for early stopping
)

# Step 4: Predict cell types
predictions = cellassign_model.predict()

# Store the predictions in the AnnData object
sce_data.obs['cellassign_predictions'] = predictions

# Save the results to a CSV file
output_path = '/mnt/data00/share_data/results/autogen/gpt-4o/cellassign/agent_output/cellassign.csv'
sce_data.obs['cellassign_predictions'].to_csv(output_path)


# Convert gene names to uppercase in both datasets to ensure consistency
sce_data.var_names = sce_data.var_names.str.upper()
marker_gene_matrix.index = marker_gene_matrix.index.str.upper()

# Check the structure of the marker gene matrix
print(marker_gene_matrix.head())

# Subset the AnnData object to include only the genes present in the marker gene matrix
common_genes = sce_data.var_names.intersection(marker_gene_matrix.index)

# Check if there are common genes
if len(common_genes) == 0:
    raise ValueError("No common genes found between the AnnData object and the marker gene matrix after normalization.")

sce_data = sce_data[:, common_genes].copy()  # Make a copy to avoid view issues

# Step 1: Setup the AnnData object
CellAssign.setup_anndata(sce_data, size_factor_key='size_factor')

# Step 2: Initialize the CellAssign model
cellassign_model = CellAssign(sce_data, cell_type_markers=marker_gene_matrix.loc[common_genes])

# Step 3: Train the model
cellassign_model.train(
    max_epochs=400,  # Number of epochs
    lr=0.003,        # Learning rate
    accelerator='auto',  # Use GPU if available
    devices='auto',  # Automatically select devices
    batch_size=1024, # Batch size
    early_stopping=True,  # Enable early stopping
    early_stopping_patience=15  # Patience for early stopping
)

# Step 4: Predict cell types
predictions = cellassign_model.predict()

# Store the predictions in the AnnData object
sce_data.obs['cellassign_predictions'] = predictions

# Save the results to a CSV file
output_path = '/mnt/data00/share_data/results/autogen/gpt-4o/cellassign/agent_output/cellassign.csv'
sce_data.obs['cellassign_predictions'].to_csv(output_path)


# Convert gene names to strings and then to uppercase in both datasets to ensure consistency
sce_data.var_names = sce_data.var_names.astype(str).str.upper()
marker_gene_matrix.index = marker_gene_matrix.index.astype(str).str.upper()

# Check the structure of the marker gene matrix
print(marker_gene_matrix.head())

# Subset the AnnData object to include only the genes present in the marker gene matrix
common_genes = sce_data.var_names.intersection(marker_gene_matrix.index)

# Check if there are common genes
if len(common_genes) == 0:
    raise ValueError("No common genes found between the AnnData object and the marker gene matrix after normalization.")

sce_data = sce_data[:, common_genes].copy()  # Make a copy to avoid view issues

# Step 1: Setup the AnnData object
CellAssign.setup_anndata(sce_data, size_factor_key='size_factor')

# Step 2: Initialize the CellAssign model
cellassign_model = CellAssign(sce_data, cell_type_markers=marker_gene_matrix.loc[common_genes])

# Step 3: Train the model
cellassign_model.train(
    max_epochs=400,  # Number of epochs
    lr=0.003,        # Learning rate
    accelerator='auto',  # Use GPU if available
    devices='auto',  # Automatically select devices
    batch_size=1024, # Batch size
    early_stopping=True,  # Enable early stopping
    early_stopping_patience=15  # Patience for early stopping
)

# Step 4: Predict cell types
predictions = cellassign_model.predict()

# Store the predictions in the AnnData object
sce_data.obs['cellassign_predictions'] = predictions

# Save the results to a CSV file
output_path = '/mnt/data00/share_data/results/autogen/gpt-4o/cellassign/agent_output/cellassign.csv'
sce_data.obs['cellassign_predictions'].to_csv(output_path)


# Print a sample of gene names from the AnnData object
print("Sample of gene names in AnnData object:")
print(sce_data.var_names[:10])

# Print a sample of gene names from the marker gene matrix
print("Sample of gene names in marker gene matrix:")
print(marker_gene_matrix.index[:10])

# Check for common genes again
common_genes = sce_data.var_names.intersection(marker_gene_matrix.index)

# Check if there are common genes
if len(common_genes) == 0:
    raise ValueError("No common genes found between the AnnData object and the marker gene matrix after normalization.")

sce_data = sce_data[:, common_genes].copy()  # Make a copy to avoid view issues

# Step 1: Setup the AnnData object
CellAssign.setup_anndata(sce_data, size_factor_key='size_factor')

# Step 2: Initialize the CellAssign model
cellassign_model = CellAssign(sce_data, cell_type_markers=marker_gene_matrix.loc[common_genes])

# Step 3: Train the model
cellassign_model.train(
    max_epochs=400,  # Number of epochs
    lr=0.003,        # Learning rate
    accelerator='auto',  # Use GPU if available
    devices='auto',  # Automatically select devices
    batch_size=1024, # Batch size
    early_stopping=True,  # Enable early stopping
    early_stopping_patience=15  # Patience for early stopping
)

# Step 4: Predict cell types
predictions = cellassign_model.predict()

# Store the predictions in the AnnData object
sce_data.obs['cellassign_predictions'] = predictions

# Save the results to a CSV file
output_path = '/mnt/data00/share_data/results/autogen/gpt-4o/cellassign/agent_output/cellassign.csv'
sce_data.obs['cellassign_predictions'].to_csv(output_path)


# Print a sample of gene names from the AnnData object
print("Sample of gene names in AnnData object:")
print(sce_data.var_names[:10])

# Print a sample of gene names from the marker gene matrix
print("Sample of gene names in marker gene matrix:")
print(marker_gene_matrix.index[:10])

# Check for common genes again
common_genes = sce_data.var_names.intersection(marker_gene_matrix.index)

# Check if there are common genes
if len(common_genes) == 0:
    raise ValueError("No common genes found between the AnnData object and the marker gene matrix after normalization.")

sce_data = sce_data[:, common_genes].copy()  # Make a copy to avoid view issues

# Step 1: Setup the AnnData object
CellAssign.setup_anndata(sce_data, size_factor_key='size_factor')

# Step 2: Initialize the CellAssign model
cellassign_model = CellAssign(sce_data, cell_type_markers=marker_gene_matrix.loc[common_genes])

# Step 3: Train the model
cellassign_model.train(
    max_epochs=400,  # Number of epochs
    lr=0.003,        # Learning rate
    accelerator='auto',  # Use GPU if available
    devices='auto',  # Automatically select devices
    batch_size=1024, # Batch size
    early_stopping=True,  # Enable early stopping
    early_stopping_patience=15  # Patience for early stopping
)

# Step 4: Predict cell types
predictions = cellassign_model.predict()

# Store the predictions in the AnnData object
sce_data.obs['cellassign_predictions'] = predictions

# Save the results to a CSV file
output_path = '/mnt/data00/share_data/results/autogen/gpt-4o/cellassign/agent_output/cellassign.csv'
sce_data.obs['cellassign_predictions'].to_csv(output_path)
