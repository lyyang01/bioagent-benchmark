
import anndata as ad

# Load the scRNA-seq data
scRNA_data_path = '/mnt/data00/share_data/agent_benchmark/destvi/scRNA-LN-compressed.h5ad'
scRNA_adata = ad.read_h5ad(scRNA_data_path)

# Load the spatial transcriptomics data
spatial_data_path = '/mnt/data00/share_data/agent_benchmark/destvi/ST-LN-compressed.h5ad'
st_adata = ad.read_h5ad(spatial_data_path)

# Check the loaded data
print(scRNA_adata)
print(st_adata)


import scanpy as sc

# Preprocess scRNA-seq data
# Normalize the data and log-transform
sc.pp.normalize_total(scRNA_adata, target_sum=1e4)
sc.pp.log1p(scRNA_adata)

# Identify highly variable genes
sc.pp.highly_variable_genes(scRNA_adata, n_top_genes=2000, subset=True)

# Preprocess spatial data
# Normalize the data and log-transform
sc.pp.normalize_total(st_adata, target_sum=1e4)
sc.pp.log1p(st_adata)

# Align the data matrices in terms of features (genes)
# Ensure both datasets have the same set of genes
common_genes = scRNA_adata.var_names.intersection(st_adata.var_names)
scRNA_adata = scRNA_adata[:, common_genes]
st_adata = st_adata[:, common_genes]

# Check for missing values
# In this context, missing values are typically not present in AnnData objects, but it's good to verify
assert not scRNA_adata.isnull().any().any(), "Missing values found in scRNA-seq data"
assert not st_adata.isnull().any().any(), "Missing values found in spatial data"

# Verify the preprocessing steps
print(f"scRNA-seq data shape after preprocessing: {scRNA_adata.shape}")
print(f"Spatial data shape after preprocessing: {st_adata.shape}")


import numpy as np

# Preprocess scRNA-seq data
# Normalize the data and log-transform
sc.pp.normalize_total(scRNA_adata, target_sum=1e4)
sc.pp.log1p(scRNA_adata)

# Identify highly variable genes
sc.pp.highly_variable_genes(scRNA_adata, n_top_genes=2000, subset=True)

# Preprocess spatial data
# Normalize the data and log-transform
sc.pp.normalize_total(st_adata, target_sum=1e4)
sc.pp.log1p(st_adata)

# Align the data matrices in terms of features (genes)
# Ensure both datasets have the same set of genes
common_genes = scRNA_adata.var_names.intersection(st_adata.var_names)
scRNA_adata = scRNA_adata[:, common_genes]
st_adata = st_adata[:, common_genes]

# Check for missing values in the data matrices
assert not np.isnan(scRNA_adata.X).any(), "Missing values found in scRNA-seq data"
assert not np.isnan(st_adata.X).any(), "Missing values found in spatial data"

# Verify the preprocessing steps
print(f"scRNA-seq data shape after preprocessing: {scRNA_adata.shape}")
print(f"Spatial data shape after preprocessing: {st_adata.shape}")


import numpy as np
import scipy.sparse as sp

# Preprocess scRNA-seq data
# Normalize the data and log-transform
sc.pp.normalize_total(scRNA_adata, target_sum=1e4)
sc.pp.log1p(scRNA_adata)

# Identify highly variable genes
sc.pp.highly_variable_genes(scRNA_adata, n_top_genes=2000, subset=True)

# Preprocess spatial data
# Normalize the data and log-transform
sc.pp.normalize_total(st_adata, target_sum=1e4)
sc.pp.log1p(st_adata)

# Align the data matrices in terms of features (genes)
# Ensure both datasets have the same set of genes
common_genes = scRNA_adata.var_names.intersection(st_adata.var_names)
scRNA_adata = scRNA_adata[:, common_genes]
st_adata = st_adata[:, common_genes]

# Check for missing values in the data matrices
def check_missing_values(adata):
    if sp.issparse(adata.X):
        return not np.isnan(adata.X.data).any()
    else:
        return not np.isnan(adata.X).any()

assert check_missing_values(scRNA_adata), "Missing values found in scRNA-seq data"
assert check_missing_values(st_adata), "Missing values found in spatial data"

# Verify the preprocessing steps
print(f"scRNA-seq data shape after preprocessing: {scRNA_adata.shape}")
print(f"Spatial data shape after preprocessing: {st_adata.shape}")


import scvi
from scvi.model import CondSCVI, DestVI

# Setup data for CondSCVI
CondSCVI.setup_anndata(scRNA_adata, labels_key='cell_types', batch_key='batch')

# Initialize the CondSCVI model
cond_scvi_model = CondSCVI(scRNA_adata, n_hidden=128, n_latent=5, n_layers=2, dropout_rate=0.05)

# Train the CondSCVI model
cond_scvi_model.train(max_epochs=300, lr=0.001, accelerator='gpu', devices='auto', batch_size=128)

# Setup data for DestVI
DestVI.setup_anndata(st_adata)

# Initialize the DestVI model using the trained CondSCVI model
destvi_model = DestVI.from_rna_model(st_adata, cond_scvi_model, vamp_prior_p=15, l1_reg=0.0)

# The model is now initialized and ready for training


import scvi
from scvi.model import CondSCVI, DestVI

# Make a copy of the AnnData objects to avoid issues with views
scRNA_adata = scRNA_adata.copy()
st_adata = st_adata.copy()

# Setup data for CondSCVI
CondSCVI.setup_anndata(scRNA_adata, labels_key='cell_types', batch_key='batch')

# Initialize the CondSCVI model
cond_scvi_model = CondSCVI(scRNA_adata, n_hidden=128, n_latent=5, n_layers=2, dropout_rate=0.05)

# Train the CondSCVI model
cond_scvi_model.train(max_epochs=300, lr=0.001, accelerator='gpu', devices='auto', batch_size=128)

# Setup data for DestVI
DestVI.setup_anndata(st_adata)

# Initialize the DestVI model using the trained CondSCVI model
destvi_model = DestVI.from_rna_model(st_adata, cond_scvi_model, vamp_prior_p=15, l1_reg=0.0)

# The model is now initialized and ready for training


import scvi
from scvi.model import CondSCVI, DestVI

# Make a copy of the AnnData objects to avoid issues with views
scRNA_adata = scRNA_adata.copy()
st_adata = st_adata.copy()

# Ensure the cell type labels are consistent
# This step assumes 'cell_types' is a categorical column in scRNA_adata.obs
scRNA_adata.obs['cell_types'] = scRNA_adata.obs['cell_types'].astype('category')

# Setup data for CondSCVI
CondSCVI.setup_anndata(scRNA_adata, labels_key='cell_types', batch_key='batch')

# Initialize the CondSCVI model
cond_scvi_model = CondSCVI(scRNA_adata, n_hidden=128, n_latent=5, n_layers=2, dropout_rate=0.05)

# Train the CondSCVI model
cond_scvi_model.train(max_epochs=300, lr=0.001, accelerator='gpu', devices='auto', batch_size=128)

# Setup data for DestVI
DestVI.setup_anndata(st_adata)

# Initialize the DestVI model using the trained CondSCVI model
# Ensure the number of cell types matches between the datasets
destvi_model = DestVI.from_rna_model(st_adata, cond_scvi_model, vamp_prior_p=15, l1_reg=0.0)

# The model is now initialized and ready for training


import scvi
from scvi.model import CondSCVI, DestVI

# Make a copy of the AnnData objects to avoid issues with views
scRNA_adata = scRNA_adata.copy()
st_adata = st_adata.copy()

# Ensure the cell type labels are consistent
# This step assumes 'cell_types' is a categorical column in scRNA_adata.obs
scRNA_adata.obs['cell_types'] = scRNA_adata.obs['cell_types'].astype('category')

# Setup data for CondSCVI
CondSCVI.setup_anndata(scRNA_adata, labels_key='cell_types', batch_key='batch')

# Initialize the CondSCVI model
cond_scvi_model = CondSCVI(scRNA_adata, n_hidden=128, n_latent=5, n_layers=2, dropout_rate=0.05)

# Train the CondSCVI model
cond_scvi_model.train(max_epochs=300, lr=0.001, accelerator='gpu', devices='auto', batch_size=128)

# Setup data for DestVI
DestVI.setup_anndata(st_adata)

# Initialize the DestVI model using the trained CondSCVI model
# Ensure the number of cell types matches between the datasets
destvi_model = DestVI.from_rna_model(st_adata, cond_scvi_model, vamp_prior_p=15, l1_reg=0.0)

# The model is now initialized and ready for training
