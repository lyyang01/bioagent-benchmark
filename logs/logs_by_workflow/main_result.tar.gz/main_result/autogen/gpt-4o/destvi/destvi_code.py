
import anndata as ad

# Load the scRNA-seq data
scRNA_data_path = '/mnt/data00/share_data/agent_benchmark/destvi/scRNA-LN-compressed.h5ad'
scRNA_adata = ad.read_h5ad(scRNA_data_path)

# Load the spatial transcriptomics data
spatial_data_path = '/mnt/data00/share_data/agent_benchmark/destvi/ST-LN-compressed.h5ad'
st_adata = ad.read_h5ad(spatial_data_path)

# Check the loaded data
print(scRNA_adata)
print(st_adata)


import numpy as np
import scipy.sparse as sp

# Preprocess scRNA-seq data
# Normalize the data and log-transform
sc.pp.normalize_total(scRNA_adata, target_sum=1e4)
sc.pp.log1p(scRNA_adata)

# Identify highly variable genes
sc.pp.highly_variable_genes(scRNA_adata, n_top_genes=2000, subset=True)

# Preprocess spatial data
# Normalize the data and log-transform
sc.pp.normalize_total(st_adata, target_sum=1e4)
sc.pp.log1p(st_adata)

# Align the data matrices in terms of features (genes)
# Ensure both datasets have the same set of genes
common_genes = scRNA_adata.var_names.intersection(st_adata.var_names)
scRNA_adata = scRNA_adata[:, common_genes]
st_adata = st_adata[:, common_genes]

# Check for missing values in the data matrices
def check_missing_values(adata):
    if sp.issparse(adata.X):
        return not np.isnan(adata.X.data).any()
    else:
        return not np.isnan(adata.X).any()

assert check_missing_values(scRNA_adata), "Missing values found in scRNA-seq data"
assert check_missing_values(st_adata), "Missing values found in spatial data"

# Verify the preprocessing steps
print(f"scRNA-seq data shape after preprocessing: {scRNA_adata.shape}")
print(f"Spatial data shape after preprocessing: {st_adata.shape}")
