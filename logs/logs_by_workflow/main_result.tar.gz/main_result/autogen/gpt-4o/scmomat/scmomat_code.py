
# Load the feature name files for RNA and ATAC

# Import necessary libraries
import numpy as np

# Define file paths
rna_feature_file = '/mnt/data00/share_data/agent_benchmark/scmomat/MOp_5batches/genes.txt'
atac_feature_file = '/mnt/data00/share_data/agent_benchmark/scmomat/MOp_5batches/regions.txt'

# Load RNA feature names
with open(rna_feature_file, 'r') as file:
    rna_features = file.read().splitlines()

# Load ATAC feature names
with open(atac_feature_file, 'r') as file:
    atac_features = file.read().splitlines()

# Print the number of features loaded for verification
print(f"Number of RNA features loaded: {len(rna_features)}")
print(f"Number of ATAC features loaded: {len(atac_features)}")


# Load the scATAC-seq data for batches 1, 3, and 5

# Define file paths for scATAC-seq data
atac_batch1_file = '/mnt/data00/share_data/agent_benchmark/scmomat/MOp_5batches/RxC1.npz'
atac_batch3_file = '/mnt/data00/share_data/agent_benchmark/scmomat/MOp_5batches/RxC3.npz'
atac_batch5_file = '/mnt/data00/share_data/agent_benchmark/scmomat/MOp_5batches/RxC5.npz'

# Load scATAC-seq data for each batch and inspect keys
atac_batch1_data = np.load(atac_batch1_file)
atac_batch3_data = np.load(atac_batch3_file)
atac_batch5_data = np.load(atac_batch5_file)

# Print the keys of the loaded data for verification
print(f"Keys in scATAC-seq data for batch 1: {list(atac_batch1_data.keys())}")
print(f"Keys in scATAC-seq data for batch 3: {list(atac_batch3_data.keys())}")
print(f"Keys in scATAC-seq data for batch 5: {list(atac_batch5_data.keys())}")


# Load the scRNA-seq data for batches 1, 2, and 4

# Define file paths for scRNA-seq data
rna_batch1_file = '/mnt/data00/share_data/agent_benchmark/scmomat/MOp_5batches/GxC1.npz'
rna_batch2_file = '/mnt/data00/share_data/agent_benchmark/scmomat/MOp_5batches/GxC2.npz'
rna_batch4_file = '/mnt/data00/share_data/agent_benchmark/scmomat/MOp_5batches/GxC4.npz'

# Load scRNA-seq data for each batch and inspect keys
rna_batch1_data = np.load(rna_batch1_file)
rna_batch2_data = np.load(rna_batch2_file)
rna_batch4_data = np.load(rna_batch4_file)

# Print the keys of the loaded data for verification
print(f"Keys in scRNA-seq data for batch 1: {list(rna_batch1_data.keys())}")
print(f"Keys in scRNA-seq data for batch 2: {list(rna_batch2_data.keys())}")
print(f"Keys in scRNA-seq data for batch 4: {list(rna_batch4_data.keys())}")


# Load the region association matrix

# Define file path for region association matrix
region_association_file = '/mnt/data00/share_data/agent_benchmark/scmomat/MOp_5batches/GxR.npz'

# Load region association matrix and inspect keys
region_association_data = np.load(region_association_file)

# Print the keys of the loaded data for verification
print(f"Keys in region association matrix: {list(region_association_data.keys())}")
