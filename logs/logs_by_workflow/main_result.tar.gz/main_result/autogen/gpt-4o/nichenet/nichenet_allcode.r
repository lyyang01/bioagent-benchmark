
# Load necessary libraries
library(Seurat)

# Load the Seurat object from the specified file path
seurat_obj_path <- '/mnt/data00/share_data/agent_benchmark/nichenet/seuratObj.rds'
seurat_obj <- readRDS(seurat_obj_path)

# Check the Seurat object to ensure it contains the necessary expression data
print(seurat_obj)


# Load necessary libraries for NicheNet
library(nichenetr)

# Load the ligand-target prior model
ligand_target_prior_model_path <- '/mnt/data00/share_data/agent_benchmark/nichenet/lr_network_mouse_21122021.rds'
ligand_target_prior_model <- readRDS(ligand_target_prior_model_path)

# Load the ligand-receptor network
ligand_receptor_network_path <- '/mnt/data00/share_data/agent_benchmark/nichenet/ligand_target_matrix_nsga2r_final_mouse.rds'
ligand_receptor_network <- readRDS(ligand_receptor_network_path)

# Load the weighted ligand-receptor network
weighted_ligand_receptor_network_path <- '/mnt/data00/share_data/agent_benchmark/nichenet/weighted_networks_nsga2r_final_mouse.rds'
weighted_ligand_receptor_network <- readRDS(weighted_ligand_receptor_network_path)

# Check the loaded models and networks
print(ligand_target_prior_model)
print(ligand_receptor_network)
print(weighted_ligand_receptor_network)


# Assuming the Seurat object contains metadata with cell type information
# We will identify sender and receiver cell populations based on this metadata

# View the metadata to understand the structure and available information
head(seurat_obj@meta.data)

# Define sender and receiver cell types
# For this example, let's assume we have cell types labeled as 'Sender' and 'Receiver' in the metadata
sender_cell_type <- "Sender"
receiver_cell_type <- "Receiver"

# Extract sender and receiver cells based on the defined cell types
sender_cells <- WhichCells(seurat_obj, ident = sender_cell_type)
receiver_cells <- WhichCells(seurat_obj, ident = receiver_cell_type)

# Extract expression data for sender and receiver cells
sender_expression <- GetAssayData(seurat_obj, assay = "RNA", slot = "data")[, sender_cells]
receiver_expression <- GetAssayData(seurat_obj, assay = "RNA", slot = "data")[, receiver_cells]

# Check the dimensions of the extracted expression matrices
print(dim(sender_expression))
print(dim(receiver_expression))

# Ensure the data is formatted correctly for NicheNet analysis
# This includes having the correct gene identifiers and expression values


# Inspect the metadata to identify available cell type labels
head(seurat_obj@meta.data)

# List unique identities in the Seurat object to find the correct labels
unique_identities <- unique(Idents(seurat_obj))
print(unique_identities)

# After identifying the correct labels, update the sender and receiver cell types
# For example, if the correct labels are "CellTypeA" and "CellTypeB", update as follows:
# sender_cell_type <- "CellTypeA"
# receiver_cell_type <- "CellTypeB"

# Extract sender and receiver cells based on the correct cell types
# sender_cells <- WhichCells(seurat_obj, ident = sender_cell_type)
# receiver_cells <- WhichCells(seurat_obj, ident = receiver_cell_type)

# Extract expression data for sender and receiver cells
# sender_expression <- GetAssayData(seurat_obj, assay = "RNA", slot = "data")[, sender_cells]
# receiver_expression <- GetAssayData(seurat_obj, assay = "RNA", slot = "data")[, receiver_cells]

# Check the dimensions of the extracted expression matrices
# print(dim(sender_expression))
# print(dim(receiver_expression))


# Load necessary libraries for NicheNet analysis
library(nichenetr)

# Define sender and receiver cell types based on the metadata inspection
sender_cell_type <- "CD8 T"
receiver_cell_type <- "CD4 T"

# Extract sender and receiver cells based on the correct cell types
sender_cells <- WhichCells(seurat_obj, ident = sender_cell_type)
receiver_cells <- WhichCells(seurat_obj, ident = receiver_cell_type)

# Extract expression data for sender and receiver cells
sender_expression <- GetAssayData(seurat_obj, assay = "RNA", slot = "data")[, sender_cells]
receiver_expression <- GetAssayData(seurat_obj, assay = "RNA", slot = "data")[, receiver_cells]

# Perform NicheNet analysis
# Predict ligand activities using the loaded models and networks
ligand_activities <- nichenet_ligand_activity(sender_expression, receiver_expression, 
                                              ligand_target_prior_model, 
                                              ligand_receptor_network, 
                                              weighted_ligand_receptor_network)

# Assign the ligand prediction ligand_activities table to a variable named saved_data
saved_data <- ligand_activities

# Save the saved_data variable as 'nichenet.RData' in the specified output directory
save_path <- '/mnt/data00/share_data/results/autogen/gpt-4o/nichenet/agent_output/nichenet.RData'
save(saved_data, file = save_path)

# Print the ligand activities to verify the results
print(saved_data)


# Load necessary libraries for NicheNet analysis
library(nichenetr)

# Define sender and receiver cell types based on the metadata inspection
sender_cell_type <- "CD8 T"
receiver_cell_type <- "CD4 T"

# Extract sender and receiver cells based on the correct cell types
sender_cells <- WhichCells(seurat_obj, ident = sender_cell_type)
receiver_cells <- WhichCells(seurat_obj, ident = receiver_cell_type)

# Extract expression data for sender and receiver cells
sender_expression <- GetAssayData(seurat_obj, assay = "RNA", slot = "data")[, sender_cells]
receiver_expression <- GetAssayData(seurat_obj, assay = "RNA", slot = "data")[, receiver_cells]

# Perform NicheNet analysis
# Use the correct function to predict ligand activities
ligand_activities <- nichenet_ligand_activities(sender_expression, receiver_expression, 
                                                ligand_target_prior_model, 
                                                ligand_receptor_network, 
                                                weighted_ligand_receptor_network)

# Assign the ligand prediction ligand_activities table to a variable named saved_data
saved_data <- ligand_activities

# Save the saved_data variable as 'nichenet.RData' in the specified output directory
save_path <- '/mnt/data00/share_data/results/autogen/gpt-4o/nichenet/agent_output/nichenet.RData'
save(saved_data, file = save_path)

# Print the ligand activities to verify the results
print(saved_data)


# Load necessary libraries for NicheNet analysis
library(nichenetr)

# Define sender and receiver cell types based on the metadata inspection
sender_cell_type <- "CD8 T"
receiver_cell_type <- "CD4 T"

# Extract sender and receiver cells based on the correct cell types
sender_cells <- WhichCells(seurat_obj, ident = sender_cell_type)
receiver_cells <- WhichCells(seurat_obj, ident = receiver_cell_type)

# Extract expression data for sender and receiver cells
sender_expression <- GetAssayData(seurat_obj, assay = "RNA", slot = "data")[, sender_cells]
receiver_expression <- GetAssayData(seurat_obj, assay = "RNA", slot = "data")[, receiver_cells]

# Perform NicheNet analysis
# Step 1: Define the genes of interest (e.g., differentially expressed genes in receiver cells)
genes_of_interest <- rownames(receiver_expression)

# Step 2: Calculate ligand activities
ligand_activities <- predict_ligand_activities(genes_of_interest = genes_of_interest,
                                               ligand_target_matrix = ligand_target_prior_model,
                                               potential_ligands = rownames(sender_expression),
                                               expression_receiver = receiver_expression,
                                               expression_sender = sender_expression)

# Assign the ligand prediction ligand_activities table to a variable named saved_data
saved_data <- ligand_activities

# Save the saved_data variable as 'nichenet.RData' in the specified output directory
save_path <- '/mnt/data00/share_data/results/autogen/gpt-4o/nichenet/agent_output/nichenet.RData'
save(saved_data, file = save_path)

# Print the ligand activities to verify the results
print(saved_data)


# Load necessary libraries for NicheNet analysis
library(nichenetr)

# Define sender and receiver cell types based on the metadata inspection
sender_cell_type <- "CD8 T"
receiver_cell_type <- "CD4 T"

# Extract sender and receiver cells based on the correct cell types
sender_cells <- WhichCells(seurat_obj, ident = sender_cell_type)
receiver_cells <- WhichCells(seurat_obj, ident = receiver_cell_type)

# Extract expression data for sender and receiver cells
sender_expression <- GetAssayData(seurat_obj, assay = "RNA", slot = "data")[, sender_cells]
receiver_expression <- GetAssayData(seurat_obj, assay = "RNA", slot = "data")[, receiver_cells]

# Perform NicheNet analysis
# Step 1: Define the geneset (e.g., differentially expressed genes in receiver cells)
# For demonstration, let's assume all genes in the receiver expression are of interest
geneset <- rownames(receiver_expression)

# Step 2: Calculate ligand activities
ligand_activities <- predict_ligand_activities(geneset = geneset,
                                               ligand_target_matrix = ligand_target_prior_model,
                                               potential_ligands = rownames(sender_expression),
                                               expression_receiver = receiver_expression,
                                               expression_sender = sender_expression)

# Assign the ligand prediction ligand_activities table to a variable named saved_data
saved_data <- ligand_activities

# Save the saved_data variable as 'nichenet.RData' in the specified output directory
save_path <- '/mnt/data00/share_data/results/autogen/gpt-4o/nichenet/agent_output/nichenet.RData'
save(saved_data, file = save_path)

# Print the ligand activities to verify the results
print(saved_data)


# Load necessary libraries for NicheNet analysis
library(nichenetr)

# Define sender and receiver cell types based on the metadata inspection
sender_cell_type <- "CD8 T"
receiver_cell_type <- "CD4 T"

# Extract sender and receiver cells based on the correct cell types
sender_cells <- WhichCells(seurat_obj, ident = sender_cell_type)
receiver_cells <- WhichCells(seurat_obj, ident = receiver_cell_type)

# Extract expression data for sender and receiver cells
sender_expression <- GetAssayData(seurat_obj, assay = "RNA", slot = "data")[, sender_cells]
receiver_expression <- GetAssayData(seurat_obj, assay = "RNA", slot = "data")[, receiver_cells]

# Perform NicheNet analysis
# Step 1: Define the geneset (e.g., differentially expressed genes in receiver cells)
# For demonstration, let's assume all genes in the receiver expression are of interest
geneset <- rownames(receiver_expression)

# Step 2: Define background expressed genes
background_expressed_genes <- rownames(receiver_expression)

# Step 3: Calculate ligand activities
ligand_activities <- predict_ligand_activities(geneset = geneset,
                                               ligand_target_matrix = ligand_target_prior_model,
                                               potential_ligands = rownames(sender_expression),
                                               expression_receiver = receiver_expression,
                                               expression_sender = sender_expression,
                                               background_expressed_genes = background_expressed_genes)

# Assign the ligand prediction ligand_activities table to a variable named saved_data
saved_data <- ligand_activities

# Save the saved_data variable as 'nichenet.RData' in the specified output directory
save_path <- '/mnt/data00/share_data/results/autogen/gpt-4o/nichenet/agent_output/nichenet.RData'
save(saved_data, file = save_path)

# Print the ligand activities to verify the results
print(saved_data)
