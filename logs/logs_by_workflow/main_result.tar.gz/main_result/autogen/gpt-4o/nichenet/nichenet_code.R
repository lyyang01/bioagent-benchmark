
# Load necessary libraries
library(Seurat)

# Load the Seurat object from the specified file path
seurat_obj_path <- '/mnt/data00/share_data/agent_benchmark/nichenet/seuratObj.rds'
seurat_obj <- readRDS(seurat_obj_path)

# Check the Seurat object to ensure it contains the necessary expression data
print(seurat_obj)


# Load necessary libraries for NicheNet
library(nichenetr)

# Load the ligand-target prior model
ligand_target_prior_model_path <- '/mnt/data00/share_data/agent_benchmark/nichenet/lr_network_mouse_21122021.rds'
ligand_target_prior_model <- readRDS(ligand_target_prior_model_path)

# Load the ligand-receptor network
ligand_receptor_network_path <- '/mnt/data00/share_data/agent_benchmark/nichenet/ligand_target_matrix_nsga2r_final_mouse.rds'
ligand_receptor_network <- readRDS(ligand_receptor_network_path)

# Load the weighted ligand-receptor network
weighted_ligand_receptor_network_path <- '/mnt/data00/share_data/agent_benchmark/nichenet/weighted_networks_nsga2r_final_mouse.rds'
weighted_ligand_receptor_network <- readRDS(weighted_ligand_receptor_network_path)

# Check the loaded models and networks
print(ligand_target_prior_model)
print(ligand_receptor_network)
print(weighted_ligand_receptor_network)


# Inspect the metadata to identify available cell type labels
head(seurat_obj@meta.data)

# List unique identities in the Seurat object to find the correct labels
unique_identities <- unique(Idents(seurat_obj))
print(unique_identities)

# After identifying the correct labels, update the sender and receiver cell types
# For example, if the correct labels are "CellTypeA" and "CellTypeB", update as follows:
# sender_cell_type <- "CellTypeA"
# receiver_cell_type <- "CellTypeB"

# Extract sender and receiver cells based on the correct cell types
# sender_cells <- WhichCells(seurat_obj, ident = sender_cell_type)
# receiver_cells <- WhichCells(seurat_obj, ident = receiver_cell_type)

# Extract expression data for sender and receiver cells
# sender_expression <- GetAssayData(seurat_obj, assay = "RNA", slot = "data")[, sender_cells]
# receiver_expression <- GetAssayData(seurat_obj, assay = "RNA", slot = "data")[, receiver_cells]

# Check the dimensions of the extracted expression matrices
# print(dim(sender_expression))
# print(dim(receiver_expression))
