
import anndata as ad

# Load the single-cell ATAC-seq dataset
adata = ad.read('/mnt/data00/share_data/agent_benchmark/mira/mira-datasets/e18_10X_brain_dataset/e18_mouse_brain_10x_dataset.ad')

# Display basic information about the dataset
print(adata)


import pandas as pd

# Load the barcodes file
barcodes_df = pd.read_csv('/mnt/data00/share_data/agent_benchmark/mira/mira-datasets/e18_10X_brain_dataset/e18_mouse_brain_10x_main_barcodes.csv')

# Display the first few rows of the barcodes DataFrame
print(barcodes_df.head())

# Integrate barcodes with the AnnData object
# Assuming the barcodes are in a column named 'barcode' and match the order of observations in adata
adata.obs['barcode'] = barcodes_df['barcode'].values

# Verify integration
print(adata.obs.head())


# Display the column names of the barcodes DataFrame
print(barcodes_df.columns)

# Assuming the correct column name is 'Barcode' (or another name found in the output)
# Replace 'Barcode' with the actual column name if different
adata.obs['barcode'] = barcodes_df['Barcode'].values

# Verify integration
print(adata.obs.head())


# Display the column names of the barcodes DataFrame
print(barcodes_df.columns)

# Once the correct column name is identified, replace 'CorrectColumnName' with the actual name
# For example, if the column name is 'CellBarcode', use that instead
# adata.obs['barcode'] = barcodes_df['CorrectColumnName'].values

# Verify integration
# print(adata.obs.head())


# Integrate barcodes with the AnnData object using the correct column name
adata.obs['barcode'] = barcodes_df['0'].values

# Verify integration
print(adata.obs.head())

# Preprocessing steps
# 1. Normalization: Scale the data to make it comparable across cells
# 2. Filtering: Remove low-quality cells or features

# Example normalization (log normalization)
adata.X = adata.X / adata.X.sum(axis=1, keepdims=True) * 1e4  # Normalize counts per cell
adata.X = np.log1p(adata.X)  # Log-transform the data

# Example filtering: Remove cells with low total counts
min_counts = 1000  # Minimum counts per cell
adata = adata[adata.X.sum(axis=1) >= min_counts]

# Verify preprocessing
print(f"Number of cells after filtering: {adata.n_obs}")


# Filter the AnnData object to include only cells with barcodes
# Assuming the barcodes in the DataFrame are unique identifiers for the cells
valid_barcodes = barcodes_df['0'].values
adata = adata[adata.obs_names.isin(valid_barcodes)]

# Integrate barcodes with the filtered AnnData object
adata.obs['barcode'] = valid_barcodes

# Verify integration
print(adata.obs.head())

# Preprocessing steps
# Normalization and filtering as before
adata.X = adata.X / adata.X.sum(axis=1, keepdims=True) * 1e4  # Normalize counts per cell
adata.X = np.log1p(adata.X)  # Log-transform the data

# Verify preprocessing
print(f"Number of cells after filtering: {adata.n_obs}")


import numpy as np
from scipy.sparse import csr_matrix

# Filter the AnnData object to include only cells with barcodes
valid_barcodes = barcodes_df['0'].values
adata = adata[adata.obs_names.isin(valid_barcodes)]

# Integrate barcodes with the filtered AnnData object
adata.obs['barcode'] = valid_barcodes

# Verify integration
print(adata.obs.head())

# Preprocessing steps
# Normalization for sparse matrix
if isinstance(adata.X, csr_matrix):
    adata.X = adata.X.multiply(1e4 / adata.X.sum(axis=1).A1[:, np.newaxis])
else:
    adata.X = adata.X / adata.X.sum(axis=1, keepdims=True) * 1e4

# Log-transform the data
adata.X = np.log1p(adata.X)

# Verify preprocessing
print(f"Number of cells after filtering: {adata.n_obs}")


import mira
import anndata as ad

# Assuming adata is your preprocessed AnnData object
# Configure the topic model
model = mira.topics.make_model(
    n_samples=adata.n_obs,
    n_features=adata.n_vars,
    feature_type='accessibility',  # Since we are working with ATAC-seq data
    counts_layer=None,  # Use the default layer if raw counts are in adata.X
    num_topics=16,  # Number of topics to learn from data
    use_cuda=True  # Use GPU acceleration if available
)

# Fit the model to the data
model.fit(adata)

# Extract topic contributions
topic_contributions = model.get_topic_contributions(adata)

# Convert topic contributions to a DataFrame
import pandas as pd
topic_contributions_df = pd.DataFrame(topic_contributions, index=adata.obs_names)

# Save the results
output_path = '/mnt/data00/share_data/results/autogen/gpt-4o/mira/agent_output/mira.csv'
topic_contributions_df.to_csv(output_path)

print(f"Topic contributions saved to {output_path}")


import mira
import anndata as ad
from scipy.sparse import csr_matrix

# Convert the matrix to CSR format if it's not already
if not isinstance(adata.X, csr_matrix):
    adata.X = adata.X.tocsr()

# Configure the topic model
model = mira.topics.make_model(
    n_samples=adata.n_obs,
    n_features=adata.n_vars,
    feature_type='accessibility',  # Since we are working with ATAC-seq data
    counts_layer=None,  # Use the default layer if raw counts are in adata.X
    num_topics=16,  # Number of topics to learn from data
    use_cuda=True  # Use GPU acceleration if available
)

# Fit the model to the data
model.fit(adata)

# Extract topic contributions
topic_contributions = model.get_topic_contributions(adata)

# Convert topic contributions to a DataFrame
import pandas as pd
topic_contributions_df = pd.DataFrame(topic_contributions, index=adata.obs_names)

# Save the results
output_path = '/mnt/data00/share_data/results/autogen/gpt-4o/mira/agent_output/mira.csv'
topic_contributions_df.to_csv(output_path)

print(f"Topic contributions saved to {output_path}")


import mira
import anndata as ad
from scipy.sparse import csr_matrix

# Ensure the data is in CSR format
if not isinstance(adata.X, csr_matrix):
    adata.X = adata.X.tocsr()

# Revert to raw counts if available in a specific layer
# Assuming raw counts are stored in a layer named 'raw_counts'
if 'raw_counts' in adata.layers:
    adata.X = adata.layers['raw_counts']

# Configure the topic model
model = mira.topics.make_model(
    n_samples=adata.n_obs,
    n_features=adata.n_vars,
    feature_type='accessibility',  # Since we are working with ATAC-seq data
    counts_layer=None,  # Use the default layer if raw counts are in adata.X
    num_topics=16,  # Number of topics to learn from data
    use_cuda=True  # Use GPU acceleration if available
)

# Fit the model to the data
model.fit(adata)

# Extract topic contributions
topic_contributions = model.get_topic_contributions(adata)

# Convert topic contributions to a DataFrame
import pandas as pd
topic_contributions_df = pd.DataFrame(topic_contributions, index=adata.obs_names)

# Save the results
output_path = '/mnt/data00/share_data/results/autogen/gpt-4o/mira/agent_output/mira.csv'
topic_contributions_df.to_csv(output_path)

print(f"Topic contributions saved to {output_path}")


import mira
import anndata as ad
from scipy.sparse import csr_matrix

# Check if raw counts are stored in a specific layer
# If not, we need to ensure that adata.X contains the raw counts
# This example assumes raw counts might be in a layer named 'raw_counts'
if 'raw_counts' in adata.layers:
    adata.X = adata.layers['raw_counts']
else:
    # If no raw counts layer is available, ensure adata.X is integer
    adata.X = adata.X.astype(int)

# Ensure the data is in CSR format
if not isinstance(adata.X, csr_matrix):
    adata.X = adata.X.tocsr()

# Configure the topic model
model = mira.topics.make_model(
    n_samples=adata.n_obs,
    n_features=adata.n_vars,
    feature_type='accessibility',  # Since we are working with ATAC-seq data
    counts_layer=None,  # Use the default layer if raw counts are in adata.X
    num_topics=16,  # Number of topics to learn from data
    use_cuda=True  # Use GPU acceleration if available
)

# Fit the model to the data
model.fit(adata)

# Extract topic contributions
topic_contributions = model.get_topic_contributions(adata)

# Convert topic contributions to a DataFrame
import pandas as pd
topic_contributions_df = pd.DataFrame(topic_contributions, index=adata.obs_names)

# Save the results
output_path = '/mnt/data00/share_data/results/autogen/gpt-4o/mira/agent_output/mira.csv'
topic_contributions_df.to_csv(output_path)

print(f"Topic contributions saved to {output_path}")


import mira
import anndata as ad
from scipy.sparse import csr_matrix

# Ensure the data is in CSR format and contains integer counts
if not isinstance(adata.X, csr_matrix):
    adata.X = adata.X.tocsr()

# Configure the topic model
model = mira.topics.make_model(
    n_samples=adata.n_obs,
    n_features=adata.n_vars,
    feature_type='accessibility',  # Since we are working with ATAC-seq data
    counts_layer=None,  # Use the default layer if raw counts are in adata.X
    num_topics=16,  # Number of topics to learn from data
    use_cuda=True  # Use GPU acceleration if available
)

# Fit the model to the data
model.fit(adata)

# Extract topic contributions using the correct method
topic_contributions = model.get_cell_topic_compositions(adata)

# Convert topic contributions to a DataFrame
import pandas as pd
topic_contributions_df = pd.DataFrame(topic_contributions, index=adata.obs_names)

# Save the results
output_path = '/mnt/data00/share_data/results/autogen/gpt-4o/mira/agent_output/mira.csv'
topic_contributions_df.to_csv(output_path)

print(f"Topic contributions saved to {output_path}")


import mira
import anndata as ad
from scipy.sparse import csr_matrix

# Ensure the data is in CSR format and contains integer counts
if not isinstance(adata.X, csr_matrix):
    adata.X = adata.X.tocsr()

# Configure the topic model
model = mira.topics.make_model(
    n_samples=adata.n_obs,
    n_features=adata.n_vars,
    feature_type='accessibility',  # Since we are working with ATAC-seq data
    counts_layer=None,  # Use the default layer if raw counts are in adata.X
    num_topics=16,  # Number of topics to learn from data
    use_cuda=True  # Use GPU acceleration if available
)

# Fit the model to the data
model.fit(adata)

# Extract topic contributions using the correct method
topic_contributions = model.get_cell_factors(adata)

# Convert topic contributions to a DataFrame
import pandas as pd
topic_contributions_df = pd.DataFrame(topic_contributions, index=adata.obs_names)

# Save the results
output_path = '/mnt/data00/share_data/results/autogen/gpt-4o/mira/agent_output/mira.csv'
topic_contributions_df.to_csv(output_path)

print(f"Topic contributions saved to {output_path}")


import mira
import anndata as ad
from scipy.sparse import csr_matrix

# Ensure the data is in CSR format and contains integer counts
if not isinstance(adata.X, csr_matrix):
    adata.X = adata.X.tocsr()

# Configure the topic model
model = mira.topics.make_model(
    n_samples=adata.n_obs,
    n_features=adata.n_vars,
    feature_type='accessibility',  # Since we are working with ATAC-seq data
    counts_layer=None,  # Use the default layer if raw counts are in adata.X
    num_topics=16,  # Number of topics to learn from data
    use_cuda=True  # Use GPU acceleration if available
)

# Fit the model to the data
model.fit(adata)

# Extract topic contributions using the correct method
topic_contributions = model.get_cell_topic_compositions(adata)

# Convert topic contributions to a DataFrame
import pandas as pd
topic_contributions_df = pd.DataFrame(topic_contributions, index=adata.obs_names)

# Save the results
output_path = '/mnt/data00/share_data/results/autogen/gpt-4o/mira/agent_output/mira.csv'
topic_contributions_df.to_csv(output_path)

print(f"Topic contributions saved to {output_path}")


import mira
import anndata as ad
from scipy.sparse import csr_matrix

# Ensure the data is in CSR format and contains integer counts
if not isinstance(adata.X, csr_matrix):
    adata.X = adata.X.tocsr()

# Configure the topic model
model = mira.topics.make_model(
    n_samples=adata.n_obs,
    n_features=adata.n_vars,
    feature_type='accessibility',  # Since we are working with ATAC-seq data
    counts_layer=None,  # Use the default layer if raw counts are in adata.X
    num_topics=16,  # Number of topics to learn from data
    use_cuda=True  # Use GPU acceleration if available
)

# Fit the model to the data
model.fit(adata)

# Extract topic contributions using the correct method
topic_contributions = model.get_cell_topic_compositions(adata)

# Convert topic contributions to a DataFrame
import pandas as pd
topic_contributions_df = pd.DataFrame(topic_contributions, index=adata.obs_names)

# Save the results
output_path = '/mnt/data00/share_data/results/autogen/gpt-4o/mira/agent_output/mira.csv'
topic_contributions_df.to_csv(output_path)

print(f"Topic contributions saved to {output_path}")
