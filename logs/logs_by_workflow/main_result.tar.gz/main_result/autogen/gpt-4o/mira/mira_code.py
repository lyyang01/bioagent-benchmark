
import anndata as ad

# Load the single-cell ATAC-seq dataset
adata = ad.read('/mnt/data00/share_data/agent_benchmark/mira/mira-datasets/e18_10X_brain_dataset/e18_mouse_brain_10x_dataset.ad')

# Display basic information about the dataset
print(adata)


# Display the column names of the barcodes DataFrame
print(barcodes_df.columns)

# Once the correct column name is identified, replace 'CorrectColumnName' with the actual name
# For example, if the column name is 'CellBarcode', use that instead
# adata.obs['barcode'] = barcodes_df['CorrectColumnName'].values

# Verify integration
# print(adata.obs.head())


import numpy as np
from scipy.sparse import csr_matrix

# Filter the AnnData object to include only cells with barcodes
valid_barcodes = barcodes_df['0'].values
adata = adata[adata.obs_names.isin(valid_barcodes)]

# Integrate barcodes with the filtered AnnData object
adata.obs['barcode'] = valid_barcodes

# Verify integration
print(adata.obs.head())

# Preprocessing steps
# Normalization for sparse matrix
if isinstance(adata.X, csr_matrix):
    adata.X = adata.X.multiply(1e4 / adata.X.sum(axis=1).A1[:, np.newaxis])
else:
    adata.X = adata.X / adata.X.sum(axis=1, keepdims=True) * 1e4

# Log-transform the data
adata.X = np.log1p(adata.X)

# Verify preprocessing
print(f"Number of cells after filtering: {adata.n_obs}")
