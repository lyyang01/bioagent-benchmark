
# Load the necessary library
library(scPNMF)

# Load the dataset from the scPNMF package
data(zheng4, package = 'scPNMF')

# Check the structure of the zheng4 object to find the expression data
str(zheng4)

# Assuming zheng4 is a SingleCellExperiment object, use assay to extract log-transformed counts
# Replace 'logcounts' with the correct assay name if different
Input_zheng4 <- assay(zheng4, "logcounts")

# The data is now loaded and ready for further analysis


# Check for missing values in the data
missing_values <- sum(is.na(Input_zheng4))
if (missing_values > 0) {
  cat("There are", missing_values, "missing values in the dataset.\n")
  # Handle missing values if necessary, e.g., by imputation or removal
  # For simplicity, let's remove any rows with missing values
  Input_zheng4 <- Input_zheng4[complete.cases(Input_zheng4), ]
}

# Check the dimensions of the data
cat("The dataset has", nrow(Input_zheng4), "genes and", ncol(Input_zheng4), "cells.\n")

# Normalize the data if necessary
# Assuming the data is already log-transformed, further normalization might not be needed
# However, if additional normalization is required, consider using methods like scaling

# Example: Scaling the data (if needed)
# Input_zheng4 <- scale(Input_zheng4)

# The data is now preprocessed and ready for scPNMF analysis


# Load the necessary library
library(scPNMF)

# Set the number of latent factors (K) - this is a parameter you might need to adjust based on your data
K <- 10  # Example value, adjust as needed

# Apply scPNMF to the preprocessed data
result <- scPNMF::PNMFfun(Input_zheng4, K, method = "EucDist", tol = 1e-4, maxIter = 1000, verboseN = TRUE)

# Extract the basis matrix (W) and sparse encoding matrix (S) from the result
W <- result$W
S <- result$S

# Use basisSelect to identify highly variable genes
selected_genes <- scPNMF::basisSelect(W, S, Input_zheng4, toTest = TRUE, toAnnotate = FALSE, mc.cores = 1)

# The selected_genes object now contains the highly variable genes identified by scPNMF


# Extract the list of highly variable gene names from the selected_genes object
# Assuming selected_genes contains the gene names or indices
highly_variable_genes <- rownames(Input_zheng4)[selected_genes]

# Define the output directory
output_directory <- '/mnt/data00/share_data/results/autogen/gpt-4o/scpnmf/agent_output'

# Create the directory if it doesn't exist
if (!dir.exists(output_directory)) {
  dir.create(output_directory, recursive = TRUE)
}

# Save the result as an RData file
save(highly_variable_genes, file = file.path(output_directory, 'scpnmf.RData'))

# The highly variable genes have been saved successfully


# Verify that the 'scpnmf.RData' file exists in the specified directory
output_file <- file.path(output_directory, 'scpnmf.RData')

if (file.exists(output_file)) {
  cat("The file 'scpnmf.RData' has been successfully saved in the directory.\n")
  
  # Load the file to check its contents
  load(output_file)
  
  # Display the first few highly variable genes to confirm the results
  cat("Here are some of the highly variable genes identified:\n")
  print(head(highly_variable_genes))
} else {
  cat("The file 'scpnmf.RData' was not found in the directory.\n")
}


# Define the documentation content
documentation_content <- "
# Documentation of the Process for Identifying Highly Variable Genes using scPNMF

## Step 1: Load the Input Data
- The dataset 'zheng4' was loaded from the 'scPNMF' package.
- Log-transformed counts were extracted using the `assay` function.

## Step 2: Preprocess the Data
- Checked for missing values in the dataset. No missing values were found.
- The dataset contained 2192 genes and 3994 cells.
- The data was assumed to be already log-transformed, so no additional normalization was performed.

## Step 3: Apply scPNMF
- The `PNMFfun` function from the scPNMF package was used to perform non-negative matrix factorization.
- Parameters used:
  - Number of latent factors (K): 10
  - Method: Euclidean distance
  - Tolerance for convergence: 1e-4
  - Maximum iterations: 1000
  - Verbose output: TRUE
- The function iterated 1000 times to converge.

## Step 4: Extract and Save Results
- The `basisSelect` function was used to identify highly variable genes from the basis and sparse encoding matrices.
- The list of highly variable genes was extracted and saved as 'scpnmf.RData' in the specified directory.

## Step 5: Verify the Output
- Confirmed that the 'scpnmf.RData' file was successfully saved.
- Loaded the file to verify its contents. However, the list of highly variable genes was empty, indicating a potential issue with the selection process.

## Observations and Insights
- The process successfully executed without errors, but the output list of highly variable genes was empty. This may require further investigation into the parameters used or the data itself.
- Future steps could involve adjusting the number of latent factors (K) or exploring different methods for gene selection.

## Conclusion
- The scPNMF method was applied to identify highly variable genes, but the results need further validation to ensure meaningful biological insights.
"

# Write the documentation to a text file
writeLines(documentation_content, file.path(output_directory, 'process_documentation.txt'))
