
import scanpy as sc

# Load the scRNA-seq data
sc_data_path = '/mnt/data00/share_data/agent_benchmark/cell2location/sc.h5ad'
adata_sc = sc.read_h5ad(sc_data_path)

# Check the loaded data
print(adata_sc)


import scanpy as sc

# Load the spatial transcriptomics data
adata_vis = sc.datasets.visium_sge(sample_id='V1_Human_Lymph_Node')

# Check the loaded data
print(adata_vis)


import scanpy as sc

# Preprocess the scRNA-seq data

# Filter cells and genes
sc.pp.filter_cells(adata_sc, min_genes=200)  # Filter out cells with fewer than 200 genes
sc.pp.filter_genes(adata_sc, min_cells=3)    # Filter out genes expressed in fewer than 3 cells

# Normalize the data
sc.pp.normalize_total(adata_sc, target_sum=1e4)  # Normalize counts per cell

# Logarithmize the data
sc.pp.log1p(adata_sc)  # Log-transform the data

# Identify highly variable genes
sc.pp.highly_variable_genes(adata_sc, min_mean=0.0125, max_mean=3, min_disp=0.5)

# Filter the data to keep only highly variable genes
adata_sc = adata_sc[:, adata_sc.var.highly_variable]

# Scale the data
sc.pp.scale(adata_sc, max_value=10)

# Check the preprocessed data
print(adata_sc)


import scanpy as sc

# Preprocess the spatial transcriptomics data

# Normalize the data
sc.pp.normalize_total(adata_vis, target_sum=1e4)  # Normalize counts per spot

# Logarithmize the data
sc.pp.log1p(adata_vis)  # Log-transform the data

# Check the preprocessed data
print(adata_vis)
