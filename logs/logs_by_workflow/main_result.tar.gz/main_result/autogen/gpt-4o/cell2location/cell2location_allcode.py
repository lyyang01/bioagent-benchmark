
import scanpy as sc

# Load the scRNA-seq data
sc_data_path = '/mnt/data00/share_data/agent_benchmark/cell2location/sc.h5ad'
adata_sc = sc.read_h5ad(sc_data_path)

# Check the loaded data
print(adata_sc)


import scanpy as sc

# Load the spatial transcriptomics data
adata_vis = sc.datasets.visium_sge(sample_id='V1_Human_Lymph_Node')

# Check the loaded data
print(adata_vis)


import scanpy as sc

# Preprocess the scRNA-seq data

# Filter cells and genes
sc.pp.filter_cells(adata_sc, min_genes=200)  # Filter out cells with fewer than 200 genes
sc.pp.filter_genes(adata_sc, min_cells=3)    # Filter out genes expressed in fewer than 3 cells

# Normalize the data
sc.pp.normalize_total(adata_sc, target_sum=1e4)  # Normalize counts per cell

# Logarithmize the data
sc.pp.log1p(adata_sc)  # Log-transform the data

# Identify highly variable genes
sc.pp.highly_variable_genes(adata_sc, min_mean=0.0125, max_mean=3, min_disp=0.5)

# Filter the data to keep only highly variable genes
adata_sc = adata_sc[:, adata_sc.var.highly_variable]

# Scale the data
sc.pp.scale(adata_sc, max_value=10)

# Check the preprocessed data
print(adata_sc)


import scanpy as sc

# Preprocess the spatial transcriptomics data

# Normalize the data
sc.pp.normalize_total(adata_vis, target_sum=1e4)  # Normalize counts per spot

# Logarithmize the data
sc.pp.log1p(adata_vis)  # Log-transform the data

# Check the preprocessed data
print(adata_vis)


import cell2location
import pandas as pd

# Set up the AnnData object for the RegressionModel
cell2location.models.RegressionModel.setup_anndata(adata_sc)

# Train the RegressionModel to estimate per cluster average mRNA count
regression_model = cell2location.models.RegressionModel(adata_sc)
regression_model.train(max_epochs=250, use_gpu=True)

# Export the estimated cell type signatures
cell_type_signatures = regression_model.export_posterior(adata_sc, add_to_varm=['means'])

# Prepare the spatial data for Cell2location model
cell2location.models.Cell2location.setup_anndata(adata_vis)

# Run the Cell2location model using the spatial data and estimated cell type signatures
cell2location_model = cell2location.models.Cell2location(adata_vis, cell_type_signatures)
cell2location_model.train(max_epochs=3000, use_gpu=True)

# Export the cell abundance estimates to the spatial data object
cell2location_model.export_posterior(adata_vis, add_to_obsm=['q05_cell_abundance_w_sf'])

# Save the cell abundance estimates to a CSV file
output_path = '/mnt/data00/share_data/results/autogen/gpt-4o/cell2location/agent_output/cell2location.csv'
cell_abundance_df = pd.DataFrame(adata_vis.obsm['q05_cell_abundance_w_sf'])
cell_abundance_df.to_csv(output_path)

print("Cell type abundance estimates saved to:", output_path)


import cell2location
import pandas as pd

# Set up the AnnData object for the RegressionModel
cell2location.models.RegressionModel.setup_anndata(adata_sc)

# Train the RegressionModel to estimate per cluster average mRNA count
regression_model = cell2location.models.RegressionModel(adata_sc)
regression_model.train(max_epochs=250, accelerator='gpu')  # Use GPU for training

# Export the estimated cell type signatures
cell_type_signatures = regression_model.export_posterior(adata_sc, add_to_varm=['means'])

# Prepare the spatial data for Cell2location model
cell2location.models.Cell2location.setup_anndata(adata_vis)

# Run the Cell2location model using the spatial data and estimated cell type signatures
cell2location_model = cell2location.models.Cell2location(adata_vis, cell_type_signatures)
cell2location_model.train(max_epochs=3000, accelerator='gpu')  # Use GPU for training

# Export the cell abundance estimates to the spatial data object
cell2location_model.export_posterior(adata_vis, add_to_obsm=['q05_cell_abundance_w_sf'])

# Save the cell abundance estimates to a CSV file
output_path = '/mnt/data00/share_data/results/autogen/gpt-4o/cell2location/agent_output/cell2location.csv'
cell_abundance_df = pd.DataFrame(adata_vis.obsm['q05_cell_abundance_w_sf'])
cell_abundance_df.to_csv(output_path)

print("Cell type abundance estimates saved to:", output_path)


import cell2location
import pandas as pd

# Ensure no negative values in the data
adata_sc.X = adata_sc.X.clip(min=0)
adata_vis.X = adata_vis.X.clip(min=0)

# Set up the AnnData object for the RegressionModel
cell2location.models.RegressionModel.setup_anndata(adata_sc)

# Train the RegressionModel to estimate per cluster average mRNA count
regression_model = cell2location.models.RegressionModel(adata_sc)
regression_model.train(max_epochs=250, accelerator='gpu')  # Use GPU for training

# Export the estimated cell type signatures
cell_type_signatures = regression_model.export_posterior(adata_sc, add_to_varm=['means'])

# Prepare the spatial data for Cell2location model
cell2location.models.Cell2location.setup_anndata(adata_vis)

# Run the Cell2location model using the spatial data and estimated cell type signatures
cell2location_model = cell2location.models.Cell2location(adata_vis, cell_type_signatures)
cell2location_model.train(max_epochs=3000, accelerator='gpu')  # Use GPU for training

# Export the cell abundance estimates to the spatial data object
cell2location_model.export_posterior(adata_vis, add_to_obsm=['q05_cell_abundance_w_sf'])

# Save the cell abundance estimates to a CSV file
output_path = '/mnt/data00/share_data/results/autogen/gpt-4o/cell2location/agent_output/cell2location.csv'
cell_abundance_df = pd.DataFrame(adata_vis.obsm['q05_cell_abundance_w_sf'])
cell_abundance_df.to_csv(output_path)

print("Cell type abundance estimates saved to:", output_path)


import cell2location
import pandas as pd
import numpy as np

# Ensure no negative values in the data
adata_sc.X = np.clip(adata_sc.X.toarray(), a_min=0, a_max=None)
adata_vis.X = np.clip(adata_vis.X.toarray(), a_min=0, a_max=None)

# Set up the AnnData object for the RegressionModel
cell2location.models.RegressionModel.setup_anndata(adata_sc)

# Train the RegressionModel to estimate per cluster average mRNA count
regression_model = cell2location.models.RegressionModel(adata_sc)
regression_model.train(max_epochs=250, accelerator='gpu')  # Use GPU for training

# Export the estimated cell type signatures
cell_type_signatures = regression_model.export_posterior(adata_sc, add_to_varm=['means'])

# Prepare the spatial data for Cell2location model
cell2location.models.Cell2location.setup_anndata(adata_vis)

# Run the Cell2location model using the spatial data and estimated cell type signatures
cell2location_model = cell2location.models.Cell2location(adata_vis, cell_type_signatures)
cell2location_model.train(max_epochs=3000, accelerator='gpu')  # Use GPU for training

# Export the cell abundance estimates to the spatial data object
cell2location_model.export_posterior(adata_vis, add_to_obsm=['q05_cell_abundance_w_sf'])

# Save the cell abundance estimates to a CSV file
output_path = '/mnt/data00/share_data/results/autogen/gpt-4o/cell2location/agent_output/cell2location.csv'
cell_abundance_df = pd.DataFrame(adata_vis.obsm['q05_cell_abundance_w_sf'])
cell_abundance_df.to_csv(output_path)

print("Cell type abundance estimates saved to:", output_path)


import cell2location
import pandas as pd
import numpy as np
from scipy.sparse import issparse

# Ensure no negative values in the data
if issparse(adata_sc.X):
    adata_sc.X = adata_sc.X.toarray()
adata_sc.X = np.clip(adata_sc.X, a_min=0, a_max=None)

if issparse(adata_vis.X):
    adata_vis.X = adata_vis.X.toarray()
adata_vis.X = np.clip(adata_vis.X, a_min=0, a_max=None)

# Set up the AnnData object for the RegressionModel
cell2location.models.RegressionModel.setup_anndata(adata_sc)

# Train the RegressionModel to estimate per cluster average mRNA count
regression_model = cell2location.models.RegressionModel(adata_sc)
regression_model.train(max_epochs=250, accelerator='gpu')  # Use GPU for training

# Export the estimated cell type signatures
cell_type_signatures = regression_model.export_posterior(adata_sc, add_to_varm=['means'])

# Prepare the spatial data for Cell2location model
cell2location.models.Cell2location.setup_anndata(adata_vis)

# Run the Cell2location model using the spatial data and estimated cell type signatures
cell2location_model = cell2location.models.Cell2location(adata_vis, cell_type_signatures)
cell2location_model.train(max_epochs=3000, accelerator='gpu')  # Use GPU for training

# Export the cell abundance estimates to the spatial data object
cell2location_model.export_posterior(adata_vis, add_to_obsm=['q05_cell_abundance_w_sf'])

# Save the cell abundance estimates to a CSV file
output_path = '/mnt/data00/share_data/results/autogen/gpt-4o/cell2location/agent_output/cell2location.csv'
cell_abundance_df = pd.DataFrame(adata_vis.obsm['q05_cell_abundance_w_sf'])
cell_abundance_df.to_csv(output_path)

print("Cell type abundance estimates saved to:", output_path)


import cell2location
import pandas as pd
import numpy as np
from scipy.sparse import issparse

# Add a small constant to avoid zero values
epsilon = 1e-10

# Ensure no negative values and add epsilon to avoid zeros
if issparse(adata_sc.X):
    adata_sc.X = adata_sc.X.toarray()
adata_sc.X = np.clip(adata_sc.X, a_min=0, a_max=None) + epsilon

if issparse(adata_vis.X):
    adata_vis.X = adata_vis.X.toarray()
adata_vis.X = np.clip(adata_vis.X, a_min=0, a_max=None) + epsilon

# Set up the AnnData object for the RegressionModel
cell2location.models.RegressionModel.setup_anndata(adata_sc)

# Train the RegressionModel to estimate per cluster average mRNA count
regression_model = cell2location.models.RegressionModel(adata_sc)
regression_model.train(max_epochs=250, accelerator='gpu')  # Use GPU for training

# Export the estimated cell type signatures
cell_type_signatures = regression_model.export_posterior(adata_sc, add_to_varm=['means'])

# Prepare the spatial data for Cell2location model
cell2location.models.Cell2location.setup_anndata(adata_vis)

# Run the Cell2location model using the spatial data and estimated cell type signatures
cell2location_model = cell2location.models.Cell2location(adata_vis, cell_type_signatures)
cell2location_model.train(max_epochs=3000, accelerator='gpu')  # Use GPU for training

# Export the cell abundance estimates to the spatial data object
cell2location_model.export_posterior(adata_vis, add_to_obsm=['q05_cell_abundance_w_sf'])

# Save the cell abundance estimates to a CSV file
output_path = '/mnt/data00/share_data/results/autogen/gpt-4o/cell2location/agent_output/cell2location.csv'
cell_abundance_df = pd.DataFrame(adata_vis.obsm['q05_cell_abundance_w_sf'])
cell_abundance_df.to_csv(output_path)

print("Cell type abundance estimates saved to:", output_path)


import cell2location
import pandas as pd
import numpy as np
from scipy.sparse import issparse

# Convert data to integer counts
if issparse(adata_sc.X):
    adata_sc.X = adata_sc.X.toarray()
adata_sc.X = np.round(adata_sc.X).astype(int)

if issparse(adata_vis.X):
    adata_vis.X = adata_vis.X.toarray()
adata_vis.X = np.round(adata_vis.X).astype(int)

# Set up the AnnData object for the RegressionModel
cell2location.models.RegressionModel.setup_anndata(adata_sc)

# Train the RegressionModel to estimate per cluster average mRNA count
regression_model = cell2location.models.RegressionModel(adata_sc)
regression_model.train(max_epochs=250, accelerator='gpu')  # Use GPU for training

# Export the estimated cell type signatures
cell_type_signatures = regression_model.export_posterior(adata_sc, add_to_varm=['means'])

# Prepare the spatial data for Cell2location model
cell2location.models.Cell2location.setup_anndata(adata_vis)

# Run the Cell2location model using the spatial data and estimated cell type signatures
cell2location_model = cell2location.models.Cell2location(adata_vis, cell_type_signatures)
cell2location_model.train(max_epochs=3000, accelerator='gpu')  # Use GPU for training

# Export the cell abundance estimates to the spatial data object
cell2location_model.export_posterior(adata_vis, add_to_obsm=['q05_cell_abundance_w_sf'])

# Save the cell abundance estimates to a CSV file
output_path = '/mnt/data00/share_data/results/autogen/gpt-4o/cell2location/agent_output/cell2location.csv'
cell_abundance_df = pd.DataFrame(adata_vis.obsm['q05_cell_abundance_w_sf'])
cell_abundance_df.to_csv(output_path)

print("Cell type abundance estimates saved to:", output_path)


import cell2location
import pandas as pd
import numpy as np
from scipy.sparse import issparse

# Convert data to integer counts
if issparse(adata_sc.X):
    adata_sc.X = adata_sc.X.toarray()
adata_sc.X = np.round(adata_sc.X).astype(int)

if issparse(adata_vis.X):
    adata_vis.X = adata_vis.X.toarray()
adata_vis.X = np.round(adata_vis.X).astype(int)

# Set up the AnnData object for the RegressionModel
cell2location.models.RegressionModel.setup_anndata(adata_sc)

# Train the RegressionModel to estimate per cluster average mRNA count
regression_model = cell2location.models.RegressionModel(adata_sc)
regression_model.train(max_epochs=250, accelerator='gpu')  # Use GPU for training

# Export the estimated cell type signatures
cell_type_signatures = regression_model.export_posterior(adata_sc, add_to_varm=['means'])

# Ensure gene names match between adata_vis and cell_type_signatures
common_genes = adata_vis.var_names.intersection(cell_type_signatures.index)
adata_vis = adata_vis[:, common_genes]
cell_type_signatures = cell_type_signatures.loc[common_genes]

# Prepare the spatial data for Cell2location model
cell2location.models.Cell2location.setup_anndata(adata_vis)

# Run the Cell2location model using the spatial data and estimated cell type signatures
cell2location_model = cell2location.models.Cell2location(adata_vis, cell_type_signatures)
cell2location_model.train(max_epochs=3000, accelerator='gpu')  # Use GPU for training

# Export the cell abundance estimates to the spatial data object
cell2location_model.export_posterior(adata_vis, add_to_obsm=['q05_cell_abundance_w_sf'])

# Save the cell abundance estimates to a CSV file
output_path = '/mnt/data00/share_data/results/autogen/gpt-4o/cell2location/agent_output/cell2location.csv'
cell_abundance_df = pd.DataFrame(adata_vis.obsm['q05_cell_abundance_w_sf'])
cell_abundance_df.to_csv(output_path)

print("Cell type abundance estimates saved to:", output_path)


import cell2location
import pandas as pd
import numpy as np
from scipy.sparse import issparse

# Convert data to integer counts
if issparse(adata_sc.X):
    adata_sc.X = adata_sc.X.toarray()
adata_sc.X = np.round(adata_sc.X).astype(int)

if issparse(adata_vis.X):
    adata_vis.X = adata_vis.X.toarray()
adata_vis.X = np.round(adata_vis.X).astype(int)

# Set up the AnnData object for the RegressionModel
cell2location.models.RegressionModel.setup_anndata(adata_sc)

# Train the RegressionModel to estimate per cluster average mRNA count
regression_model = cell2location.models.RegressionModel(adata_sc)
regression_model.train(max_epochs=250, accelerator='gpu')  # Use GPU for training

# Export the estimated cell type signatures
cell_type_signatures = regression_model.export_posterior(adata_sc, add_to_varm=['means'])

# Convert cell_type_signatures to DataFrame if not already
if not isinstance(cell_type_signatures, pd.DataFrame):
    cell_type_signatures = pd.DataFrame(cell_type_signatures, index=adata_sc.var_names)

# Ensure gene names match between adata_vis and cell_type_signatures
common_genes = adata_vis.var_names.intersection(cell_type_signatures.index)
adata_vis = adata_vis[:, common_genes]
cell_type_signatures = cell_type_signatures.loc[common_genes]

# Prepare the spatial data for Cell2location model
cell2location.models.Cell2location.setup_anndata(adata_vis)

# Run the Cell2location model using the spatial data and estimated cell type signatures
cell2location_model = cell2location.models.Cell2location(adata_vis, cell_type_signatures)
cell2location_model.train(max_epochs=3000, accelerator='gpu')  # Use GPU for training

# Export the cell abundance estimates to the spatial data object
cell2location_model.export_posterior(adata_vis, add_to_obsm=['q05_cell_abundance_w_sf'])

# Save the cell abundance estimates to a CSV file
output_path = '/mnt/data00/share_data/results/autogen/gpt-4o/cell2location/agent_output/cell2location.csv'
cell_abundance_df = pd.DataFrame(adata_vis.obsm['q05_cell_abundance_w_sf'])
cell_abundance_df.to_csv(output_path)

print("Cell type abundance estimates saved to:", output_path)


import cell2location
import pandas as pd
import numpy as np
from scipy.sparse import issparse

# Convert data to integer counts
if issparse(adata_sc.X):
    adata_sc.X = adata_sc.X.toarray()
adata_sc.X = np.round(adata_sc.X).astype(int)

if issparse(adata_vis.X):
    adata_vis.X = adata_vis.X.toarray()
adata_vis.X = np.round(adata_vis.X).astype(int)

# Set up the AnnData object for the RegressionModel
cell2location.models.RegressionModel.setup_anndata(adata_sc)

# Train the RegressionModel to estimate per cluster average mRNA count
regression_model = cell2location.models.RegressionModel(adata_sc)
regression_model.train(max_epochs=250, accelerator='gpu')  # Use GPU for training

# Export the estimated cell type signatures
cell_type_signatures = regression_model.export_posterior(adata_sc, add_to_varm=['means'])

# Check the type and structure of cell_type_signatures
print(type(cell_type_signatures))
print(cell_type_signatures)

# Convert cell_type_signatures to DataFrame if not already
if isinstance(cell_type_signatures, dict) and 'means' in cell_type_signatures:
    cell_type_signatures = pd.DataFrame(cell_type_signatures['means'], index=adata_sc.var_names)

# Ensure gene names match between adata_vis and cell_type_signatures
common_genes = adata_vis.var_names.intersection(cell_type_signatures.index)
adata_vis = adata_vis[:, common_genes]
cell_type_signatures = cell_type_signatures.loc[common_genes]

# Prepare the spatial data for Cell2location model
cell2location.models.Cell2location.setup_anndata(adata_vis)

# Run the Cell2location model using the spatial data and estimated cell type signatures
cell2location_model = cell2location.models.Cell2location(adata_vis, cell_type_signatures)
cell2location_model.train(max_epochs=3000, accelerator='gpu')  # Use GPU for training

# Export the cell abundance estimates to the spatial data object
cell2location_model.export_posterior(adata_vis, add_to_obsm=['q05_cell_abundance_w_sf'])

# Save the cell abundance estimates to a CSV file
output_path = '/mnt/data00/share_data/results/autogen/gpt-4o/cell2location/agent_output/cell2location.csv'
cell_abundance_df = pd.DataFrame(adata_vis.obsm['q05_cell_abundance_w_sf'])
cell_abundance_df.to_csv(output_path)

print("Cell type abundance estimates saved to:", output_path)


import cell2location
import pandas as pd
import numpy as np
from scipy.sparse import issparse

# Convert data to integer counts
if issparse(adata_sc.X):
    adata_sc.X = adata_sc.X.toarray()
adata_sc.X = np.round(adata_sc.X).astype(int)

if issparse(adata_vis.X):
    adata_vis.X = adata_vis.X.toarray()
adata_vis.X = np.round(adata_vis.X).astype(int)

# Set up the AnnData object for the RegressionModel
cell2location.models.RegressionModel.setup_anndata(adata_sc)

# Train the RegressionModel to estimate per cluster average mRNA count
regression_model = cell2location.models.RegressionModel(adata_sc)
regression_model.train(max_epochs=250, accelerator='gpu')  # Use GPU for training

# Export the estimated cell type signatures
cell_type_signatures = regression_model.export_posterior(adata_sc, add_to_varm=['means'])

# Convert cell_type_signatures to DataFrame if not already
if isinstance(cell_type_signatures, dict) and 'means' in cell_type_signatures:
    cell_type_signatures = pd.DataFrame(cell_type_signatures['means'], index=adata_sc.var_names)

# Ensure gene names match between adata_vis and cell_type_signatures
common_genes = adata_vis.var_names.intersection(cell_type_signatures.index)
adata_vis = adata_vis[:, common_genes]
cell_type_signatures = cell_type_signatures.loc[common_genes]

# Prepare the spatial data for Cell2location model
cell2location.models.Cell2location.setup_anndata(adata_vis)

# Run the Cell2location model using the spatial data and estimated cell type signatures
cell2location_model = cell2location.models.Cell2location(adata_vis, cell_type_signatures)
cell2location_model.train(max_epochs=3000, accelerator='gpu')  # Use GPU for training

# Export the cell abundance estimates to the spatial data object
cell2location_model.export_posterior(adata_vis, add_to_obsm=['q05_cell_abundance_w_sf'])

# Save the cell abundance estimates to a CSV file
output_path = '/mnt/data00/share_data/results/autogen/gpt-4o/cell2location/agent_output/cell2location.csv'
cell_abundance_df = pd.DataFrame(adata_vis.obsm['q05_cell_abundance_w_sf'])
cell_abundance_df.to_csv(output_path)

print("Cell type abundance estimates saved to:", output_path)


import cell2location
import pandas as pd
import numpy as np
from scipy.sparse import issparse

# Convert data to integer counts
if issparse(adata_sc.X):
    adata_sc.X = adata_sc.X.toarray()
adata_sc.X = np.round(adata_sc.X).astype(int)

if issparse(adata_vis.X):
    adata_vis.X = adata_vis.X.toarray()
adata_vis.X = np.round(adata_vis.X).astype(int)

# Set up the AnnData object for the RegressionModel
cell2location.models.RegressionModel.setup_anndata(adata_sc)

# Train the RegressionModel to estimate per cluster average mRNA count
regression_model = cell2location.models.RegressionModel(adata_sc)
regression_model.train(max_epochs=250, accelerator='gpu')  # Use GPU for training

# Export the estimated cell type signatures
cell_type_signatures = regression_model.export_posterior(adata_sc, add_to_varm=['means'])

# Convert cell_type_signatures to DataFrame if not already
if isinstance(cell_type_signatures, dict) and 'means' in cell_type_signatures:
    cell_type_signatures = pd.DataFrame(cell_type_signatures['means'], index=adata_sc.var_names)

# Ensure gene names match between adata_vis and cell_type_signatures
common_genes = adata_vis.var_names.intersection(cell_type_signatures.index)
adata_vis = adata_vis[:, common_genes]
cell_type_signatures = cell_type_signatures.loc[common_genes]

# Prepare the spatial data for Cell2location model
cell2location.models.Cell2location.setup_anndata(adata_vis)

# Run the Cell2location model using the spatial data and estimated cell type signatures
cell2location_model = cell2location.models.Cell2location(adata_vis, cell_type_signatures)
cell2location_model.train(max_epochs=3000, accelerator='gpu')  # Use GPU for training

# Export the cell abundance estimates to the spatial data object
cell2location_model.export_posterior(adata_vis, add_to_obsm=['q05_cell_abundance_w_sf'])

# Save the cell abundance estimates to a CSV file
output_path = '/mnt/data00/share_data/results/autogen/gpt-4o/cell2location/agent_output/cell2location.csv'
cell_abundance_df = pd.DataFrame(adata_vis.obsm['q05_cell_abundance_w_sf'])
cell_abundance_df.to_csv(output_path)

print("Cell type abundance estimates saved to:", output_path)
