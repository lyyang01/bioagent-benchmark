
# Load necessary library
library(Seurat)

# Define the input directory
input_directory <- '/mnt/data00/share_data/agent_benchmark/sctransform/pbmc3k/filtered_gene_bc_matrices/hg19/'

# Load the data using Read10X
sc_data <- Read10X(data.dir = input_directory)

# Create a Seurat object from the loaded data
seurat_object <- CreateSeuratObject(counts = sc_data)

# Save the Seurat object for further processing
saveRDS(seurat_object, file = '/mnt/data00/share_data/results/autogen/gpt-4o/sctransform/agent_output/seurat_object.rds')

# Print a summary of the Seurat object
print(seurat_object)


# Load necessary library
library(Seurat)

# Load the previously saved Seurat object
seurat_object <- readRDS('/mnt/data00/share_data/results/autogen/gpt-4o/sctransform/agent_output/seurat_object.rds')

# Apply SCTransform normalization
seurat_object <- SCTransform(seurat_object, verbose = TRUE)

# Save the normalized Seurat object for further processing
saveRDS(seurat_object, file = '/mnt/data00/share_data/results/autogen/gpt-4o/sctransform/agent_output/seurat_object_sctransform.rds')

# Print a summary of the normalized Seurat object
print(seurat_object)


# Load necessary library
library(Seurat)

# Load the normalized Seurat object
seurat_object <- readRDS('/mnt/data00/share_data/results/autogen/gpt-4o/sctransform/agent_output/seurat_object_sctransform.rds')

# Perform PCA on the normalized data
seurat_object <- RunPCA(seurat_object, verbose = TRUE)

# Save the Seurat object with PCA results
saveRDS(seurat_object, file = '/mnt/data00/share_data/results/autogen/gpt-4o/sctransform/agent_output/seurat_object_pca.rds')

# Visualize the PCA results
ElbowPlot(seurat_object)

# Print a summary of the PCA results
print(seurat_object[["pca"]])


# Load necessary libraries
library(Seurat)
library(ggplot2)  # Load ggplot2 for ggsave function

# Load the Seurat object with PCA results
seurat_object <- readRDS('/mnt/data00/share_data/results/autogen/gpt-4o/sctransform/agent_output/seurat_object_pca.rds')

# Perform UMAP on the Seurat object
seurat_object <- RunUMAP(seurat_object, dims = 1:20, verbose = TRUE)

# Save the Seurat object with UMAP results
saveRDS(seurat_object, file = '/mnt/data00/share_data/results/autogen/gpt-4o/sctransform/agent_output/seurat_object_umap.rds')

# Visualize the UMAP results
umap_plot <- DimPlot(seurat_object, reduction = "umap")

# Save the UMAP plot
ggsave(filename = '/mnt/data00/share_data/results/autogen/gpt-4o/sctransform/agent_output/umap_plot.png', plot = umap_plot)
