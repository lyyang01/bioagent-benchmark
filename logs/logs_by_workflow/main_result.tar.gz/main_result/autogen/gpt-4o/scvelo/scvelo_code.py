
import scanpy as sc

# Load the single-cell RNA sequencing data into an AnnData object using scanpy
adata = sc.read_h5ad('/mnt/data00/share_data/agent_benchmark/scvelo/endocrinogenesis_day15.h5ad')

# Display basic information about the loaded data
print(adata)


import scvelo as scv

# Preprocess the data for RNA velocity analysis
# Normalize the data
scv.pp.filter_and_normalize(adata)

# Log-transform the data
scv.pp.log1p(adata)

# Identify the first and second moments (necessary for velocity estimation)
scv.pp.moments(adata)

# Display the updated AnnData object to verify preprocessing
print(adata)


# Compute RNA velocity using scVelo
scv.tl.velocity(adata)

# Display the updated AnnData object to verify RNA velocity computation
print(adata)


# Generate the RNA velocity graph
scv.tl.velocity_graph(adata)

# Display the updated AnnData object to verify the velocity graph computation
print(adata.uns['velocity_graph'])


import pandas as pd

# Extract the velocity graph transition matrix
velocity_graph_matrix = adata.uns['velocity_graph'].toarray()

# Convert the matrix to a DataFrame for easier saving
velocity_graph_df = pd.DataFrame(velocity_graph_matrix)

# Define the output file path
output_file_path = '/mnt/data00/share_data/results/autogen/gpt-4o/scvelo/agent_output/scvelo.csv'

# Save the DataFrame as a CSV file
velocity_graph_df.to_csv(output_file_path, index=False)

print(f"Velocity graph transition matrix saved to {output_file_path}")
