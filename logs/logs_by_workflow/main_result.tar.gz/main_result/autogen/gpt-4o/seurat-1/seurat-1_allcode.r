
# Load necessary library
library(Seurat)

# Define file paths
rna_file_path <- '/mnt/data00/share_data/agent_benchmark/seurat-1/GSE100866_CBMC_8K_13AB_10X-RNA_umi.csv.gz'
adt_file_path <- '/mnt/data00/share_data/agent_benchmark/seurat-1/GSE100866_CBMC_8K_13AB_10X-ADT_umi.csv.gz'

# Load RNA UMI matrix
rna_data <- read.csv(rna_file_path, row.names = 1)
# Check the structure of the RNA data
str(rna_data)

# Load ADT UMI matrix
adt_data <- read.csv(adt_file_path, row.names = 1)
# Check the structure of the ADT data
str(adt_data)

# Ensure data is correctly structured for Seurat
# RNA and ADT data should have cells as columns and features (genes/proteins) as rows


# Create a Seurat object using the RNA UMI matrix
seurat_object <- CreateSeuratObject(counts = rna_data, project = "RNA_Analysis")

# Print the Seurat object to check its structure
print(seurat_object)

# Basic setup for further analysis
# The Seurat object will contain the RNA data as the default assay
# Additional metadata can be added if available or required


# Add ADT data as a new assay in the Seurat object
seurat_object[["ADT"]] <- CreateAssayObject(counts = adt_data)

# Print the Seurat object to verify the addition of the ADT assay
print(seurat_object)

# Ensure that the ADT data is correctly integrated
# The Seurat object should now contain both RNA and ADT assays


# Calculate the percentage of mitochondrial genes for each cell
seurat_object[["percent.mt"]] <- PercentageFeatureSet(seurat_object, pattern = "^MT-")

# Visualize QC metrics as a violin plot
VlnPlot(seurat_object, features = c("nFeature_RNA", "nCount_RNA", "percent.mt"), ncol = 3)

# Set thresholds for filtering
# These thresholds are examples and may need adjustment based on the dataset
min_features <- 200
max_features <- 2500
max_mitochondrial <- 5

# Filter cells based on QC metrics
seurat_object <- subset(seurat_object, subset = nFeature_RNA > min_features & nFeature_RNA < max_features & percent.mt < max_mitochondrial)

# Print the Seurat object to check the number of cells after filtering
print(seurat_object)


# Normalize RNA data
seurat_object <- NormalizeData(seurat_object, assay = "RNA", normalization.method = "LogNormalize", scale.factor = 10000)

# Normalize ADT data
seurat_object <- NormalizeData(seurat_object, assay = "ADT", normalization.method = "CLR")

# Print the Seurat object to verify normalization
print(seurat_object)


# Identify highly variable features in the RNA data
seurat_object <- FindVariableFeatures(seurat_object, assay = "RNA", selection.method = "vst", nfeatures = 2000)

# Print the top 10 highly variable features
top10_variable_genes <- head(VariableFeatures(seurat_object), 10)
print(top10_variable_genes)

# Plot variable features with and without labels
VariableFeaturePlot(seurat_object) + 
  LabelPoints(points = top10_variable_genes, repel = TRUE)

# Save the plot
ggsave(filename = "/mnt/data00/share_data/results/autogen/gpt-4o/seurat-1/agent_output/variable_features_plot.png")


# Identify highly variable features in the RNA data
seurat_object <- FindVariableFeatures(seurat_object, assay = "RNA", selection.method = "vst", nfeatures = 2000)

# Print the top 10 highly variable features
top10_variable_genes <- head(VariableFeatures(seurat_object), 10)
print(top10_variable_genes)

# Plot variable features with and without labels
variable_feature_plot <- VariableFeaturePlot(seurat_object)
variable_feature_plot + LabelPoints(plot = variable_feature_plot, points = top10_variable_genes, repel = TRUE)

# Save the plot
ggsave(filename = "/mnt/data00/share_data/results/autogen/gpt-4o/seurat-1/agent_output/variable_features_plot.png", plot = variable_feature_plot)


# Load ggplot2 for saving plots
library(ggplot2)

# Identify highly variable features in the RNA data
seurat_object <- FindVariableFeatures(seurat_object, assay = "RNA", selection.method = "vst", nfeatures = 2000)

# Print the top 10 highly variable features
top10_variable_genes <- head(VariableFeatures(seurat_object), 10)
print(top10_variable_genes)

# Plot variable features with and without labels
variable_feature_plot <- VariableFeaturePlot(seurat_object)
variable_feature_plot <- variable_feature_plot + LabelPoints(plot = variable_feature_plot, points = top10_variable_genes, repel = TRUE)

# Save the plot
ggsave(filename = "/mnt/data00/share_data/results/autogen/gpt-4o/seurat-1/agent_output/variable_features_plot.png", plot = variable_feature_plot)


# Load ggplot2 for saving plots
library(ggplot2)

# Identify highly variable features in the RNA data
seurat_object <- FindVariableFeatures(seurat_object, assay = "RNA", selection.method = "vst", nfeatures = 2000)

# Print the top 10 highly variable features
top10_variable_genes <- head(VariableFeatures(seurat_object), 10)
print(top10_variable_genes)

# Plot variable features with and without labels
variable_feature_plot <- VariableFeaturePlot(seurat_object)
variable_feature_plot <- variable_feature_plot + LabelPoints(plot = variable_feature_plot, points = top10_variable_genes, repel = TRUE)

# Save the plot with specified dimensions
ggsave(filename = "/mnt/data00/share_data/results/autogen/gpt-4o/seurat-1/agent_output/variable_features_plot.png", plot = variable_feature_plot, width = 10, height = 6)


# Scale the RNA data
seurat_object <- ScaleData(seurat_object, assay = "RNA", features = VariableFeatures(seurat_object))

# Perform PCA on the scaled RNA data
seurat_object <- RunPCA(seurat_object, assay = "RNA", features = VariableFeatures(seurat_object))

# Visualize the PCA results
PCAPlot(seurat_object, dims = c(1, 2))

# Save the PCA plot
ggsave(filename = "/mnt/data00/share_data/results/autogen/gpt-4o/seurat-1/agent_output/pca_plot.png")


# Perform Weighted Nearest Neighbor (WNN) analysis
seurat_object <- FindMultiModalNeighbors(
  seurat_object, 
  reduction.list = list("pca", "apca"), 
  dims.list = list(1:30, 1:18), 
  modality.weight.name = "RNA.weight"
)

# Run UMAP on the WNN graph
seurat_object <- RunUMAP(seurat_object, nn.name = "weighted.nn", reduction.name = "wnn.umap", reduction.key = "wnnUMAP_")

# Print the Seurat object to verify integration
print(seurat_object)

# Save the integrated UMAP plot
DimPlot(seurat_object, reduction = "wnn.umap", group.by = "seurat_clusters") +
  ggsave(filename = "/mnt/data00/share_data/results/autogen/gpt-4o/seurat-1/agent_output/wnn_umap_plot.png")


# Perform PCA on the ADT data
seurat_object <- ScaleData(seurat_object, assay = "ADT")
seurat_object <- RunPCA(seurat_object, assay = "ADT", reduction.name = "apca")

# Perform Weighted Nearest Neighbor (WNN) analysis
seurat_object <- FindMultiModalNeighbors(
  seurat_object, 
  reduction.list = list("pca", "apca"), 
  dims.list = list(1:30, 1:18), 
  modality.weight.name = "RNA.weight"
)

# Run UMAP on the WNN graph
seurat_object <- RunUMAP(seurat_object, nn.name = "weighted.nn", reduction.name = "wnn.umap", reduction.key = "wnnUMAP_")

# Print the Seurat object to verify integration
print(seurat_object)

# Save the integrated UMAP plot
DimPlot(seurat_object, reduction = "wnn.umap", group.by = "seurat_clusters") +
  ggsave(filename = "/mnt/data00/share_data/results/autogen/gpt-4o/seurat-1/agent_output/wnn_umap_plot.png")


# Identify variable features for the ADT data
seurat_object <- FindVariableFeatures(seurat_object, assay = "ADT", selection.method = "vst", nfeatures = 200)

# Perform PCA on the ADT data
seurat_object <- ScaleData(seurat_object, assay = "ADT", features = VariableFeatures(seurat_object, assay = "ADT"))
seurat_object <- RunPCA(seurat_object, assay = "ADT", features = VariableFeatures(seurat_object, assay = "ADT"), reduction.name = "apca")

# Perform Weighted Nearest Neighbor (WNN) analysis
seurat_object <- FindMultiModalNeighbors(
  seurat_object, 
  reduction.list = list("pca", "apca"), 
  dims.list = list(1:30, 1:18), 
  modality.weight.name = "RNA.weight"
)

# Run UMAP on the WNN graph
seurat_object <- RunUMAP(seurat_object, nn.name = "weighted.nn", reduction.name = "wnn.umap", reduction.key = "wnnUMAP_")

# Print the Seurat object to verify integration
print(seurat_object)

# Save the integrated UMAP plot
DimPlot(seurat_object, reduction = "wnn.umap", group.by = "seurat_clusters") +
  ggsave(filename = "/mnt/data00/share_data/results/autogen/gpt-4o/seurat-1/agent_output/wnn_umap_plot.png")


# Identify variable features for the ADT data
seurat_object <- FindVariableFeatures(seurat_object, assay = "ADT", selection.method = "vst", nfeatures = 200)

# Scale and perform PCA on the ADT data
seurat_object <- ScaleData(seurat_object, assay = "ADT", features = VariableFeatures(seurat_object, assay = "ADT"))
seurat_object <- RunPCA(seurat_object, assay = "ADT", features = VariableFeatures(seurat_object, assay = "ADT"), reduction.name = "apca")

# Check the number of PCs available for ADT
adt_pca <- Embeddings(seurat_object, reduction = "apca")
num_adt_pcs <- ncol(adt_pca)
print(paste("Number of ADT PCs available:", num_adt_pcs))

# Perform Weighted Nearest Neighbor (WNN) analysis using available PCs
seurat_object <- FindMultiModalNeighbors(
  seurat_object, 
  reduction.list = list("pca", "apca"), 
  dims.list = list(1:30, 1:num_adt_pcs), 
  modality.weight.name = "RNA.weight"
)

# Run UMAP on the WNN graph
seurat_object <- RunUMAP(seurat_object, nn.name = "weighted.nn", reduction.name = "wnn.umap", reduction.key = "wnnUMAP_")

# Print the Seurat object to verify integration
print(seurat_object)

# Save the integrated UMAP plot
DimPlot(seurat_object, reduction = "wnn.umap", group.by = "seurat_clusters") +
  ggsave(filename = "/mnt/data00/share_data/results/autogen/gpt-4o/seurat-1/agent_output/wnn_umap_plot.png")


# Perform clustering on the integrated data
seurat_object <- FindClusters(seurat_object, graph.name = "weighted.nn", resolution = 0.5)

# Run UMAP on the WNN graph
seurat_object <- RunUMAP(seurat_object, nn.name = "weighted.nn", reduction.name = "wnn.umap", reduction.key = "wnnUMAP_")

# Print the Seurat object to verify integration and clustering
print(seurat_object)

# Save the integrated UMAP plot with clusters
DimPlot(seurat_object, reduction = "wnn.umap", group.by = "seurat_clusters") +
  ggsave(filename = "/mnt/data00/share_data/results/autogen/gpt-4o/seurat-1/agent_output/wnn_umap_plot.png")
