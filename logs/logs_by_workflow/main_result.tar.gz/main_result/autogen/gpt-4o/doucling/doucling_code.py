
import scanpy as sc

# Load the dataset into an AnnData object
adata = sc.read_10x_mtx(
    '/mnt/data00/share_data/agent_benchmark/doucling/filtered_gene_bc_matrices/GRCh38/',  # Path to the dataset
    var_names='gene_symbols',  # Use gene symbols for variable names
    cache=True  # Cache the data for faster loading next time
)

# Check the loaded data
print(adata)


import scanpy as sc
import numpy as np

# Load the dataset into an AnnData object
adata = sc.read_10x_mtx(
    '/mnt/data00/share_data/agent_benchmark/doucling/filtered_gene_bc_matrices/GRCh38/',
    var_names='gene_symbols',
    cache=True
)

# Preprocess the data
sc.pp.normalize_total(adata, target_sum=1e4)
sc.pp.log1p(adata)
sc.pp.highly_variable_genes(adata, min_mean=0.0125, max_mean=3, min_disp=0.5)
adata = adata[:, adata.var.highly_variable]
sc.pp.scale(adata, max_value=10)
sc.tl.pca(adata, svd_solver='arpack')
sc.pp.neighbors(adata, n_neighbors=10, n_pcs=40)
sc.tl.umap(adata)

# Cluster the data
sc.tl.leiden(adata, resolution=0.5)

# Identify potential doublets based on cluster size
# Assuming doublets might form small distinct clusters
cluster_sizes = adata.obs['leiden'].value_counts()
potential_doublet_clusters = cluster_sizes[cluster_sizes < np.percentile(cluster_sizes, 10)].index

# Mark cells in these clusters as potential doublets
adata.obs['DouCLing'] = adata.obs['leiden'].isin(potential_doublet_clusters)

# Save the results to a CSV file
output_path = '/mnt/data00/share_data/results/autogen/gpt-4o/doucling/agent_output/doucling.csv'
adata.obs['DouCLing'].to_csv(output_path)

# Print the results
print(f"Doublet detection results saved to {output_path}")


# Verify the contents of the 'DouCLing' column in adata.obs
print(adata.obs['DouCLing'].head())


import pandas as pd

# Load the CSV file to verify its contents
output_path = '/mnt/data00/share_data/results/autogen/gpt-4o/doucling/agent_output/doucling.csv'
doubling_results = pd.read_csv(output_path, index_col=0)

# Display the first few rows of the CSV file
print(doubling_results.head())
