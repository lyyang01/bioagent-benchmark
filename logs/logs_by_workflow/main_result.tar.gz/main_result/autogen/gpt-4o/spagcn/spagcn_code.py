
import scanpy as sc
from PIL import Image

# Load the gene expression and spatial location data
adata = sc.read_h5ad('/mnt/data00/share_data/agent_benchmark/spagcn/sample_data.h5ad')

# Load the histology image data
histology_image = Image.open('/mnt/data00/share_data/agent_benchmark/spagcn/histology.tif')

# Display basic information about the loaded data
print("Gene expression data and spatial location loaded:")
print(adata)

print("\nHistology image data loaded:")
print(histology_image.format, histology_image.size, histology_image.mode)


import numpy as np

# Extract spatial coordinates from the dataset
# 'x2' and 'x3' are used for x_array and y_array
# 'x4' and 'x5' are used for x_pixel and y_pixel
x_array = adata.obs['x2'].values
y_array = adata.obs['x3'].values
x_pixel = adata.obs['x4'].values
y_pixel = adata.obs['x5'].values

# Combine the coordinates into a single array for further processing
spatial_coordinates_array = np.vstack((x_array, y_array)).T
spatial_coordinates_pixel = np.vstack((x_pixel, y_pixel)).T

# Display the extracted spatial coordinates
print("Spatial coordinates (array):")
print(spatial_coordinates_array[:5])  # Display first 5 for brevity

print("\nSpatial coordinates (pixel):")
print(spatial_coordinates_pixel[:5])  # Display first 5 for brevity


import SpaGCN

# Initialize the SpaGCN model
model = SpaGCN.SpaGCN()

# Calculate the adjacency matrix using spatial coordinates and histology image
# Here, we assume default values for beta and alpha, and use histology information
adj_matrix = SpaGCN.calculate_adj_matrix(
    x=x_array,
    y=y_array,
    x_pixel=x_pixel,
    y_pixel=y_pixel,
    image=np.array(histology_image),
    beta=49,  # Default value
    alpha=1,  # Default value
    histology=True
)

# Prefilter genes to retain those expressed in at least 3 cells
SpaGCN.prefilter_genes(adata, min_cells=3)

# Prefilter special genes
SpaGCN.prefilter_specialgenes(adata)

# Display the initialized model and adjacency matrix
print("SpaGCN model initialized.")
print("Adjacency matrix calculated with shape:", adj_matrix.shape)
