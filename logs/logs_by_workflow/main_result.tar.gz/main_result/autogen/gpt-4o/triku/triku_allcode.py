
import anndata as ad

# Load the single-cell RNA sequencing data into an AnnData object
file_path = '/mnt/data00/share_data/agent_benchmark/triku/pbmc3k_raw.h5ad'
pbmc = ad.read_h5ad(file_path)

# Verify the data has been loaded correctly
print(pbmc)


import scanpy as sc

# Preprocess the data: Normalize and scale
# Normalization: Adjust the total counts per cell to a common scale
sc.pp.normalize_total(pbmc, target_sum=1e4)

# Logarithmize the data: Log-transform the data to stabilize variance
sc.pp.log1p(pbmc)

# Scaling: Scale each gene to unit variance and zero mean
# This step is crucial for PCA and other downstream analyses
sc.pp.scale(pbmc, max_value=10)

# Verify preprocessing steps
print(pbmc)


import triku

# Apply Triku for feature selection
# Using the preprocessed AnnData object `pbmc`
triku.tl.triku(
    object_triku=pbmc,  # The AnnData object containing the preprocessed data
    n_features=None,    # Automatically determine the number of features to select
    use_raw=True,       # Use the raw data if available
    n_divisions=None,   # Automatically adjust the number of divisions
    s=-0.01,            # Correction factor for feature selection
    n_windows=75,       # Number of windows for median subtraction
    min_knn=6,          # Minimum number of expressed cells for convolution
    name=None,          # Store results in "triku_X"
    dist_conn='dist',   # Use distances for knn array construction
    distance_correction='median',  # Use median for distance correction
    verbose='warning'   # Set verbosity level
)

# Verify the results are stored in the AnnData object
print(pbmc.obsm['X_triku'])


import scanpy as sc
import triku

# Compute the neighborhood graph
# This step is necessary for Triku to perform feature selection
sc.pp.neighbors(pbmc, n_neighbors=10, use_rep='X_pca')

# Apply Triku for feature selection
triku.tl.triku(
    object_triku=pbmc,  # The AnnData object containing the preprocessed data
    n_features=None,    # Automatically determine the number of features to select
    use_raw=True,       # Use the raw data if available
    n_divisions=None,   # Automatically adjust the number of divisions
    s=-0.01,            # Correction factor for feature selection
    n_windows=75,       # Number of windows for median subtraction
    min_knn=6,          # Minimum number of expressed cells for convolution
    name=None,          # Store results in "triku_X"
    dist_conn='dist',   # Use distances for knn array construction
    distance_correction='median',  # Use median for distance correction
    verbose='warning'   # Set verbosity level
)

# Verify the results are stored in the AnnData object
print(pbmc.obsm['X_triku'])


import scanpy as sc
import triku

# Perform PCA to reduce dimensionality
sc.tl.pca(pbmc, svd_solver='arpack')

# Compute the neighborhood graph
# This step is necessary for Triku to perform feature selection
sc.pp.neighbors(pbmc, n_neighbors=10, use_rep='X_pca')

# Apply Triku for feature selection
triku.tl.triku(
    object_triku=pbmc,  # The AnnData object containing the preprocessed data
    n_features=None,    # Automatically determine the number of features to select
    use_raw=True,       # Use the raw data if available
    n_divisions=None,   # Automatically adjust the number of divisions
    s=-0.01,            # Correction factor for feature selection
    n_windows=75,       # Number of windows for median subtraction
    min_knn=6,          # Minimum number of expressed cells for convolution
    name=None,          # Store results in "triku_X"
    dist_conn='dist',   # Use distances for knn array construction
    distance_correction='median',  # Use median for distance correction
    verbose='warning'   # Set verbosity level
)

# Verify the results are stored in the AnnData object
print(pbmc.obsm['X_triku'])


import scanpy as sc
import triku

# Ensure the data is positive by using raw counts
# Set the raw attribute to the original counts if not already set
pbmc.raw = pbmc

# Perform PCA to reduce dimensionality
sc.tl.pca(pbmc, svd_solver='arpack')

# Compute the neighborhood graph
sc.pp.neighbors(pbmc, n_neighbors=10, use_rep='X_pca')

# Apply Triku for feature selection
triku.tl.triku(
    object_triku=pbmc,  # The AnnData object containing the preprocessed data
    n_features=None,    # Automatically determine the number of features to select
    use_raw=True,       # Use the raw data if available
    n_divisions=None,   # Automatically adjust the number of divisions
    s=-0.01,            # Correction factor for feature selection
    n_windows=75,       # Number of windows for median subtraction
    min_knn=6,          # Minimum number of expressed cells for convolution
    name=None,          # Store results in "triku_X"
    dist_conn='dist',   # Use distances for knn array construction
    distance_correction='median',  # Use median for distance correction
    verbose='warning'   # Set verbosity level
)

# Verify the results are stored in the AnnData object
print(pbmc.obsm['X_triku'])


import scanpy as sc
import triku

# Re-load the data to ensure we have the original counts
pbmc = ad.read_h5ad('/mnt/data00/share_data/agent_benchmark/triku/pbmc3k_raw.h5ad')

# Set the raw attribute to the original counts
pbmc.raw = pbmc

# Perform PCA to reduce dimensionality
sc.tl.pca(pbmc, svd_solver='arpack')

# Compute the neighborhood graph
sc.pp.neighbors(pbmc, n_neighbors=10, use_rep='X_pca')

# Apply Triku for feature selection
triku.tl.triku(
    object_triku=pbmc,  # The AnnData object containing the preprocessed data
    n_features=None,    # Automatically determine the number of features to select
    use_raw=True,       # Use the raw data if available
    n_divisions=None,   # Automatically adjust the number of divisions
    s=-0.01,            # Correction factor for feature selection
    n_windows=75,       # Number of windows for median subtraction
    min_knn=6,          # Minimum number of expressed cells for convolution
    name=None,          # Store results in "triku_X"
    dist_conn='dist',   # Use distances for knn array construction
    distance_correction='median',  # Use median for distance correction
    verbose='warning'   # Set verbosity level
)

# Verify the results are stored in the AnnData object
print(pbmc.obsm['X_triku'])
