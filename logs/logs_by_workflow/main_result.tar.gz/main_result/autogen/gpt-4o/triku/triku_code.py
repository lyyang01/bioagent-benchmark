
import anndata as ad

# Load the single-cell RNA sequencing data into an AnnData object
file_path = '/mnt/data00/share_data/agent_benchmark/triku/pbmc3k_raw.h5ad'
pbmc = ad.read_h5ad(file_path)

# Verify the data has been loaded correctly
print(pbmc)


import scanpy as sc

# Preprocess the data: Normalize and scale
# Normalization: Adjust the total counts per cell to a common scale
sc.pp.normalize_total(pbmc, target_sum=1e4)

# Logarithmize the data: Log-transform the data to stabilize variance
sc.pp.log1p(pbmc)

# Scaling: Scale each gene to unit variance and zero mean
# This step is crucial for PCA and other downstream analyses
sc.pp.scale(pbmc, max_value=10)

# Verify preprocessing steps
print(pbmc)
