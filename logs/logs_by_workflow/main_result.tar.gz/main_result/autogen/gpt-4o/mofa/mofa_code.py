
import muon as mu

# Load the dataset
file_path = '/mnt/data00/share_data/agent_benchmark/mofa/pbmc10k.h5mu'
mdata = mu.read_h5mu(file_path)

# Check the structure of the loaded data
print(mdata)
