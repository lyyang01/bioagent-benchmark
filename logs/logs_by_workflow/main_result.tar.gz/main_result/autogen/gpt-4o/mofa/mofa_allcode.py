
import anndata as ad

# Load the dataset
file_path = '/mnt/data00/share_data/agent_benchmark/mofa/pbmc10k.h5mu'
mdata = ad.read_h5mu(file_path)

# Check the structure of the loaded data
print(mdata)


import muon as mu

# Load the dataset
file_path = '/mnt/data00/share_data/agent_benchmark/mofa/pbmc10k.h5mu'
mdata = mu.read_h5mu(file_path)

# Check the structure of the loaded data
print(mdata)


import muon as mu
import scanpy as sc

# Assuming mdata is already loaded as a MuData object

# Preprocess RNA data
sc.pp.normalize_total(mdata['rna'])
sc.pp.log1p(mdata['rna'])
sc.pp.highly_variable_genes(mdata['rna'], n_top_genes=2000)

# Preprocess ATAC data
# Assuming ATAC data preprocessing is similar, adjust as necessary
sc.pp.normalize_total(mdata['atac'])
sc.pp.log1p(mdata['atac'])
sc.pp.highly_variable_genes(mdata['atac'], n_top_genes=2000)

# Run MOFA
mu.tl.mofa(
    mdata,
    use_var='highly_variable',  # Use highly variable features
    n_factors=15,               # Number of factors to learn
    center_groups=True,         # Center groups to zero mean
    scale_views=True,           # Scale views to unit variance
    n_iterations=1000,          # Number of iterations
    convergence_mode='medium',  # Convergence mode
    save_metadata=True          # Save metadata
)

# The results will be stored in mdata.obsm['X_mofa']


import muon as mu
import scanpy as sc

# Assuming mdata is already loaded as a MuData object

# Preprocess RNA data
sc.pp.filter_genes(mdata['rna'], min_cells=1)  # Filter out genes not expressed in any cells
sc.pp.normalize_total(mdata['rna'])
sc.pp.log1p(mdata['rna'])
sc.pp.highly_variable_genes(mdata['rna'], n_top_genes=2000)

# Preprocess ATAC data
sc.pp.filter_genes(mdata['atac'], min_cells=1)  # Filter out features not present in any cells
sc.pp.normalize_total(mdata['atac'])
sc.pp.log1p(mdata['atac'])
sc.pp.highly_variable_genes(mdata['atac'], n_top_genes=2000)

# Run MOFA
mu.tl.mofa(
    mdata,
    use_var='highly_variable',  # Use highly variable features
    n_factors=15,               # Number of factors to learn
    center_groups=True,         # Center groups to zero mean
    scale_views=True,           # Scale views to unit variance
    n_iterations=1000,          # Number of iterations
    convergence_mode='medium',  # Convergence mode
    save_metadata=True          # Save metadata
)

# The results will be stored in mdata.obsm['X_mofa']


import muon as mu
import scanpy as sc

# Assuming mdata is already loaded as a MuData object

# Preprocess RNA data
sc.pp.filter_genes(mdata['rna'], min_cells=1)  # Filter out genes not expressed in any cells
sc.pp.filter_cells(mdata['rna'], min_genes=1)  # Filter out cells with no expressed genes
sc.pp.normalize_total(mdata['rna'], target_sum=1e4)  # Normalize to a target sum
sc.pp.log1p(mdata['rna'])  # Log-transform the data
sc.pp.highly_variable_genes(mdata['rna'], n_top_genes=2000, flavor='seurat')  # Use 'seurat' flavor

# Preprocess ATAC data
sc.pp.filter_genes(mdata['atac'], min_cells=1)  # Filter out features not present in any cells
sc.pp.filter_cells(mdata['atac'], min_genes=1)  # Filter out cells with no expressed features
sc.pp.normalize_total(mdata['atac'], target_sum=1e4)  # Normalize to a target sum
sc.pp.log1p(mdata['atac'])  # Log-transform the data
sc.pp.highly_variable_genes(mdata['atac'], n_top_genes=2000, flavor='seurat')  # Use 'seurat' flavor

# Run MOFA
mu.tl.mofa(
    mdata,
    use_var='highly_variable',  # Use highly variable features
    n_factors=15,               # Number of factors to learn
    center_groups=True,         # Center groups to zero mean
    scale_views=True,           # Scale views to unit variance
    n_iterations=1000,          # Number of iterations
    convergence_mode='medium',  # Convergence mode
    save_metadata=True          # Save metadata
)

# The results will be stored in mdata.obsm['X_mofa']


import muon as mu
import scanpy as sc
import numpy as np

# Assuming mdata is already loaded as a MuData object

# Function to clean data
def clean_data(adata):
    # Remove genes with all zero values
    sc.pp.filter_genes(adata, min_cells=1)
    # Remove cells with all zero values
    sc.pp.filter_cells(adata, min_genes=1)
    # Fill NaN values with zero
    adata.X = np.nan_to_num(adata.X)

# Clean RNA data
clean_data(mdata['rna'])
sc.pp.normalize_total(mdata['rna'], target_sum=1e4)  # Normalize to a target sum
sc.pp.log1p(mdata['rna'])  # Log-transform the data
sc.pp.highly_variable_genes(mdata['rna'], n_top_genes=2000, flavor='seurat')  # Use 'seurat' flavor

# Clean ATAC data
clean_data(mdata['atac'])
sc.pp.normalize_total(mdata['atac'], target_sum=1e4)  # Normalize to a target sum
sc.pp.log1p(mdata['atac'])  # Log-transform the data
sc.pp.highly_variable_genes(mdata['atac'], n_top_genes=2000, flavor='seurat')  # Use 'seurat' flavor

# Run MOFA
mu.tl.mofa(
    mdata,
    use_var='highly_variable',  # Use highly variable features
    n_factors=15,               # Number of factors to learn
    center_groups=True,         # Center groups to zero mean
    scale_views=True,           # Scale views to unit variance
    n_iterations=1000,          # Number of iterations
    convergence_mode='medium',  # Convergence mode
    save_metadata=True          # Save metadata
)

# The results will be stored in mdata.obsm['X_mofa']


import muon as mu
import scanpy as sc
import numpy as np

# Assuming mdata is already loaded as a MuData object

# Function to clean data
def clean_data(adata):
    # Remove genes with all zero values
    sc.pp.filter_genes(adata, min_cells=1)
    # Remove cells with all zero values
    sc.pp.filter_cells(adata, min_genes=1)
    # Fill NaN values with zero
    adata.X = np.nan_to_num(adata.X)
    # Ensure no negative values after log transformation
    adata.X = np.maximum(adata.X, 0)

# Clean RNA data
clean_data(mdata['rna'])
sc.pp.normalize_total(mdata['rna'], target_sum=1e4)  # Normalize to a target sum
sc.pp.log1p(mdata['rna'])  # Log-transform the data
sc.pp.highly_variable_genes(mdata['rna'], n_top_genes=2000, flavor='seurat')  # Use 'seurat' flavor

# Clean ATAC data
clean_data(mdata['atac'])
sc.pp.normalize_total(mdata['atac'], target_sum=1e4)  # Normalize to a target sum
sc.pp.log1p(mdata['atac'])  # Log-transform the data
sc.pp.highly_variable_genes(mdata['atac'], n_top_genes=2000, flavor='seurat')  # Use 'seurat' flavor

# Run MOFA
mu.tl.mofa(
    mdata,
    use_var='highly_variable',  # Use highly variable features
    n_factors=15,               # Number of factors to learn
    center_groups=True,         # Center groups to zero mean
    scale_views=True,           # Scale views to unit variance
    n_iterations=1000,          # Number of iterations
    convergence_mode='medium',  # Convergence mode
    save_metadata=True          # Save metadata
)

# The results will be stored in mdata.obsm['X_mofa']
