
import scanpy as sc

# Load the single-cell RNA sequencing dataset
adata = sc.datasets.paul15()

# The dataset is now loaded into the AnnData object 'adata'


# Preprocess the data using the Zheng17 recipe
sc.pp.recipe_zheng17(adata)

# The data is now preprocessed and ready for further analysis


# Perform clustering using the Louvain algorithm
sc.pp.neighbors(adata)  # Compute the neighborhood graph of cells
sc.tl.louvain(adata)    # Run Louvain clustering

# The cluster labels are now stored in 'adata.obs['louvain']'


# Compute PAGA on the clustered data
sc.tl.paga(adata, groups='louvain')

# The PAGA results, including connectivity strengths between clusters, are stored in 'adata.uns['paga']['connectivities']'


import pandas as pd
import os

# Extract the PAGA connectivity matrix
connectivity_matrix = adata.uns['paga']['connectivities'].toarray()

# Convert the matrix to a DataFrame
connectivity_df = pd.DataFrame(connectivity_matrix)

# Define the output directory and file path
output_dir = '/mnt/data00/share_data/results/autogen/gpt-4o/paga/agent_output'
os.makedirs(output_dir, exist_ok=True)
output_file = os.path.join(output_dir, 'paga.csv')

# Save the DataFrame as a CSV file
connectivity_df.to_csv(output_file, index=False)

# The connectivity matrix is now saved as 'paga.csv' in the specified directory


# Verify the existence and content of the 'paga.csv' file
output_file = '/mnt/data00/share_data/results/autogen/gpt-4o/paga/agent_output/paga.csv'

# Check if the file exists
if os.path.exists(output_file):
    # Load the CSV file to verify its content
    loaded_df = pd.read_csv(output_file)
    print("File 'paga.csv' successfully saved and loaded. Here are the first few rows:")
    print(loaded_df.head())
else:
    print("File 'paga.csv' was not found in the specified directory.")
