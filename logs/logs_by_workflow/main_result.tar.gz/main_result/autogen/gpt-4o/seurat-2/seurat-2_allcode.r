
# Load the necessary libraries for data integration
library(Seurat)      # Seurat is used for single-cell RNA-seq data analysis and integration
library(SeuratData)  # SeuratData provides easy access to datasets for Seurat

# Ensure that the SeuratData package is installed and the dataset is available
# Install the SeuratData package if not already installed
if (!requireNamespace("SeuratData", quietly = TRUE)) {
  install.packages("SeuratData")
}

# Load the SeuratData package
library(SeuratData)

# Load the dataset for Slide-seq v2 of the mouse hippocampus
# This dataset will be used for spatial data integration
slide.seq <- LoadData('ssHippo')


# Load the scRNA-seq reference data from the specified file path
# This data will be used as a reference for integrating with the spatial data

# Define the file path for the scRNA-seq reference data
reference_file_path <- '/mnt/data00/share_data/agent_benchmark/seurat-2/mouse_hippocampus_reference.rds'

# Load the reference data into a Seurat object
scRNAseq_reference <- readRDS(reference_file_path)

# Check the structure of the loaded reference data
print(scRNAseq_reference)


# Preprocess the spatial data for integration
# Normalization, identification of highly variable features, and scaling are essential steps

# Normalize the spatial data
slide.seq <- NormalizeData(slide.seq, normalization.method = "LogNormalize", scale.factor = 10000)

# Identify highly variable features in the spatial data
slide.seq <- FindVariableFeatures(slide.seq, selection.method = "vst", nfeatures = 2000)

# Scale the spatial data
slide.seq <- ScaleData(slide.seq, features = VariableFeatures(object = slide.seq))

# Perform dimensionality reduction using PCA
slide.seq <- RunPCA(slide.seq, features = VariableFeatures(object = slide.seq))

# Visualize the PCA results to check the variance explained by each principal component
ElbowPlot(slide.seq)

# Note: Dimensionality reduction is performed to reduce the complexity of the data and facilitate integration


# Preprocess the scRNA-seq reference data for integration
# Normalization, identification of highly variable features, and scaling are essential steps

# Normalize the scRNA-seq reference data
scRNAseq_reference <- NormalizeData(scRNAseq_reference, normalization.method = "LogNormalize", scale.factor = 10000)

# Identify highly variable features in the scRNA-seq reference data
scRNAseq_reference <- FindVariableFeatures(scRNAseq_reference, selection.method = "vst", nfeatures = 2000)

# Scale the scRNA-seq reference data
scRNAseq_reference <- ScaleData(scRNAseq_reference, features = VariableFeatures(object = scRNAseq_reference))

# Perform dimensionality reduction using PCA
scRNAseq_reference <- RunPCA(scRNAseq_reference, features = VariableFeatures(object = scRNAseq_reference))

# Visualize the PCA results to check the variance explained by each principal component
ElbowPlot(scRNAseq_reference)

# Note: Dimensionality reduction is performed to reduce the complexity of the data and facilitate integration


# Check the structure of the scRNA-seq reference data to ensure it is a valid Seurat object
str(scRNAseq_reference)

# Proceed with preprocessing if the object structure is correct
if (inherits(scRNAseq_reference, "Seurat")) {
  # Normalize the scRNA-seq reference data
  scRNAseq_reference <- NormalizeData(scRNAseq_reference, normalization.method = "LogNormalize", scale.factor = 10000)
  
  # Identify highly variable features in the scRNA-seq reference data
  scRNAseq_reference <- FindVariableFeatures(scRNAseq_reference, selection.method = "vst", nfeatures = 2000)
  
  # Scale the scRNA-seq reference data
  scRNAseq_reference <- ScaleData(scRNAseq_reference, features = VariableFeatures(object = scRNAseq_reference))
  
  # Perform dimensionality reduction using PCA
  scRNAseq_reference <- RunPCA(scRNAseq_reference, features = VariableFeatures(object = scRNAseq_reference))
  
  # Visualize the PCA results to check the variance explained by each principal component
  ElbowPlot(scRNAseq_reference)
} else {
  stop("The loaded object is not a valid Seurat object. Please check the data file.")
}


# Check the available assays in the scRNA-seq reference data
print(Assays(scRNAseq_reference))

# Specify the default assay if necessary
DefaultAssay(scRNAseq_reference) <- "RNA"  # Assuming "RNA" is the correct assay; adjust if different

# Normalize the scRNA-seq reference data
scRNAseq_reference <- NormalizeData(scRNAseq_reference, normalization.method = "LogNormalize", scale.factor = 10000)

# Identify highly variable features in the scRNA-seq reference data
scRNAseq_reference <- FindVariableFeatures(scRNAseq_reference, selection.method = "vst", nfeatures = 2000)

# Scale the scRNA-seq reference data
scRNAseq_reference <- ScaleData(scRNAseq_reference, features = VariableFeatures(object = scRNAseq_reference))

# Perform dimensionality reduction using PCA
scRNAseq_reference <- RunPCA(scRNAseq_reference, features = VariableFeatures(object = scRNAseq_reference))

# Visualize the PCA results to check the variance explained by each principal component
ElbowPlot(scRNAseq_reference)


# Check the structure of the scRNA-seq reference data to ensure it is a valid Seurat object
str(scRNAseq_reference)

# List the assays available in the Seurat object
available_assays <- Assays(scRNAseq_reference)
print(available_assays)

# If the "RNA" assay is available, proceed with preprocessing
if ("RNA" %in% available_assays) {
  # Set the default assay to "RNA"
  DefaultAssay(scRNAseq_reference) <- "RNA"
  
  # Normalize the scRNA-seq reference data
  scRNAseq_reference <- NormalizeData(scRNAseq_reference, normalization.method = "LogNormalize", scale.factor = 10000)
  
  # Identify highly variable features in the scRNA-seq reference data
  scRNAseq_reference <- FindVariableFeatures(scRNAseq_reference, selection.method = "vst", nfeatures = 2000)
  
  # Scale the scRNA-seq reference data
  scRNAseq_reference <- ScaleData(scRNAseq_reference, features = VariableFeatures(object = scRNAseq_reference))
  
  # Perform dimensionality reduction using PCA
  scRNAseq_reference <- RunPCA(scRNAseq_reference, features = VariableFeatures(object = scRNAseq_reference))
  
  # Visualize the PCA results to check the variance explained by each principal component
  ElbowPlot(scRNAseq_reference)
} else {
  stop("The 'RNA' assay is not available in the Seurat object. Please check the data file.")
}


# Check the structure of the scRNA-seq reference data
str(scRNAseq_reference)

# List the assays available in the Seurat object
available_assays <- Assays(scRNAseq_reference)
print(available_assays)

# Attempt to access the RNA assay directly if available
if ("RNA" %in% available_assays) {
  # Set the default assay to "RNA"
  DefaultAssay(scRNAseq_reference) <- "RNA"
  
  # Normalize the scRNA-seq reference data
  scRNAseq_reference <- NormalizeData(scRNAseq_reference, normalization.method = "LogNormalize", scale.factor = 10000)
  
  # Identify highly variable features in the scRNA-seq reference data
  scRNAseq_reference <- FindVariableFeatures(scRNAseq_reference, selection.method = "vst", nfeatures = 2000)
  
  # Scale the scRNA-seq reference data
  scRNAseq_reference <- ScaleData(scRNAseq_reference, features = VariableFeatures(object = scRNAseq_reference))
  
  # Perform dimensionality reduction using PCA
  scRNAseq_reference <- RunPCA(scRNAseq_reference, features = VariableFeatures(object = scRNAseq_reference))
  
  # Visualize the PCA results to check the variance explained by each principal component
  ElbowPlot(scRNAseq_reference)
} else {
  stop("The 'RNA' assay is not available in the Seurat object. Please check the data file.")
}
