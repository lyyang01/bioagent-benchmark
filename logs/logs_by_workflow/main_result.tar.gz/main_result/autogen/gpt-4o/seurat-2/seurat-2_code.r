
# Load the necessary libraries for data integration
library(Seurat)      # Seurat is used for single-cell RNA-seq data analysis and integration
library(SeuratData)  # SeuratData provides easy access to datasets for Seurat

# Ensure that the SeuratData package is installed and the dataset is available
# Install the SeuratData package if not already installed
if (!requireNamespace("SeuratData", quietly = TRUE)) {
  install.packages("SeuratData")
}

# Load the SeuratData package
library(SeuratData)

# Load the dataset for Slide-seq v2 of the mouse hippocampus
# This dataset will be used for spatial data integration
slide.seq <- LoadData('ssHippo')


# Load the scRNA-seq reference data from the specified file path
# This data will be used as a reference for integrating with the spatial data

# Define the file path for the scRNA-seq reference data
reference_file_path <- '/mnt/data00/share_data/agent_benchmark/seurat-2/mouse_hippocampus_reference.rds'

# Load the reference data into a Seurat object
scRNAseq_reference <- readRDS(reference_file_path)

# Check the structure of the loaded reference data
print(scRNAseq_reference)


# Preprocess the spatial data for integration
# Normalization, identification of highly variable features, and scaling are essential steps

# Normalize the spatial data
slide.seq <- NormalizeData(slide.seq, normalization.method = "LogNormalize", scale.factor = 10000)

# Identify highly variable features in the spatial data
slide.seq <- FindVariableFeatures(slide.seq, selection.method = "vst", nfeatures = 2000)

# Scale the spatial data
slide.seq <- ScaleData(slide.seq, features = VariableFeatures(object = slide.seq))

# Perform dimensionality reduction using PCA
slide.seq <- RunPCA(slide.seq, features = VariableFeatures(object = slide.seq))

# Visualize the PCA results to check the variance explained by each principal component
ElbowPlot(slide.seq)

# Note: Dimensionality reduction is performed to reduce the complexity of the data and facilitate integration
