
import anndata

# Load the dataset into an AnnData object
adata = anndata.read_h5ad('/mnt/data00/share_data/agent_benchmark/graphst/mouse_anterior_posterior_brain_merged.h5ad')

# Verify the data has been loaded correctly
print(adata)


import scanpy as sc

# Pre-process the data for GraphST analysis

# Step 1: Normalize the data
# Normalize the data to account for differences in sequencing depth
sc.pp.normalize_total(adata, target_sum=1e4)

# Step 2: Logarithmize the data
# Log-transform the data to stabilize variance
sc.pp.log1p(adata)

# Step 3: Identify highly variable genes
# This step is crucial for dimensionality reduction and clustering
sc.pp.highly_variable_genes(adata, min_mean=0.0125, max_mean=3, min_disp=0.5)

# Step 4: Scale the data
# Scale the data to unit variance and zero mean
sc.pp.scale(adata, max_value=10)

# Step 5: Check metadata
# Ensure that the necessary metadata is present
print(adata.obs.head())

# Note: The above steps are general pre-processing steps for single-cell data.
# Depending on the specific requirements of GraphST, additional steps may be needed.


from GraphST.utils import clustering
from GraphST.GraphST import GraphST
from sklearn.decomposition import PCA

# Set up the GraphST model
device = 'cuda'  # Assuming GPU is available; change to 'cpu' if not
random_seed = 42

# Initialize the GraphST model
model = GraphST(adata, device=device, random_seed=random_seed)

# Train the GraphST model
model.train()

# Perform PCA to create an embedding
pca = PCA(n_components=20, random_state=random_seed)
adata.obsm['emb'] = pca.fit_transform(adata.X)

# Perform clustering using GraphST
n_clusters = 10
method = 'louvain'  # Options include 'louvain', 'leiden', and 'kmeans'

# Apply clustering to the AnnData object
clustering(adata, n_clusters=n_clusters, method=method)

# Store the clustering results in the 'domain' column of obs
adata.obs['domain'] = adata.obs['louvain']  # Assuming 'louvain' is used

# Note: Adjust the number of clusters and method based on your specific analysis needs.


# Define the output directory and file name
output_dir = '/mnt/data00/share_data/results/autogen/gpt-4o/graphst/agent_output'
output_file = f'{output_dir}/graphst.csv'

# Save the 'domain' column from obs to a CSV file
adata.obs['domain'].to_csv(output_file, index=True)

print(f"Results saved to {output_file}")
