
import anndata

# Load the dataset into an AnnData object
adata = anndata.read_h5ad('/mnt/data00/share_data/agent_benchmark/scpoli/GSE194122_openproblems_neurips2021_multiome_BMMC_processed.h5ad')

# Verify the data has been loaded correctly
print(adata)


import scanpy as sc

# Preprocess the ATAC-seq data
# Normalization and filtering are crucial steps for ATAC-seq data preprocessing

# Step 1: Normalize the data
# Here, we use log normalization which is common for single-cell data
sc.pp.normalize_total(adata, target_sum=1e4)
sc.pp.log1p(adata)

# Step 2: Filter the data
# Filtering out low-quality cells and peaks
# Assumption: We filter based on the number of counts and features
sc.pp.filter_cells(adata, min_counts=1000)  # Filter cells with fewer than 1000 counts
sc.pp.filter_genes(adata, min_cells=10)     # Filter peaks present in fewer than 10 cells

# Step 3: Identify highly variable features
# This step is important for dimensionality reduction and downstream analysis
sc.pp.highly_variable_genes(adata, min_mean=0.0125, max_mean=3, min_disp=0.5)

# Keep only the highly variable genes
adata = adata[:, adata.var.highly_variable]

# Step 4: Scale the data
# Scaling is necessary for PCA and other dimensionality reduction techniques
sc.pp.scale(adata, max_value=10)

# Verify preprocessing steps
print(adata)


from scarches.models.scpoli import scPoli
from scarches.models.scpoli._utils import reads_to_fragments

# Convert reads to fragments, which is a necessary preprocessing step for scPoli
adata_fragments = reads_to_fragments(adata, copy=True)

# Initialize the scPoli model
# Assumptions: 'batch' and 'cell_type' are the relevant keys in the dataset
scpoli_model = scPoli(
    adata=adata_fragments,
    condition_keys='batch',  # Assuming 'batch' is the condition key
    cell_type_keys='cell_type',  # Assuming 'cell_type' is the cell type key
    embedding_dims=50,  # Example embedding dimension
    recon_loss='nb'  # Using negative binomial loss for count data
)

# Train the scPoli model
# Assumptions: Using 100 epochs with 20 pretraining epochs
scpoli_model.train(
    n_epochs=100,
    pretraining_epochs=20,
    early_stopping_kwargs={'patience': 10, 'min_delta': 0.001},
    eta=1.0,
    prototype_training=True,
    unlabeled_prototype_training=True
)

# Get the latent representation
adata_latent = scpoli_model.get_latent(adata_fragments, mean=True)

# Verify the latent representation
print(adata_latent)


import numpy as np
from scarches.models.scpoli import scPoli
from scarches.models.scpoli._utils import reads_to_fragments

# Ensure adata.X is in a compatible format for arithmetic operations
adata.X = np.array(adata.X)

# Convert reads to fragments, which is a necessary preprocessing step for scPoli
adata_fragments = reads_to_fragments(adata, copy=True)

# Initialize the scPoli model
scpoli_model = scPoli(
    adata=adata_fragments,
    condition_keys='batch',  # Assuming 'batch' is the condition key
    cell_type_keys='cell_type',  # Assuming 'cell_type' is the cell type key
    embedding_dims=50,  # Example embedding dimension
    recon_loss='nb'  # Using negative binomial loss for count data
)

# Train the scPoli model
scpoli_model.train(
    n_epochs=100,
    pretraining_epochs=20,
    early_stopping_kwargs={'patience': 10, 'min_delta': 0.001},
    eta=1.0,
    prototype_training=True,
    unlabeled_prototype_training=True
)

# Get the latent representation
adata_latent = scpoli_model.get_latent(adata_fragments, mean=True)

# Verify the latent representation
print(adata_latent)


import numpy as np
from scarches.models.scpoli import scPoli
from scarches.models.scpoli._utils import reads_to_fragments

# Convert adata.X to a dense format if it's sparse
if not isinstance(adata.X, np.ndarray):
    adata.X = adata.X.toarray()

# Convert reads to fragments, which is a necessary preprocessing step for scPoli
adata_fragments = reads_to_fragments(adata, copy=True)

# Initialize the scPoli model
scpoli_model = scPoli(
    adata=adata_fragments,
    condition_keys='batch',  # Assuming 'batch' is the condition key
    cell_type_keys='cell_type',  # Assuming 'cell_type' is the cell type key
    embedding_dims=50,  # Example embedding dimension
    recon_loss='nb'  # Using negative binomial loss for count data
)

# Train the scPoli model
scpoli_model.train(
    n_epochs=100,
    pretraining_epochs=20,
    early_stopping_kwargs={'patience': 10, 'min_delta': 0.001},
    eta=1.0,
    prototype_training=True,
    unlabeled_prototype_training=True
)

# Get the latent representation
adata_latent = scpoli_model.get_latent(adata_fragments, mean=True)

# Verify the latent representation
print(adata_latent)


import numpy as np
from scarches.models.scpoli import scPoli
from scarches.models.scpoli._utils import reads_to_fragments

# Convert adata.X to a dense format if it's sparse
if not isinstance(adata.X, np.ndarray):
    adata.X = adata.X.toarray()

# Ensure that adata.X is a NumPy array
adata.X = np.array(adata.X)

# Convert reads to fragments, which is a necessary preprocessing step for scPoli
adata_fragments = reads_to_fragments(adata, copy=True)

# Initialize the scPoli model
scpoli_model = scPoli(
    adata=adata_fragments,
    condition_keys='batch',  # Assuming 'batch' is the condition key
    cell_type_keys='cell_type',  # Assuming 'cell_type' is the cell type key
    embedding_dims=50,  # Example embedding dimension
    recon_loss='nb'  # Using negative binomial loss for count data
)

# Train the scPoli model
scpoli_model.train(
    n_epochs=100,
    pretraining_epochs=20,
    early_stopping_kwargs={'patience': 10, 'min_delta': 0.001},
    eta=1.0,
    prototype_training=True,
    unlabeled_prototype_training=True
)

# Get the latent representation
adata_latent = scpoli_model.get_latent(adata_fragments, mean=True)

# Verify the latent representation
print(adata_latent)


import numpy as np
from scarches.models.scpoli import scPoli
from scarches.models.scpoli._utils import reads_to_fragments

# Convert adata.X to a dense format if it's sparse
if not isinstance(adata.X, np.ndarray):
    adata.X = adata.X.toarray()

# Convert adata.X to a dense NumPy array explicitly
adata.X = np.array(adata.X, dtype=np.float32)

# Convert reads to fragments, which is a necessary preprocessing step for scPoli
adata_fragments = reads_to_fragments(adata, copy=True)

# Initialize the scPoli model
scpoli_model = scPoli(
    adata=adata_fragments,
    condition_keys='batch',  # Assuming 'batch' is the condition key
    cell_type_keys='cell_type',  # Assuming 'cell_type' is the cell type key
    embedding_dims=50,  # Example embedding dimension
    recon_loss='nb'  # Using negative binomial loss for count data
)

# Train the scPoli model
scpoli_model.train(
    n_epochs=100,
    pretraining_epochs=20,
    early_stopping_kwargs={'patience': 10, 'min_delta': 0.001},
    eta=1.0,
    prototype_training=True,
    unlabeled_prototype_training=True
)

# Get the latent representation
adata_latent = scpoli_model.get_latent(adata_fragments, mean=True)

# Verify the latent representation
print(adata_latent)


import numpy as np
from scarches.models.scpoli import scPoli
from scarches.models.scpoli._utils import reads_to_fragments

# Convert adata.X to a dense format if it's sparse
if not isinstance(adata.X, np.ndarray):
    adata.X = adata.X.toarray()

# Ensure that adata.X is a dense NumPy array
adata.X = np.array(adata.X, dtype=np.float32)

# Manually handle the conversion to fragments
# This step is to ensure that the data is in the correct format
adata.layers['fragments'] = np.ceil(adata.X / 2)

# Initialize the scPoli model
scpoli_model = scPoli(
    adata=adata,
    condition_keys='batch',  # Assuming 'batch' is the condition key
    cell_type_keys='cell_type',  # Assuming 'cell_type' is the cell type key
    embedding_dims=50,  # Example embedding dimension
    recon_loss='nb'  # Using negative binomial loss for count data
)

# Train the scPoli model
scpoli_model.train(
    n_epochs=100,
    pretraining_epochs=20,
    early_stopping_kwargs={'patience': 10, 'min_delta': 0.001},
    eta=1.0,
    prototype_training=True,
    unlabeled_prototype_training=True
)

# Get the latent representation
adata_latent = scpoli_model.get_latent(adata, mean=True)

# Verify the latent representation
print(adata_latent)


import numpy as np
from scarches.models.scpoli import scPoli
from scarches.models.scpoli._utils import reads_to_fragments

# Convert adata.X to a dense format if it's sparse
if not isinstance(adata.X, np.ndarray):
    adata.X = adata.X.toarray()

# Convert adata.X to a dense NumPy array explicitly
adata.X = np.array(adata.X, dtype=np.float32)

# Manually handle the conversion to fragments
adata.layers['fragments'] = np.ceil(adata.X / 2)

# Initialize the scPoli model
scpoli_model = scPoli(
    adata=adata,
    condition_keys='batch',  # Assuming 'batch' is the condition key
    cell_type_keys='cell_type',  # Assuming 'cell_type' is the cell type key
    embedding_dims=50,  # Example embedding dimension
    recon_loss='nb'  # Using negative binomial loss for count data
)

# Train the scPoli model
scpoli_model.train(
    n_epochs=100,
    pretraining_epochs=20,
    early_stopping_kwargs={'patience': 10},  # Adjusted early stopping parameters
    eta=1.0,
    prototype_training=True,
    unlabeled_prototype_training=True
)

# Get the latent representation
adata_latent = scpoli_model.get_latent(adata, mean=True)

# Verify the latent representation
print(adata_latent)


import numpy as np
from scarches.models.scpoli import scPoli
from scarches.models.scpoli._utils import reads_to_fragments

# Convert adata.X to a dense format if it's sparse
if not isinstance(adata.X, np.ndarray):
    adata.X = adata.X.toarray()

# Convert adata.X to a dense NumPy array explicitly
adata.X = np.array(adata.X, dtype=np.float32)

# Check for NaN values and replace them with zero
adata.X = np.nan_to_num(adata.X)

# Manually handle the conversion to fragments
adata.layers['fragments'] = np.ceil(adata.X / 2)

# Initialize the scPoli model
scpoli_model = scPoli(
    adata=adata,
    condition_keys='batch',  # Assuming 'batch' is the condition key
    cell_type_keys='cell_type',  # Assuming 'cell_type' is the cell type key
    embedding_dims=50,  # Example embedding dimension
    recon_loss='nb'  # Using negative binomial loss for count data
)

# Train the scPoli model
scpoli_model.train(
    n_epochs=100,
    pretraining_epochs=20,
    early_stopping_kwargs={'patience': 10},  # Adjusted early stopping parameters
    eta=1.0,
    prototype_training=True,
    unlabeled_prototype_training=True
)

# Get the latent representation
adata_latent = scpoli_model.get_latent(adata, mean=True)

# Verify the latent representation
print(adata_latent)


import numpy as np
from scarches.models.scpoli import scPoli
from scarches.models.scpoli._utils import reads_to_fragments

# Convert adata.X to a dense format if it's sparse
if not isinstance(adata.X, np.ndarray):
    adata.X = adata.X.toarray()

# Convert adata.X to a dense NumPy array explicitly
adata.X = np.array(adata.X, dtype=np.float32)

# Check for NaN values and replace them with zero
adata.X = np.nan_to_num(adata.X)

# Normalize the data to ensure stability during training
adata.X = (adata.X - np.mean(adata.X, axis=0)) / np.std(adata.X, axis=0)

# Manually handle the conversion to fragments
adata.layers['fragments'] = np.ceil(adata.X / 2)

# Initialize the scPoli model
scpoli_model = scPoli(
    adata=adata,
    condition_keys='batch',  # Assuming 'batch' is the condition key
    cell_type_keys='cell_type',  # Assuming 'cell_type' is the cell type key
    embedding_dims=50,  # Example embedding dimension
    recon_loss='nb'  # Using negative binomial loss for count data
)

# Train the scPoli model
scpoli_model.train(
    n_epochs=100,
    pretraining_epochs=20,
    early_stopping_kwargs={'patience': 10},  # Adjusted early stopping parameters
    eta=1.0,
    prototype_training=True,
    unlabeled_prototype_training=True
)

# Get the latent representation
adata_latent = scpoli_model.get_latent(adata, mean=True)

# Verify the latent representation
print(adata_latent)


import numpy as np
from scarches.models.scpoli import scPoli
from scarches.models.scpoli._utils import reads_to_fragments

# Convert adata.X to a dense format if it's sparse
if not isinstance(adata.X, np.ndarray):
    adata.X = adata.X.toarray()

# Convert adata.X to a dense NumPy array explicitly
adata.X = np.array(adata.X, dtype=np.float32)

# Check for NaN values and replace them with zero
adata.X = np.nan_to_num(adata.X)

# Normalize the data to ensure stability during training
adata.X = (adata.X - np.mean(adata.X, axis=0)) / (np.std(adata.X, axis=0) + 1e-8)

# Manually handle the conversion to fragments
adata.layers['fragments'] = np.ceil(adata.X / 2)

# Initialize the scPoli model
scpoli_model = scPoli(
    adata=adata,
    condition_keys='batch',  # Assuming 'batch' is the condition key
    cell_type_keys='cell_type',  # Assuming 'cell_type' is the cell type key
    embedding_dims=50,  # Example embedding dimension
    recon_loss='nb'  # Using negative binomial loss for count data
)

# Train the scPoli model
scpoli_model.train(
    n_epochs=100,
    pretraining_epochs=20,
    early_stopping_kwargs={'patience': 10},  # Adjusted early stopping parameters
    eta=1.0,
    prototype_training=True,
    unlabeled_prototype_training=True
)

# Get the latent representation
adata_latent = scpoli_model.get_latent(adata, mean=True)

# Verify the latent representation
print(adata_latent)


import numpy as np
from scarches.models.scpoli import scPoli
from scarches.models.scpoli._utils import reads_to_fragments

# Convert adata.X to a dense format if it's sparse
if not isinstance(adata.X, np.ndarray):
    adata.X = adata.X.toarray()

# Convert adata.X to a dense NumPy array explicitly
adata.X = np.array(adata.X, dtype=np.float32)

# Check for NaN values and replace them with zero
adata.X = np.nan_to_num(adata.X)

# Normalize the data to ensure stability during training
adata.X = (adata.X - np.mean(adata.X, axis=0)) / (np.std(adata.X, axis=0) + 1e-8)

# Manually handle the conversion to fragments
adata.layers['fragments'] = np.ceil(adata.X / 2)

# Initialize the scPoli model
scpoli_model = scPoli(
    adata=adata,
    condition_keys='batch',  # Assuming 'batch' is the condition key
    cell_type_keys='cell_type',  # Assuming 'cell_type' is the cell type key
    embedding_dims=50,  # Example embedding dimension
    recon_loss='nb'  # Using negative binomial loss for count data
)

# Train the scPoli model
scpoli_model.train(
    n_epochs=100,
    pretraining_epochs=20,
    early_stopping_kwargs={'patience': 10},  # Adjusted early stopping parameters
    eta=1.0,
    prototype_training=True,
    unlabeled_prototype_training=True
)

# Get the latent representation
adata_latent = scpoli_model.get_latent(adata, mean=True)

# Verify the latent representation
print(adata_latent)
