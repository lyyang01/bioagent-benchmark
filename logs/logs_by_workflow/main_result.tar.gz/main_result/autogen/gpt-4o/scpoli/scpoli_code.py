
import anndata

# Load the dataset into an AnnData object
adata = anndata.read_h5ad('/mnt/data00/share_data/agent_benchmark/scpoli/GSE194122_openproblems_neurips2021_multiome_BMMC_processed.h5ad')

# Verify the data has been loaded correctly
print(adata)


import scanpy as sc

# Preprocess the ATAC-seq data
# Normalization and filtering are crucial steps for ATAC-seq data preprocessing

# Step 1: Normalize the data
# Here, we use log normalization which is common for single-cell data
sc.pp.normalize_total(adata, target_sum=1e4)
sc.pp.log1p(adata)

# Step 2: Filter the data
# Filtering out low-quality cells and peaks
# Assumption: We filter based on the number of counts and features
sc.pp.filter_cells(adata, min_counts=1000)  # Filter cells with fewer than 1000 counts
sc.pp.filter_genes(adata, min_cells=10)     # Filter peaks present in fewer than 10 cells

# Step 3: Identify highly variable features
# This step is important for dimensionality reduction and downstream analysis
sc.pp.highly_variable_genes(adata, min_mean=0.0125, max_mean=3, min_disp=0.5)

# Keep only the highly variable genes
adata = adata[:, adata.var.highly_variable]

# Step 4: Scale the data
# Scaling is necessary for PCA and other dimensionality reduction techniques
sc.pp.scale(adata, max_value=10)

# Verify preprocessing steps
print(adata)
