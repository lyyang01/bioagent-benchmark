
import zipfile
import os

# Define the path to the zip file and the directory to extract to
zip_file_path = '/mnt/data00/share_data/agent_benchmark/cellphonedb/cellphonedb.zip'
extract_to_dir = '/mnt/data00/share_data/agent_benchmark/cellphonedb/'

# Ensure the extraction directory exists
os.makedirs(extract_to_dir, exist_ok=True)

# Unzip the file
with zipfile.ZipFile(zip_file_path, 'r') as zip_ref:
    zip_ref.extractall(extract_to_dir)

print("Unzipping completed. Files are extracted to:", extract_to_dir)


import pandas as pd

# Define the path to the metadata file
metadata_file_path = '/mnt/data00/share_data/agent_benchmark/cellphonedb/data/metadata.tsv'

# Load the metadata file into a DataFrame
metadata_df = pd.read_csv(metadata_file_path, sep='\t')

# Display the first few rows of the metadata to verify loading
print(metadata_df.head())


import anndata

# Define the path to the normalized counts file
normalized_counts_file_path = '/mnt/data00/share_data/agent_benchmark/cellphonedb/data/normalised_log_counts.h5ad'

# Load the normalized counts file into an AnnData object
adata = anndata.read_h5ad(normalized_counts_file_path)

# Display the shape of the AnnData object to verify loading
print("AnnData shape (cells, genes):", adata.shape)


# Define the path to the microenvironment file
microenvironment_file_path = '/mnt/data00/share_data/agent_benchmark/cellphonedb/data/microenvironment.tsv'

# Load the microenvironment file into a DataFrame
microenvironment_df = pd.read_csv(microenvironment_file_path, sep='\t')

# Display the first few rows of the microenvironment data to verify loading
print(microenvironment_df.head())


# Define the path to the active transcription factors file
active_tfs_file_path = '/mnt/data00/share_data/agent_benchmark/cellphonedb/data/active_TFs.tsv'

# Load the active transcription factors file into a DataFrame
active_tfs_df = pd.read_csv(active_tfs_file_path, sep='\t')

# Display the first few rows of the active transcription factors data to verify loading
print(active_tfs_df.head())


import cellphonedb
import os

# Define paths for input and output
output_path = '/mnt/data00/share_data/results/autogen/gpt-4o/cellphonedb/agent_output'
os.makedirs(output_path, exist_ok=True)

# Prepare the input files for CellphoneDB
metadata_file = '/mnt/data00/share_data/agent_benchmark/cellphonedb/data/metadata.tsv'
counts_file = '/mnt/data00/share_data/agent_benchmark/cellphonedb/data/normalised_log_counts.h5ad'

# Run CellphoneDB analysis
# Note: CellphoneDB requires a command-line interface to run. Here, we simulate the command execution.
os.system(f"cellphonedb method statistical_analysis {metadata_file} {counts_file} --output-path={output_path}")

# Load the results
deconvoluted_results_path = os.path.join(output_path, 'deconvoluted.txt')
cpdb_results = {}
cpdb_results['deconvoluted'] = pd.read_csv(deconvoluted_results_path, sep='\t')

# Save the deconvoluted results as 'cellphonedb.csv'
cpdb_results['deconvoluted'].to_csv(os.path.join(output_path, 'cellphonedb.csv'), index=False)

print("CellphoneDB analysis completed and results saved.")


import os

# Define paths for input and output
output_path = '/mnt/data00/share_data/results/autogen/gpt-4o/cellphonedb/agent_output'
os.makedirs(output_path, exist_ok=True)

# Prepare the input files for CellphoneDB
metadata_file = '/mnt/data00/share_data/agent_benchmark/cellphonedb/data/metadata.tsv'
counts_file = '/mnt/data00/share_data/agent_benchmark/cellphonedb/data/normalised_log_counts.h5ad'

# Run CellphoneDB analysis
# Note: CellphoneDB requires a command-line interface to run. Here, we simulate the command execution.
command = f"cellphonedb method statistical_analysis {metadata_file} {counts_file} --output-path={output_path}"
os.system(command)

# Check if the expected output file exists
deconvoluted_results_path = os.path.join(output_path, 'deconvoluted.txt')
if os.path.exists(deconvoluted_results_path):
    cpdb_results = {}
    cpdb_results['deconvoluted'] = pd.read_csv(deconvoluted_results_path, sep='\t')

    # Save the deconvoluted results as 'cellphonedb.csv'
    cpdb_results['deconvoluted'].to_csv(os.path.join(output_path, 'cellphonedb.csv'), index=False)
    print("CellphoneDB analysis completed and results saved.")
else:
    print("CellphoneDB analysis did not produce the expected output file.")




