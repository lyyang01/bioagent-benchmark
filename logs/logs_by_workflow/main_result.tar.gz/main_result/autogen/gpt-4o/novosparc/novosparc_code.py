
import pandas as pd

# Load the Drosophila scRNA-seq dataset
scRNAseq_data_path = '/mnt/data00/share_data/agent_benchmark/novosparc/datasets/drosophila_scRNAseq/dge_normalized.txt'

# Read the data into a pandas DataFrame
# Assuming the data is tab-delimited and the first row contains headers
scRNAseq_data = pd.read_csv(scRNAseq_data_path, sep='\t', header=0)

# Display the first few rows of the dataset to verify loading
print(scRNAseq_data.head())

# Biological assumption: The dataset contains normalized gene expression values for single cells.
# Each row represents a gene, and each column represents a single cell.


# Load the reference atlas
reference_atlas_path = '/mnt/data00/share_data/agent_benchmark/novosparc/datasets/bdtnp/geometry.txt'

# Read the reference atlas data into a pandas DataFrame
# Assuming the data is tab-delimited and the first row contains headers
reference_atlas = pd.read_csv(reference_atlas_path, sep='\t', header=0)

# Display the first few rows of the reference atlas to verify loading
print(reference_atlas.head())

# Biological assumption: The reference atlas contains spatial coordinates for each reference point.
# Each row represents a spatial location, and columns may include coordinates and other metadata.


import novosparc
import scanpy as sc

# Preprocess the scRNA-seq data
# Convert the pandas DataFrame to an AnnData object, which is required by novoSpaRc
adata = sc.AnnData(scRNAseq_data)

# Preprocess the reference atlas
# Split the single column into separate columns for x, y, and z coordinates
reference_atlas[['xcoord', 'ycoord', 'zcoord']] = reference_atlas.iloc[:, 0].str.split(expand=True)

# Extract spatial coordinates from the reference atlas
spatial_coords = reference_atlas[['xcoord', 'ycoord', 'zcoord']].values.astype(float)

# Biological assumption: The spatial coordinates are in a 3D space, which is typical for spatial transcriptomics data.
# Ensure the data is compatible with novoSpaRc by checking dimensions and data types
print(f"scRNA-seq data shape: {adata.shape}")
print(f"Reference atlas shape: {spatial_coords.shape}")

# Normalize or transform the data if necessary
# Here, we assume the data is already normalized as per the file name 'dge_normalized.txt'
# If further normalization is needed, it can be done using Scanpy's preprocessing functions

# Biological assumption: The gene expression data is already normalized, which is crucial for accurate spatial reconstruction.


# Configure novoSpaRc for reconstruction
# Initialize the tissue using the dataset and locations
# Assuming we are using all genes as markers for simplicity

# Define the output folder for results
output_folder = '/mnt/data00/share_data/results/autogen/gpt-4o/novosparc/agent_output'

# Initialize the Tissue object with the scRNA-seq data and reference atlas
tissue = novosparc.cm.Tissue(
    dataset=adata,                # Anndata object for the single cell data
    locations=spatial_coords,     # Target space locations (spatial coordinates)
    atlas_matrix=None,            # Optional atlas matrix, not used here
    markers_to_use=None,          # Use all genes as markers
    output_folder=output_folder   # Folder path to save the plots and data
)

# Biological assumption: All genes are used as markers for spatial reconstruction.
# This setup assumes that the spatial coordinates are directly used for mapping the gene expression data.


# Run novoSpaRc to perform the reconstruction
# Execute the reconstruction process with the required parameter 'alpha_linear'
# 'alpha_linear' is a parameter that controls the balance between linear and non-linear reconstruction

alpha_linear = 0.5  # Example value, adjust based on specific requirements

tissue.reconstruct(alpha_linear=alpha_linear)

# Biological assumption: The 'alpha_linear' parameter influences the reconstruction method, balancing between linear and non-linear approaches.
# This step is crucial for understanding the spatial organization of gene expression in the tissue.


# Save the output results
# The results are automatically saved in the specified output folder during the reconstruction process

# Verify that the output files are saved correctly
import os

# List the files in the output directory to ensure they are saved
output_files = os.listdir(output_folder)
print("Output files saved in the directory:")
for file in output_files:
    print(file)

# Biological assumption: The output files contain the reconstructed spatial gene expression data,
# which can be used for further analysis and visualization.


# Verify the results
# Check the output files to ensure they contain the expected reconstructed gene expression data

# Load one of the output files to inspect its contents
# Assuming the output files are in a format that can be read by pandas, such as CSV or TXT

# Example: Load a specific output file (replace 'output_file.txt' with the actual file name)
output_file_path = os.path.join(output_folder, 'output_file.txt')  # Replace with actual file name

# Check if the file exists
if os.path.exists(output_file_path):
    reconstructed_data = pd.read_csv(output_file_path, sep='\t', header=0)
    print("Reconstructed data:")
    print(reconstructed_data.head())
else:
    print("Output file not found. Please check the output directory.")

# Biological assumption: The reconstructed data should reflect the spatial distribution of gene expression
# as mapped onto the reference atlas. This verification step ensures the reconstruction process was successful.


# Documenting the process and results

# Create a text file to record the process and results
documentation_path = '/mnt/data00/share_data/results/autogen/gpt-4o/novosparc/agent_output/documentation.txt'

with open(documentation_path, 'w') as doc_file:
    doc_file.write("NovoSpaRc Reconstruction Process Documentation\n")
    doc_file.write("=============================================\n\n")
    
    # Record the steps taken
    doc_file.write("Steps Taken:\n")
    doc_file.write("1. Loaded the Drosophila scRNA-seq dataset from 'dge_normalized.txt'.\n")
    doc_file.write("2. Loaded the reference atlas from 'geometry.txt'.\n")
    doc_file.write("3. Preprocessed the datasets to ensure compatibility with novoSpaRc.\n")
    doc_file.write("4. Configured novoSpaRc with the necessary parameters for reconstruction.\n")
    doc_file.write("5. Executed the novoSpaRc algorithm to perform the reconstruction.\n")
    doc_file.write("6. Attempted to save and verify the output results.\n\n")
    
    # Record any parameters used
    doc_file.write("Parameters Used:\n")
    doc_file.write(f"Alpha Linear: {alpha_linear}\n")
    doc_file.write("Output Folder: '/mnt/data00/share_data/results/autogen/gpt-4o/novosparc/agent_output'\n\n")
    
    # Record the outcomes
    doc_file.write("Outcomes:\n")
    doc_file.write("The reconstruction process was executed, but no output files were found in the specified directory.\n")
    doc_file.write("Further investigation is needed to ensure the results are saved correctly.\n\n")
    
    # Summary of findings
    doc_file.write("Summary of Findings:\n")
    doc_file.write("The process involved mapping single-cell gene expression data onto a spatial reference atlas.\n")
    doc_file.write("The expected outcome was a spatially reconstructed gene expression dataset.\n")
    doc_file.write("However, the absence of output files suggests a need for troubleshooting the saving mechanism.\n")

# Biological assumption: Documenting the process helps in understanding the workflow and identifying any issues for future improvements.
