
# Import necessary function from pydeseq2.utils
from pydeseq2.utils import load_example_data

# Load the synthetic dataset for count matrix
counts_df = load_example_data(modality='raw_counts', dataset='synthetic', debug=False)

# Load the synthetic dataset for metadata
metadata = load_example_data(modality='metadata', dataset='synthetic', debug=False)

# Display the first few rows of the loaded data to verify
print("Counts DataFrame:")
print(counts_df.head())

print("\nMetadata DataFrame:")
print(metadata.head())


# Verify the structure and content of the count matrix and metadata
# Ensure that the count matrix contains raw counts and is formatted correctly
print("Counts DataFrame Info:")
print(counts_df.info())

# Ensure that the metadata includes necessary experimental conditions and sample information
print("\nMetadata DataFrame Info:")
print(metadata.info())

# Check for any missing values in the count matrix and metadata
print("\nMissing values in Counts DataFrame:")
print(counts_df.isnull().sum())

print("\nMissing values in Metadata DataFrame:")
print(metadata.isnull().sum())

# Ensure that the row names of the count matrix match the sample identifiers in the metadata
assert all(counts_df.index == metadata.index), "Sample identifiers do not match between counts and metadata."

# The data is now verified and ready for DESeq2 analysis


# Import necessary classes from pydeseq2
from pydeseq2.dds import DeseqDataSet
from pydeseq2.ds import DeseqStats

# Create a DeseqDataSet object using the count matrix and metadata
dds = DeseqDataSet(
    counts=counts_df,
    metadata=metadata,
    design='~condition'  # Assuming 'condition' is the factor of interest
)

# Perform the DESeq2 analysis pipeline
dds.deseq2()

# Create a DeseqStats object for statistical testing
# Assuming we want to compare condition levels, e.g., 'A' vs 'B'
stats = DeseqStats(
    dds,
    contrast=['condition', 'A', 'B']
)

# Run the statistical analysis
stats.summary()

# Extract the results DataFrame
results_df = stats.results_df

# Store the results in dds.X
dds.X = results_df

# Save the results to a CSV file
output_path = '/mnt/data00/share_data/results/autogen/gpt-4o/deseq2/agent_output/deseq2.csv'
results_df.to_csv(output_path, index=False)

print(f"Results saved to {output_path}")


# Import necessary classes from pydeseq2
from pydeseq2.dds import DeseqDataSet
from pydeseq2.ds import DeseqStats

# Create a DeseqDataSet object using the count matrix and metadata
dds = DeseqDataSet(
    counts=counts_df,
    metadata=metadata,
    design='~condition'  # Assuming 'condition' is the factor of interest
)

# Perform the DESeq2 analysis pipeline
dds.deseq2()

# Create a DeseqStats object for statistical testing
# Assuming we want to compare condition levels, e.g., 'A' vs 'B'
stats = DeseqStats(
    dds,
    contrast=['condition', 'A', 'B']
)

# Run the statistical analysis
stats.summary()

# Extract the results DataFrame
results_df = stats.results_df

# Save the results to a CSV file
output_path = '/mnt/data00/share_data/results/autogen/gpt-4o/deseq2/agent_output/deseq2.csv'
results_df.to_csv(output_path, index=False)

print(f"Results saved to {output_path}")

