
import scanpy as sc

# Load the data from the HDF5 files into AnnData objects
adata1 = sc.read_10x_h5('/mnt/data00/share_data/agent_benchmark/leiden/s1d1_filtered_feature_bc_matrix.h5')
adata3 = sc.read_10x_h5('/mnt/data00/share_data/agent_benchmark/leiden/s1d3_filtered_feature_bc_matrix.h5')

# Concatenate the two datasets into a single AnnData object for joint analysis
adata = adata1.concatenate(adata3)

# Check the structure of the loaded data
print(adata)


import scanpy as sc

# Load the data from the HDF5 files into AnnData objects
adata1 = sc.read_10x_h5('/mnt/data00/share_data/agent_benchmark/leiden/s1d1_filtered_feature_bc_matrix.h5')
adata3 = sc.read_10x_h5('/mnt/data00/share_data/agent_benchmark/leiden/s1d3_filtered_feature_bc_matrix.h5')

# Ensure unique indices by appending a suffix to each dataset's barcodes
adata1.obs_names = [f"{name}_s1d1" for name in adata1.obs_names]
adata3.obs_names = [f"{name}_s1d3" for name in adata3.obs_names]

# Concatenate the two datasets into a single AnnData object for joint analysis
adata = adata1.concatenate(adata3, batch_key='batch', batch_categories=['s1d1', 's1d3'])

# Check the structure of the loaded data
print(adata)


import scanpy as sc

# Load the data from the HDF5 files into AnnData objects
adata1 = sc.read_10x_h5('/mnt/data00/share_data/agent_benchmark/leiden/s1d1_filtered_feature_bc_matrix.h5')
adata3 = sc.read_10x_h5('/mnt/data00/share_data/agent_benchmark/leiden/s1d3_filtered_feature_bc_matrix.h5')

# Ensure unique cell barcodes by appending a suffix to each dataset's barcodes
adata1.obs_names = [f"{name}_s1d1" for name in adata1.obs_names]
adata3.obs_names = [f"{name}_s1d3" for name in adata3.obs_names]

# Ensure unique gene names by appending a suffix to each dataset's gene names
adata1.var_names_make_unique()
adata3.var_names_make_unique()

# Concatenate the two datasets into a single AnnData object for joint analysis
adata = adata1.concatenate(adata3, batch_key='batch', batch_categories=['s1d1', 's1d3'])

# Check the structure of the loaded data
print(adata)


import scanpy as sc

# Normalize the data
sc.pp.normalize_total(adata, target_sum=1e4)
# Logarithmize the data
sc.pp.log1p(adata)

# Identify highly variable genes
sc.pp.highly_variable_genes(adata, n_top_genes=2000, flavor='seurat')

# Filter the data to keep only highly variable genes
adata = adata[:, adata.var['highly_variable']]

# Scale the data to ensure each gene contributes equally
sc.pp.scale(adata, max_value=10)

# Check the structure of the preprocessed data
print(adata)


import scanpy as sc

# Perform PCA on the preprocessed data
sc.tl.pca(adata, svd_solver='arpack')

# Plot the explained variance ratio to determine the number of components to retain
sc.pl.pca_variance_ratio(adata, log=True)

# Check the structure of the data after PCA
print(adata)


import scanpy as sc

# Construct a k-nearest neighbors graph
sc.pp.neighbors(adata, n_neighbors=15, n_pcs=40)

# Check the structure of the data after constructing the KNN graph
print(adata)


import scanpy as sc

# Apply the Leiden clustering algorithm
sc.tl.leiden(adata, resolution=1.0)

# Check the structure of the data after clustering
print(adata.obs['leiden'].value_counts())


import scanpy as sc

# Perform UMAP for visualization
sc.tl.umap(adata)

# Store the UMAP embeddings in the AnnData object
umap_embeddings = adata.obsm['X_umap']

# Check the structure of the data after UMAP
print(umap_embeddings)


import pandas as pd

# Convert the UMAP embeddings to a DataFrame
umap_df = pd.DataFrame(adata.obsm['X_umap'], index=adata.obs_names, columns=['UMAP1', 'UMAP2'])

# Save the DataFrame to a CSV file
umap_df.to_csv('/mnt/data00/share_data/results/autogen/gpt-4o/leiden/agent_output/leiden.csv')

print("UMAP embeddings saved to 'leiden.csv'.")



# Define the documentation content
documentation = """
# Single-Cell RNA Sequencing Data Analysis Using Leiden Clustering

## Data Loading
- Loaded datasets from HDF5 files: 's1d1_filtered_feature_bc_matrix.h5' and 's1d3_filtered_feature_bc_matrix.h5'.
- Concatenated datasets into a single AnnData object.

## Preprocessing
- Normalized data to a target sum of 10,000.
- Log-transformed the data.
- Identified top 2000 highly variable genes using the 'seurat' method.
- Scaled the data to ensure equal contribution from each gene.

## Dimensionality Reduction
- Performed PCA, retaining 40 principal components based on variance explained.

## Graph Construction
- Constructed a k-nearest neighbors graph with 15 neighbors using 40 principal components.

## Clustering
- Applied Leiden clustering with a resolution of 1.0, resulting in 24 clusters.

## Visualization
- Computed UMAP embeddings for visualization.
- Stored UMAP embeddings in 'adata.obsm['X_umap']'.

## Results Saving
- Saved UMAP embeddings to 'leiden.csv' in '/mnt/data00/share_data/results/autogen/gpt-4o/leiden/agent_output'.

## Parameters Summary
- PCA: 40 components
- KNN: 15 neighbors
- Leiden Resolution: 1.0

## Notes
- Future work may involve adjusting the resolution parameter for different clustering granularity.
- Consider exploring additional visualization techniques or integrating metadata for enhanced analysis.
"""

# Save the documentation to a text file
with open('/mnt/data00/share_data/results/autogen/gpt-4o/leiden/agent_output/documentation.txt', 'w') as file:
    file.write(documentation)

print("Documentation saved to 'documentation.txt'.")
