
import anndata as ad

# Load the single-cell RNA sequencing dataset into an AnnData object
# The dataset is expected to be in H5AD format, which is commonly used for single-cell data
adata = ad.read_h5ad('/mnt/data00/share_data/agent_benchmark/cellrank/datasets/endocrinogenesis_day15.5_raw.h5ad')

# Verify the structure of the loaded data
print(adata)


import scvelo as scv

# Preprocess the data
# Normalize the data and log-transform it
scv.pp.filter_and_normalize(adata, min_shared_counts=20, n_top_genes=2000)
scv.pp.moments(adata, n_pcs=30, n_neighbors=30)

# Verify RNA velocity information
# Check if 'spliced' and 'unspliced' layers are present, which are necessary for RNA velocity analysis
if 'spliced' in adata.layers and 'unspliced' in adata.layers:
    print("RNA velocity information is present and properly formatted.")
else:
    raise ValueError("RNA velocity information is missing or improperly formatted.")

# Display the updated AnnData object to confirm preprocessing
print(adata)


import scvelo as scv
import cellrank as cr

# Compute RNA velocity using scVelo
scv.tl.velocity(adata)
scv.tl.velocity_graph(adata)

# Initialize the VelocityKernel with the computed RNA velocity
vk = cr.kernels.VelocityKernel(adata, backward=False, attr='layers', xkey='Ms', vkey='velocity')
vk.compute_transition_matrix()  # Compute the transition matrix for the VelocityKernel

# Initialize the ConnectivityKernel to incorporate cell-cell similarity
ck = cr.kernels.ConnectivityKernel(adata, conn_key='connectivities')
ck.compute_transition_matrix()  # Compute the transition matrix for the ConnectivityKernel

# Combine the kernels to create a CombinedKernel
combined_kernel = vk + ck

# Compute the transition matrix using the combined kernel
combined_kernel.compute_transition_matrix()

# Print a message to confirm successful initialization and setup
print("CellRank initialized and transition matrix computed.")
