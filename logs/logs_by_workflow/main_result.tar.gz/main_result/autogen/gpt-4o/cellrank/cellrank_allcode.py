
import anndata as ad

# Load the single-cell RNA sequencing dataset into an AnnData object
# The dataset is expected to be in H5AD format, which is commonly used for single-cell data
adata = ad.read_h5ad('/mnt/data00/share_data/agent_benchmark/cellrank/datasets/endocrinogenesis_day15.5_raw.h5ad')

# Verify the structure of the loaded data
print(adata)


import scvelo as scv

# Preprocess the data
# Normalize the data and log-transform it
scv.pp.filter_and_normalize(adata, min_shared_counts=20, n_top_genes=2000)
scv.pp.moments(adata, n_pcs=30, n_neighbors=30)

# Verify RNA velocity information
# Check if 'spliced' and 'unspliced' layers are present, which are necessary for RNA velocity analysis
if 'spliced' in adata.layers and 'unspliced' in adata.layers:
    print("RNA velocity information is present and properly formatted.")
else:
    raise ValueError("RNA velocity information is missing or improperly formatted.")

# Display the updated AnnData object to confirm preprocessing
print(adata)


import cellrank as cr

# Initialize the VelocityKernel with the preprocessed AnnData object
# This kernel uses RNA velocity information to compute transition probabilities
vk = cr.kernels.VelocityKernel(adata, backward=False, attr='layers', xkey='Ms', vkey='velocity')

# Initialize the ConnectivityKernel to incorporate cell-cell similarity
# This kernel uses the connectivity matrix to refine transition probabilities
ck = cr.kernels.ConnectivityKernel(adata, conn_key='connectivities')

# Combine the kernels to create a CombinedKernel
# This allows us to use both RNA velocity and cell-cell similarity for trajectory inference
combined_kernel = vk + ck

# Compute the transition matrix using the combined kernel
# This matrix will be used to infer cellular trajectories
combined_kernel.compute_transition_matrix()

# Print a message to confirm successful initialization and setup
print("CellRank initialized and transition matrix computed.")


import scvelo as scv
import cellrank as cr

# Compute RNA velocity using scVelo
scv.tl.velocity(adata)
scv.tl.velocity_graph(adata)

# Initialize the VelocityKernel with the computed RNA velocity
vk = cr.kernels.VelocityKernel(adata, backward=False, attr='layers', xkey='Ms', vkey='velocity')

# Initialize the ConnectivityKernel to incorporate cell-cell similarity
ck = cr.kernels.ConnectivityKernel(adata, conn_key='connectivities')

# Combine the kernels to create a CombinedKernel
combined_kernel = vk + ck

# Compute the transition matrix using the combined kernel
combined_kernel.compute_transition_matrix()

# Print a message to confirm successful initialization and setup
print("CellRank initialized and transition matrix computed.")


import scvelo as scv
import cellrank as cr

# Compute RNA velocity using scVelo
scv.tl.velocity(adata)
scv.tl.velocity_graph(adata)

# Initialize the VelocityKernel with the computed RNA velocity
vk = cr.kernels.VelocityKernel(adata, backward=False, attr='layers', xkey='Ms', vkey='velocity')
vk.compute_transition_matrix()  # Compute the transition matrix for the VelocityKernel

# Initialize the ConnectivityKernel to incorporate cell-cell similarity
ck = cr.kernels.ConnectivityKernel(adata, conn_key='connectivities')
ck.compute_transition_matrix()  # Compute the transition matrix for the ConnectivityKernel

# Combine the kernels to create a CombinedKernel
combined_kernel = vk + ck

# Compute the transition matrix using the combined kernel
combined_kernel.compute_transition_matrix()

# Print a message to confirm successful initialization and setup
print("CellRank initialized and transition matrix computed.")


# Import necessary CellRank module for computing absorption probabilities
from cellrank.tl import estimators

# Initialize the GPCCA estimator with the combined kernel
# GPCCA is a method used to compute absorption probabilities, which are used to infer cell fates
g = estimators.GPCCA(combined_kernel)

# Compute the absorption probabilities
# This step calculates the forward transition probabilities, which indicate the likelihood of cells transitioning to different states
g.compute_schur()
g.compute_macrostates(n_states=3)  # Adjust the number of macrostates as needed
g.compute_absorption_probabilities()

# Store the forward transition probabilities in the AnnData object
adata.obsm['T_fwd_umap'] = g.absorption_probabilities

# Print a message to confirm successful computation
print("Forward transition probabilities calculated and stored in adata.obsm['T_fwd_umap'].")


# Import necessary CellRank module for computing absorption probabilities
from cellrank.tl.estimators import GPCCA

# Initialize the GPCCA estimator with the combined kernel
# GPCCA is a method used to compute absorption probabilities, which are used to infer cell fates
g = GPCCA(combined_kernel)

# Compute the absorption probabilities
# This step calculates the forward transition probabilities, which indicate the likelihood of cells transitioning to different states
g.compute_schur()
g.compute_macrostates(n_states=3)  # Adjust the number of macrostates as needed
g.compute_absorption_probabilities()

# Store the forward transition probabilities in the AnnData object
adata.obsm['T_fwd_umap'] = g.absorption_probabilities

# Print a message to confirm successful computation
print("Forward transition probabilities calculated and stored in adata.obsm['T_fwd_umap'].")


# Import necessary CellRank module for computing absorption probabilities
from cellrank.estimators import GPCCA

# Initialize the GPCCA estimator with the combined kernel
# GPCCA is a method used to compute absorption probabilities, which are used to infer cell fates
g = GPCCA(combined_kernel)

# Compute the absorption probabilities
# This step calculates the forward transition probabilities, which indicate the likelihood of cells transitioning to different states
g.compute_schur()
g.compute_macrostates(n_states=3)  # Adjust the number of macrostates as needed
g.compute_absorption_probabilities()

# Store the forward transition probabilities in the AnnData object
adata.obsm['T_fwd_umap'] = g.absorption_probabilities

# Print a message to confirm successful computation
print("Forward transition probabilities calculated and stored in adata.obsm['T_fwd_umap'].")


# Import necessary CellRank module for computing absorption probabilities
from cellrank.estimators import GPCCA

# Initialize the GPCCA estimator with the combined kernel
# GPCCA is a method used to compute absorption probabilities, which are used to infer cell fates
g = GPCCA(combined_kernel)

# Compute the Schur decomposition and macrostates
g.compute_schur()
g.compute_macrostates(n_states=3)  # Adjust the number of macrostates as needed

# Compute the terminal states, which are used to infer cell fates
g.compute_terminal_states()

# Store the forward transition probabilities in the AnnData object
adata.obsm['T_fwd_umap'] = g.absorption_probabilities

# Print a message to confirm successful computation
print("Forward transition probabilities calculated and stored in adata.obsm['T_fwd_umap'].")


# Import necessary CellRank module for computing absorption probabilities
from cellrank.estimators import GPCCA

# Initialize the GPCCA estimator with the combined kernel
# GPCCA is a method used to compute absorption probabilities, which are used to infer cell fates
g = GPCCA(combined_kernel)

# Compute the Schur decomposition and macrostates
g.compute_schur()
g.compute_macrostates(n_states=3)  # Adjust the number of macrostates as needed

# Compute the absorption probabilities, which indicate the likelihood of cells transitioning to different states
g.compute_lineage_drivers()

# Store the forward transition probabilities in the AnnData object
adata.obsm['T_fwd_umap'] = g.absorption_probabilities

# Print a message to confirm successful computation
print("Forward transition probabilities calculated and stored in adata.obsm['T_fwd_umap'].")
