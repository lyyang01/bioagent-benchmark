
# Load necessary libraries
library(DuoClustering2018)

# Load the dataset using the provided function
sce <- sce_full_Zhengmix4eq()

# The dataset is now loaded into the variable 'sce'


# Load necessary library
library(scry)

# Apply scry to identify highly variable genes
# The function 'devianceFeatureSelection' from scry is used to identify highly variable genes
hvgs <- devianceFeatureSelection(sce)

# Extract the names of the highly variable genes
hvg_names <- rownames(sce)[hvgs]

# The variable 'hvg_names' now contains the names of the highly variable genes


# Load necessary library
library(scry)

# Apply scry to identify highly variable genes
# The function 'devianceFeatureSelection' from scry is used to identify highly variable genes
hvgs <- devianceFeatureSelection(sce)

# Extract the names of the highly variable genes
hvg_names <- rownames(sce)[hvgs@listData[[1]]]

# The variable 'hvg_names' now contains the names of the highly variable genes


# Load necessary library
library(scry)

# Apply scry to identify highly variable genes
# The function 'devianceFeatureSelection' from scry is used to identify highly variable genes
hvgs <- devianceFeatureSelection(sce)

# Extract the names of the highly variable genes
# The result from devianceFeatureSelection is typically a logical vector indicating which genes are highly variable
hvg_names <- rownames(sce)[hvgs]

# The variable 'hvg_names' now contains the names of the highly variable genes


# Load necessary library
library(scry)

# Apply scry to identify highly variable genes
# The function 'devianceFeatureSelection' from scry is used to identify highly variable genes
hvgs <- devianceFeatureSelection(sce)

# Check the structure of the output to understand how to extract the indices
str(hvgs)

# Assuming hvgs is a DataFrame or similar object, we need to extract the indices of highly variable genes
# Let's assume the result is stored in a column named 'is_hvg' or similar
hvg_indices <- which(hvgs$is_hvg)

# Extract the names of the highly variable genes
hvg_names <- rownames(sce)[hvg_indices]

# The variable 'hvg_names' now contains the names of the highly variable genes


# Load necessary library
library(scry)

# Apply scry to identify highly variable genes
hvgs <- devianceFeatureSelection(sce)

# Print the structure of the output to understand how to extract the indices
print(hvgs)

# Assuming hvgs is a logical vector or contains a logical vector indicating highly variable genes
# Extract the names of the highly variable genes
hvg_names <- rownames(sce)[hvgs]

# The variable 'hvg_names' now contains the names of the highly variable genes
