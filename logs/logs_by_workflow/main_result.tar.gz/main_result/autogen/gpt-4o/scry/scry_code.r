
# Load necessary libraries
library(DuoClustering2018)

# Load the dataset using the provided function
sce <- sce_full_Zhengmix4eq()

# The dataset is now loaded into the variable 'sce'
