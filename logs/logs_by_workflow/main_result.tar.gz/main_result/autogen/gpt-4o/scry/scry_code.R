
# If the function is part of a package, make sure the package is installed and loaded
# Example: library(your_package_name)

# If the function is defined in a script, source the script
# Example: source("path/to/your_script.R")


