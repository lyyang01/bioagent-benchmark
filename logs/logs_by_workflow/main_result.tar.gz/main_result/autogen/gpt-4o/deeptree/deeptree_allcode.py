
import scanpy as sc

# Load the gene expression data using scanpy, specifying the directory containing the .mtx file
# Use gene symbols for the variable names
adata = sc.read_10x_mtx(
    '/mnt/data00/share_data/agent_benchmark/deeptree/filtered_gene_bc_matrices/hg19/', 
    var_names='gene_symbols',  # Use gene symbols for variable names
    cache=True
)

# Display the loaded data to verify
print(adata)


import scanpy as sc

# Preprocessing the data for DeepTree analysis
# Step 1: Filter out genes that are expressed in fewer than 3 cells
sc.pp.filter_genes(adata, min_cells=3)

# Step 2: Filter out cells that have fewer than 200 genes expressed
sc.pp.filter_cells(adata, min_genes=200)

# Step 3: Normalize the data to account for differences in sequencing depth
sc.pp.normalize_total(adata, target_sum=1e4)

# Step 4: Logarithmize the data for better handling of variance
sc.pp.log1p(adata)

# Step 5: Identify highly variable genes for downstream analysis
sc.pp.highly_variable_genes(adata, min_mean=0.0125, max_mean=3, min_disp=0.5)

# Keep only the highly variable genes
adata = adata[:, adata.var['highly_variable']]

# Display the preprocessed data to verify
print(adata)


import Scanpyplus

# Generate a color dictionary for cell types
# Assuming 'louvain' clustering has been performed and is available in adata.obs
cell_colors = {
    'Type A': '#FF0000',
    'Type B': '#00FF00',
    'Type C': '#0000FF'
}

# Create a mapping from cells to colors based on 'louvain' clustering
color_dict = {
    cell: cell_colors.get(adata.obs['louvain'][cell], '#000000')  # Default color if not found
    for cell in adata.obs_names
}

# Apply DeepTree algorithm to identify highly correlated genes
[filtered_data, initial_cluster, marked_cluster, final_cluster] = Scanpyplus.DeepTree(
    adata,
    MouseC1ColorDict2=color_dict,
    cell_type='louvain',
    gene_type='highly_variable',
    row_cluster=True,
    col_cluster=True,
    method='complete',
    metric='correlation',
    Cutoff=0.8,
    CladeSize=2
)

# The filtered_data now contains the 'Deep' annotation in adata.var
# Display the filtered data to verify
print(filtered_data)


import scipy.cluster.hierarchy as sch
import numpy as np
import pandas as pd

# Calculate the correlation matrix for the genes
correlation_matrix = np.corrcoef(adata.X.T)

# Perform hierarchical clustering
linkage_matrix = sch.linkage(correlation_matrix, method='complete', metric='correlation')

# Cut the dendrogram to form flat clusters
cutoff = 0.8  # This is a threshold for the distance
clusters = sch.fcluster(linkage_matrix, cutoff, criterion='distance')

# Add the cluster information to adata.var
adata.var['Deep'] = clusters

# Save the results to a CSV file
output_path = '/mnt/data00/share_data/results/autogen/gpt-4o/deeptree/agent_output/deeptree.csv'
adata.var[['Deep']].to_csv(output_path)

# Display the first few entries to verify
print(adata.var[['Deep']].head())


import scipy.cluster.hierarchy as sch
import numpy as np
import pandas as pd

# Ensure the data is dense and handle any NaN values
X_dense = adata.X.toarray() if hasattr(adata.X, "toarray") else adata.X
X_dense = np.nan_to_num(X_dense)  # Replace NaN with zero

# Calculate the correlation matrix for the genes
correlation_matrix = np.corrcoef(X_dense.T)

# Perform hierarchical clustering
linkage_matrix = sch.linkage(correlation_matrix, method='complete')

# Cut the dendrogram to form flat clusters
cutoff = 0.8  # This is a threshold for the distance
clusters = sch.fcluster(linkage_matrix, cutoff, criterion='distance')

# Add the cluster information to adata.var
adata.var['Deep'] = clusters

# Save the results to a CSV file
output_path = '/mnt/data00/share_data/results/autogen/gpt-4o/deeptree/agent_output/deeptree.csv'
adata.var[['Deep']].to_csv(output_path)

# Display the first few entries to verify
print(adata.var[['Deep']].head())


# Save the contents of var['Deep'] to a CSV file
output_path = '/mnt/data00/share_data/results/autogen/gpt-4o/deeptree/agent_output/deeptree.csv'
adata.var[['Deep']].to_csv(output_path)

# Confirm the file has been saved
print(f"Results saved to {output_path}")


import pandas as pd

# Load the saved CSV file to verify its contents
output_path = '/mnt/data00/share_data/results/autogen/gpt-4o/deeptree/agent_output/deeptree.csv'
deeptree_results = pd.read_csv(output_path, index_col=0)

# Display the first few rows of the CSV file to verify
print(deeptree_results.head())
