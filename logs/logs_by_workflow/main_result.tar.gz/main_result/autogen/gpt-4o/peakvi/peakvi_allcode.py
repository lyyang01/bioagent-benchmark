
import scanpy as sc

# Load the 10X scATAC-seq data
data_path = '/mnt/data00/share_data/agent_benchmark/peakvi/atac_pbmc_5k.untar/filtered_peak_bc_matrix'
adata = sc.read_10x_mtx(data_path, var_names='gene_symbols', cache=True)

# Check the loaded data
print(adata)

# The data is now loaded into an AnnData object, which is suitable for further analysis with PeakVI.


import os

# Define the data path
data_path = '/mnt/data00/share_data/agent_benchmark/peakvi/atac_pbmc_5k.untar/filtered_peak_bc_matrix'

# List all files in the directory
files = os.listdir(data_path)
print("Files in the directory:", files)


import anndata as ad
import pandas as pd
from scipy.io import mmread

# Define the data path
data_path = '/mnt/data00/share_data/agent_benchmark/peakvi/atac_pbmc_5k.untar/filtered_peak_bc_matrix'

# Load the matrix
matrix = mmread(f"{data_path}/matrix.mtx").T  # Transpose to match the shape (cells x features)

# Load the barcodes
barcodes = pd.read_csv(f"{data_path}/barcodes.tsv", header=None, sep='\t')

# Load the peaks
peaks = pd.read_csv(f"{data_path}/peaks.bed", header=None, sep='\t')

# Create an AnnData object
adata = ad.AnnData(X=matrix, obs=barcodes, var=peaks)

# Set the observation and variable names
adata.obs_names = barcodes[0]
adata.var_names = peaks.apply(lambda row: f"{row[0]}:{row[1]}-{row[2]}", axis=1)

# Check the loaded data
print(adata)

# The data is now loaded into an AnnData object, ready for further analysis with PeakVI.


import scanpy as sc

# Filter cells with low counts
sc.pp.filter_cells(adata, min_counts=1000)
print(f"Number of cells after filtering: {adata.n_obs}")

# Filter peaks with low counts
sc.pp.filter_genes(adata, min_counts=10)
print(f"Number of peaks after filtering: {adata.n_vars}")

# Normalize the data
sc.pp.normalize_total(adata, target_sum=1e4)

# Logarithmize the data
sc.pp.log1p(adata)

# Check the preprocessed data
print(adata)

# The data is now preprocessed and ready for PeakVI analysis.


import scanpy as sc
from scipy.sparse import csr_matrix

# Convert the matrix to csr format for subsetting
adata.X = csr_matrix(adata.X)

# Filter cells with low counts
sc.pp.filter_cells(adata, min_counts=1000)
print(f"Number of cells after filtering: {adata.n_obs}")

# Filter peaks with low counts
sc.pp.filter_genes(adata, min_counts=10)
print(f"Number of peaks after filtering: {adata.n_vars}")

# Normalize the data
sc.pp.normalize_total(adata, target_sum=1e4)

# Logarithmize the data
sc.pp.log1p(adata)

# Check the preprocessed data
print(adata)

# The data is now preprocessed and ready for PeakVI analysis.


import scvi

# Setup the AnnData object for PeakVI
scvi.model.PEAKVI.setup_anndata(adata)

# Initialize the PeakVI model
model = scvi.model.PEAKVI(
    adata,
    n_hidden=None,  # Defaults to square root of number of regions
    n_latent=None,  # Defaults to square root of n_hidden
    n_layers_encoder=2,
    n_layers_decoder=2,
    dropout_rate=0.1,
    model_depth=True,
    region_factors=True,
    use_batch_norm='none',
    use_layer_norm='both',
    latent_distribution='normal',
    deeply_inject_covariates=False,
    encode_covariates=False
)

# The model is now initialized and ready for training.


# Train the PeakVI model
model.train(
    max_epochs=500,          # Number of epochs to train
    lr=0.0001,               # Learning rate
    accelerator='auto',      # Use GPU if available
    devices='auto',          # Automatically select devices
    train_size=0.9,          # Proportion of data used for training
    validation_size=None,    # Use the remaining data for validation
    shuffle_set_split=True,  # Shuffle data before splitting
    batch_size=128,          # Batch size for training
    weight_decay=0.001,      # Regularization term
    early_stopping=True,     # Enable early stopping
    early_stopping_patience=50  # Patience for early stopping
)

# The model is now trained and ready for inference.


# Get the latent representation from the trained model
latent_representation = model.get_latent_representation()

# Store the latent representation in the AnnData object
adata.obsm['X_peakvi'] = latent_representation

# Check the stored results
print("Latent representation shape:", latent_representation.shape)
print("Stored in adata.obsm['X_peakvi']")


import pandas as pd

# Define the output path
output_path = '/mnt/data00/share_data/results/autogen/gpt-4o/peakvi/agent_output/peakvi.csv'

# Convert the latent representation to a DataFrame
latent_df = pd.DataFrame(adata.obsm['X_peakvi'], index=adata.obs_names)

# Save the DataFrame to a CSV file
latent_df.to_csv(output_path)

print(f"Results saved to {output_path}")


import os

# Define the output path
output_path = '/mnt/data00/share_data/results/autogen/gpt-4o/peakvi/agent_output/peakvi.csv'

# Check if the file exists
if os.path.exists(output_path):
    print(f"The file 'peakvi.csv' exists at {output_path} and is accessible.")
else:
    print(f"The file 'peakvi.csv' does not exist at {output_path}.")
