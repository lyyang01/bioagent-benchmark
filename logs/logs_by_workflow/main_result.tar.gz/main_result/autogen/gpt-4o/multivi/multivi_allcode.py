
import scanpy as sc

# Load the dataset into an AnnData object
adata = sc.read_10x_mtx('/mnt/data00/share_data/agent_benchmark/multivi/pbmc_10k.untar/filtered_feature_bc_matrix', 
                        var_names='gene_symbols', 
                        cache=True)

# Check the loaded data
print(adata)


# Assuming 'modality' information is stored in the 'feature_types' column of var
# Select the first 4004 cells for RNA modality data
rna_modality = adata[:, adata.var['feature_types'] == 'Gene Expression'][:4004]

# Select the second 4004 cells for paired multiome data
paired_multiome = adata[4004:8008]

# Select the last 4004 cells for ATAC modality data
atac_modality = adata[:, adata.var['feature_types'] == 'Peaks'][-4004:]

# Check the dimensions of the selected data
print(f"RNA modality data shape: {rna_modality.shape}")
print(f"Paired multiome data shape: {paired_multiome.shape}")
print(f"ATAC modality data shape: {atac_modality.shape}")


import scvi

# Initialize the MultiVI model
# Assuming that the RNA and ATAC data are stored in separate AnnData objects
# Here, we need to ensure that the data is correctly formatted for MultiVI

# Normalize the RNA data
sc.pp.normalize_total(rna_modality, target_sum=1e4)
sc.pp.log1p(rna_modality)

# Normalize the ATAC data (if applicable)
# Note: ATAC data is often binary or count-based, so normalization might differ
# Here, we assume a simple log1p transformation for demonstration
if atac_modality.shape[1] > 0:
    sc.pp.log1p(atac_modality)

# Prepare the data for MultiVI
# MultiVI requires the data to be in a specific format, typically involving concatenation
# Here, we concatenate the RNA and ATAC data along the observation axis
# Note: Ensure that the data is aligned correctly for paired and unpaired analysis

# Concatenate the data
adata_combined = rna_modality.concatenate(atac_modality, batch_key="modality")

# Check the combined data
print(f"Combined data shape: {adata_combined.shape}")


import scvi

# Setup the AnnData object for MultiVI
scvi.model.MULTIVI.setup_anndata(adata_combined, batch_key="modality")

# Initialize the MultiVI model
model = scvi.model.MULTIVI(
    adata_combined,
    n_genes=rna_modality.shape[1],
    n_regions=atac_modality.shape[1],
    modality_weights='equal',
    modality_penalty='Jeffreys',
    n_hidden=128,  # Example value, adjust based on data
    n_latent=10,   # Example value, adjust based on data
    n_layers_encoder=2,
    n_layers_decoder=2,
    dropout_rate=0.1,
    region_factors=True,
    gene_likelihood='zinb',
    dispersion='gene',
    use_batch_norm='none',
    use_layer_norm='both',
    latent_distribution='normal',
    deeply_inject_covariates=False,
    encode_covariates=False,
    fully_paired=False
)

# Train the MultiVI model
model.train(
    max_epochs=500,
    lr=0.0001,
    accelerator='gpu',  # Use GPU for faster training
    devices='auto',
    train_size=0.9,
    validation_size=None,
    shuffle_set_split=True,
    batch_size=128,
    weight_decay=0.001,
    eps=1e-08,
    early_stopping=True,
    save_best=True
)

# Get the latent representation
latent_representation = model.get_latent_representation()

# Store the results in obsm['X_multivi']
adata_combined.obsm['X_multivi'] = latent_representation

# Save the results to a CSV file
output_path = '/mnt/data00/share_data/results/autogen/gpt-4o/multivi/agent_output/multivi.csv'
adata_combined.obsm['X_multivi'].to_csv(output_path)

print(f"Results saved to {output_path}")


import scvi

# Re-select the ATAC modality data correctly
# Ensure that the ATAC data is selected based on the correct feature type
atac_modality = adata[:, adata.var['feature_types'] == 'Peaks'][-4004:]

# Check if ATAC modality has features
if atac_modality.shape[1] == 0:
    raise ValueError("ATAC modality data has no features. Please check the data selection process.")

# Concatenate the RNA and ATAC data again
adata_combined = rna_modality.concatenate(atac_modality, batch_key="modality")

# Setup the AnnData object for MultiVI
scvi.model.MULTIVI.setup_anndata(adata_combined, batch_key="modality")

# Initialize the MultiVI model
model = scvi.model.MULTIVI(
    adata_combined,
    n_genes=rna_modality.shape[1],
    n_regions=atac_modality.shape[1],
    modality_weights='equal',
    modality_penalty='Jeffreys',
    n_hidden=128,  # Example value, adjust based on data
    n_latent=10,   # Example value, adjust based on data
    n_layers_encoder=2,
    n_layers_decoder=2,
    dropout_rate=0.1,
    region_factors=True,
    gene_likelihood='zinb',
    dispersion='gene',
    use_batch_norm='none',
    use_layer_norm='both',
    latent_distribution='normal',
    deeply_inject_covariates=False,
    encode_covariates=False,
    fully_paired=False
)

# Train the MultiVI model
model.train(
    max_epochs=500,
    lr=0.0001,
    accelerator='gpu',  # Use GPU for faster training
    devices='auto',
    train_size=0.9,
    validation_size=None,
    shuffle_set_split=True,
    batch_size=128,
    weight_decay=0.001,
    eps=1e-08,
    early_stopping=True,
    save_best=True
)

# Get the latent representation
latent_representation = model.get_latent_representation()

# Store the results in obsm['X_multivi']
adata_combined.obsm['X_multivi'] = latent_representation

# Save the results to a CSV file
output_path = '/mnt/data00/share_data/results/autogen/gpt-4o/multivi/agent_output/multivi.csv'
adata_combined.obsm['X_multivi'].to_csv(output_path)

print(f"Results saved to {output_path}")


# Correct the selection of ATAC modality data
# Ensure that the selection is based on the correct indices and feature type
# Assuming the ATAC data is the last 4004 cells in the dataset
atac_modality = adata[8008:12012, adata.var['feature_types'] == 'Peaks']

# Check if ATAC modality has features
if atac_modality.shape[1] == 0:
    raise ValueError("ATAC modality data has no features. Please check the data selection process.")

# Concatenate the RNA and ATAC data again
adata_combined = rna_modality.concatenate(atac_modality, batch_key="modality")

# Setup the AnnData object for MultiVI
scvi.model.MULTIVI.setup_anndata(adata_combined, batch_key="modality")

# Initialize the MultiVI model
model = scvi.model.MULTIVI(
    adata_combined,
    n_genes=rna_modality.shape[1],
    n_regions=atac_modality.shape[1],
    modality_weights='equal',
    modality_penalty='Jeffreys',
    n_hidden=128,  # Example value, adjust based on data
    n_latent=10,   # Example value, adjust based on data
    n_layers_encoder=2,
    n_layers_decoder=2,
    dropout_rate=0.1,
    region_factors=True,
    gene_likelihood='zinb',
    dispersion='gene',
    use_batch_norm='none',
    use_layer_norm='both',
    latent_distribution='normal',
    deeply_inject_covariates=False,
    encode_covariates=False,
    fully_paired=False
)

# Train the MultiVI model
model.train(
    max_epochs=500,
    lr=0.0001,
    accelerator='gpu',  # Use GPU for faster training
    devices='auto',
    train_size=0.9,
    validation_size=None,
    shuffle_set_split=True,
    batch_size=128,
    weight_decay=0.001,
    eps=1e-08,
    early_stopping=True,
    save_best=True
)

# Get the latent representation
latent_representation = model.get_latent_representation()

# Store the results in obsm['X_multivi']
adata_combined.obsm['X_multivi'] = latent_representation

# Save the results to a CSV file
output_path = '/mnt/data00/share_data/results/autogen/gpt-4o/multivi/agent_output/multivi.csv'
adata_combined.obsm['X_multivi'].to_csv(output_path)

print(f"Results saved to {output_path}")


# Correct the selection of ATAC modality data
# Ensure that the selection is based on the correct indices and feature type
# Assuming the ATAC data is the last 4004 cells in the dataset
# and the feature type 'Peaks' is correctly identified in the var

# Check the unique feature types to ensure correct selection
print("Unique feature types:", adata.var['feature_types'].unique())

# Select the ATAC modality data
atac_modality = adata[8008:12012, adata.var['feature_types'] == 'Peaks']

# Check if ATAC modality has features
if atac_modality.shape[1] == 0:
    raise ValueError("ATAC modality data has no features. Please check the data selection process.")

# Concatenate the RNA and ATAC data again
adata_combined = rna_modality.concatenate(atac_modality, batch_key="modality")

# Setup the AnnData object for MultiVI
scvi.model.MULTIVI.setup_anndata(adata_combined, batch_key="modality")

# Initialize the MultiVI model
model = scvi.model.MULTIVI(
    adata_combined,
    n_genes=rna_modality.shape[1],
    n_regions=atac_modality.shape[1],
    modality_weights='equal',
    modality_penalty='Jeffreys',
    n_hidden=128,  # Example value, adjust based on data
    n_latent=10,   # Example value, adjust based on data
    n_layers_encoder=2,
    n_layers_decoder=2,
    dropout_rate=0.1,
    region_factors=True,
    gene_likelihood='zinb',
    dispersion='gene',
    use_batch_norm='none',
    use_layer_norm='both',
    latent_distribution='normal',
    deeply_inject_covariates=False,
    encode_covariates=False,
    fully_paired=False
)

# Train the MultiVI model
model.train(
    max_epochs=500,
    lr=0.0001,
    accelerator='gpu',  # Use GPU for faster training
    devices='auto',
    train_size=0.9,
    validation_size=None,
    shuffle_set_split=True,
    batch_size=128,
    weight_decay=0.001,
    eps=1e-08,
    early_stopping=True,
    save_best=True
)

# Get the latent representation
latent_representation = model.get_latent_representation()

# Store the results in obsm['X_multivi']
adata_combined.obsm['X_multivi'] = latent_representation

# Save the results to a CSV file
output_path = '/mnt/data00/share_data/results/autogen/gpt-4o/multivi/agent_output/multivi.csv'
adata_combined.obsm['X_multivi'].to_csv(output_path)

print(f"Results saved to {output_path}")


# Check the unique feature types to ensure correct selection
print("Unique feature types:", adata.var['feature_types'].unique())

# Verify the indices and feature types
# Assuming the ATAC data is the last 4004 cells in the dataset
# and the feature type 'Peaks' is correctly identified in the var

# Select the ATAC modality data
atac_modality = adata[8008:12012, adata.var['feature_types'] == 'Peaks']

# Check if ATAC modality has features
if atac_modality.shape[1] == 0:
    print("ATAC modality data has no features. Please check the data selection process.")
else:
    # Concatenate the RNA and ATAC data again
    adata_combined = rna_modality.concatenate(atac_modality, batch_key="modality")

    # Setup the AnnData object for MultiVI
    scvi.model.MULTIVI.setup_anndata(adata_combined, batch_key="modality")

    # Initialize the MultiVI model
    model = scvi.model.MULTIVI(
        adata_combined,
        n_genes=rna_modality.shape[1],
        n_regions=atac_modality.shape[1],
        modality_weights='equal',
        modality_penalty='Jeffreys',
        n_hidden=128,  # Example value, adjust based on data
        n_latent=10,   # Example value, adjust based on data
        n_layers_encoder=2,
        n_layers_decoder=2,
        dropout_rate=0.1,
        region_factors=True,
        gene_likelihood='zinb',
        dispersion='gene',
        use_batch_norm='none',
        use_layer_norm='both',
        latent_distribution='normal',
        deeply_inject_covariates=False,
        encode_covariates=False,
        fully_paired=False
    )

    # Train the MultiVI model
    model.train(
        max_epochs=500,
        lr=0.0001,
        accelerator='gpu',  # Use GPU for faster training
        devices='auto',
        train_size=0.9,
        validation_size=None,
        shuffle_set_split=True,
        batch_size=128,
        weight_decay=0.001,
        eps=1e-08,
        early_stopping=True,
        save_best=True
    )

    # Get the latent representation
    latent_representation = model.get_latent_representation()

    # Store the results in obsm['X_multivi']
    adata_combined.obsm['X_multivi'] = latent_representation

    # Save the results to a CSV file
    output_path = '/mnt/data00/share_data/results/autogen/gpt-4o/multivi/agent_output/multivi.csv'
    adata_combined.obsm['X_multivi'].to_csv(output_path)

    print(f"Results saved to {output_path}")

