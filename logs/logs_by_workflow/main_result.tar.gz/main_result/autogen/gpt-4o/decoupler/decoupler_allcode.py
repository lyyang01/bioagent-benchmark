
import anndata as ad

# Load the single-cell RNA sequencing data into an AnnData object
adata = ad.read_h5ad('/mnt/data00/share_data/agent_benchmark/decoupler/pbmc3k_raw.h5ad')

# Verify the data has been loaded correctly
print(adata)


import pandas as pd

# Load the marker genes from the CSV file
marker_genes = pd.read_csv('/mnt/data00/share_data/agent_benchmark/decoupler/marker_genes.csv')

# Display the first few rows of the marker genes to verify correct loading
print(marker_genes.head())


# Ensure that the gene names in the AnnData object match those in the marker genes file
# This step is crucial for Decoupler to correctly annotate cell types

# Check if the gene names in adata.var match those in the marker_genes
# Assuming 'genesymbol' is the column in marker_genes that contains gene names
marker_gene_names = marker_genes['genesymbol'].unique()

# Filter the AnnData object to only include genes present in the marker genes
# This step ensures that only relevant genes are considered for annotation
adata = adata[:, adata.var_names.isin(marker_gene_names)]

# Verify the filtering step
print(f"Number of genes after filtering: {adata.n_vars}")


import decoupler

# Prepare the network data for Decoupler
# Assuming 'cell_type' and 'genesymbol' are the columns in marker_genes that correspond to source and target nodes
network_data = marker_genes[['cell_type', 'genesymbol']]

# Run Over Representation Analysis (ORA) using Decoupler
# This will perform cell type annotation based on the marker genes
decoupler.run_ora(mat=adata, net=network_data, source='cell_type', target='genesymbol', verbose=True)

# Extract the ORA results and store them in adata.obs['cell_type']
adata.obs['cell_type'] = adata.obsm['ora_estimate'].idxmax(axis=1)

# Verify the annotation results
print(adata.obs['cell_type'].head())


# Run Over Representation Analysis (ORA) using Decoupler with use_raw=False
decoupler.run_ora(mat=adata, net=network_data, source='cell_type', target='genesymbol', verbose=True, use_raw=False)

# Extract the ORA results and store them in adata.obs['cell_type']
adata.obs['cell_type'] = adata.obsm['ora_estimate'].idxmax(axis=1)

# Verify the annotation results
print(adata.obs['cell_type'].head())


# Define the output path for saving the results
output_path = '/mnt/data00/share_data/results/autogen/gpt-4o/decoupler/agent_output/decoupler.csv'

# Save the cell type annotation results to a CSV file
adata.obs['cell_type'].to_csv(output_path, header=True)

# Confirm the file has been saved
print(f"Cell type annotations saved to {output_path}")


# Load the saved CSV file to verify its contents
verification_df = pd.read_csv('/mnt/data00/share_data/results/autogen/gpt-4o/decoupler/agent_output/decoupler.csv', index_col=0)

# Display the first few rows to ensure the annotations are correctly saved
print(verification_df.head())
