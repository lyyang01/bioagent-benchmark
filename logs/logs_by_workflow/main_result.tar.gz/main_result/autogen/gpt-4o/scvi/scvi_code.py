
import anndata as ad

# Load the input dataset
# The dataset is in the AnnData format, which is commonly used for single-cell RNA-seq data
input_file_path = '/mnt/data00/share_data/agent_benchmark/scvi/lung_atlas.h5ad'
adata = ad.read_h5ad(input_file_path)

# Verify the data is loaded correctly
print(adata)


import scvi

# Preprocess the data
# Ensure that the data is in a suitable format for scVI integration
# We will not scale the data, but we will normalize the counts and handle missing values if necessary

# Set up the AnnData object for scVI
# scVI requires raw counts in the layers['counts'], so we ensure that is set
adata.layers["counts"] = adata.layers.get("counts", adata.X.copy())

# Register the AnnData object with scVI
scvi.model.SCVI.setup_anndata(adata, layer="counts")

# Check if there are any missing values and handle them if necessary
# In this case, scVI can handle missing values internally, so no additional steps are needed

# The data is now preprocessed and ready for scVI model training
print("Data preprocessing complete. Ready for scVI model training.")


# Initialize the scVI model
# The model is set up for atlas-level integration of lung data

# Create an instance of the SCVI model
# We use the default parameters, but these can be adjusted based on specific requirements or data characteristics
scvi_model = scvi.model.SCVI(adata)

# Print model summary to verify initialization
print(scvi_model)


# Train the scVI model
# We will train the model on the preprocessed lung data

# Set the number of epochs for training
n_epochs = 400  # This can be adjusted based on convergence and computational resources

# Train the model
scvi_model.train(max_epochs=n_epochs)

# After training, the model should be ready for data integration
print("Model training complete. Ready for data integration.")


# Perform atlas-level integration using the trained scVI model
# The integration will result in a latent representation of the data

# Get the latent representation from the trained model
latent_representation = scvi_model.get_latent_representation()

# Store the integration results in the AnnData object
# The results are stored in the obsm attribute under the key 'X_scvi'
adata.obsm['X_scvi'] = latent_representation

# Verify that the integration results are stored correctly
print("Atlas-level integration complete. Results stored in adata.obsm['X_scvi'].")


# Save the integrated AnnData object
# The object now contains the scVI integration results in obsm['X_scvi']

output_file_path = '/mnt/data00/share_data/results/autogen/gpt-4o/scvi/agent_output/scvi.h5ad'
adata.write(output_file_path)

# Confirm that the file has been saved
print(f"Integrated AnnData object saved to {output_file_path}.")


# Load the saved AnnData object to verify its contents
verified_adata = ad.read_h5ad(output_file_path)

# Check if the integration results are present in obsm['X_scvi']
if 'X_scvi' in verified_adata.obsm:
    print("Verification successful: 'X_scvi' is present in obsm.")
    print(f"Shape of 'X_scvi': {verified_adata.obsm['X_scvi'].shape}")
else:
    print("Verification failed: 'X_scvi' is not present in obsm.")
