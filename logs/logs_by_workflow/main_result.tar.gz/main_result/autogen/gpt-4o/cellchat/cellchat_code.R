
# Load the necessary library for handling R data files
library(tools)

# Load the CellChat library for cell-cell communication analysis
library(CellChat)

# Load the input data from the specified location
input_data_path <- '/mnt/data00/share_data/agent_benchmark/cellchat/data_humanSkin_CellChat.rda'

# Load the R data file
load(input_data_path)

# Check the loaded data
ls()  # This will list the objects loaded into the R environment


# Inspect the structure of the data_humanSkin object
str(data_humanSkin)

# Print the first few entries to understand its content
head(data_humanSkin)


# Extract the expression data and metadata from the data_humanSkin object
expression_data <- data_humanSkin$data
metadata <- data_humanSkin$meta

# Initialize the CellChat object using the expression data and metadata
cellchat <- createCellChat(object = expression_data, meta = metadata, group.by = "labels")

# Check the CellChat object
print(cellchat)

# The CellChat object is now ready for preprocessing and analysis
