
# Load the necessary library for handling R data files
library(tools)

# Load the CellChat library for cell-cell communication analysis
library(CellChat)

# Load the input data from the specified location
input_data_path <- '/mnt/data00/share_data/agent_benchmark/cellchat/data_humanSkin_CellChat.rda'

# Load the R data file
load(input_data_path)

# Check the loaded data
ls()  # This will list the objects loaded into the R environment


# Create a CellChat object using the loaded data
# Assuming 'data_humanSkin' is the expression data matrix or Seurat object

# Initialize the CellChat object
cellchat <- createCellChat(object = data_humanSkin)

# Check the CellChat object
print(cellchat)

# The CellChat object is now ready for preprocessing and analysis


# Inspect the structure of the data_humanSkin object
str(data_humanSkin)

# Print the first few entries to understand its content
head(data_humanSkin)


# Extract the expression data and metadata from the data_humanSkin object
expression_data <- data_humanSkin$data
metadata <- data_humanSkin$meta

# Initialize the CellChat object using the expression data and metadata
cellchat <- createCellChat(object = expression_data, meta = metadata, group.by = "labels")

# Check the CellChat object
print(cellchat)

# The CellChat object is now ready for preprocessing and analysis


# Preprocess the CellChat object

# Step 1: Subset the data to include only signaling genes
cellchat <- subsetData(cellchat)  # This function subsets the data to include only signaling genes

# Step 2: Normalize the data
cellchat <- normalizeData(cellchat)  # This function normalizes the data for downstream analysis

# Step 3: Identify over-expressed genes and interactions
cellchat <- identifyOverExpressedGenes(cellchat)
cellchat <- identifyOverExpressedInteractions(cellchat)

# Step 4: Project the data onto the PPI network (Protein-Protein Interaction network)
cellchat <- projectData(cellchat, PPI.human)

# The CellChat object is now preprocessed and ready for inferring cell-cell communication networks


# Load the CellChat database for human signaling genes
CellChatDB <- CellChatDB.human  # Load the human database

# Set the database in the CellChat object
cellchat@DB <- CellChatDB

# Retry preprocessing steps with the database set
cellchat <- subsetData(cellchat)  # Subset the data to include only signaling genes
cellchat <- normalizeData(cellchat)  # Normalize the data
cellchat <- identifyOverExpressedGenes(cellchat)  # Identify over-expressed genes
cellchat <- identifyOverExpressedInteractions(cellchat)  # Identify over-expressed interactions
cellchat <- projectData(cellchat, PPI.human)  # Project data onto the PPI network

# The CellChat object is now preprocessed and ready for inferring cell-cell communication networks


# Ensure the expression data is in the correct format
# Check if the expression data is a matrix
if (!is.matrix(cellchat@data)) {
  cellchat@data <- as.matrix(cellchat@data)
}

# Retry preprocessing steps
cellchat <- subsetData(cellchat)  # Subset the data to include only signaling genes
cellchat <- normalizeData(cellchat)  # Normalize the data
cellchat <- identifyOverExpressedGenes(cellchat)  # Identify over-expressed genes
cellchat <- identifyOverExpressedInteractions(cellchat)  # Identify over-expressed interactions
cellchat <- projectData(cellchat, PPI.human)  # Project data onto the PPI network

# The CellChat object is now preprocessed and ready for inferring cell-cell communication networks


# Explicitly set the expression data and metadata in the CellChat object
cellchat@data <- expression_data
cellchat@meta <- metadata

# Retry preprocessing steps
cellchat <- subsetData(cellchat)  # Subset the data to include only signaling genes
cellchat <- normalizeData(cellchat)  # Normalize the data
cellchat <- identifyOverExpressedGenes(cellchat)  # Identify over-expressed genes
cellchat <- identifyOverExpressedInteractions(cellchat)  # Identify over-expressed interactions
cellchat <- projectData(cellchat, PPI.human)  # Project data onto the PPI network

# The CellChat object is now preprocessed and ready for inferring cell-cell communication networks


# Check the structure of the data within the CellChat object
str(cellchat@data)

# Ensure the expression data is correctly assigned
cellchat@data <- expression_data

# Check if the data is correctly set
if (is.null(cellchat@data) || ncol(cellchat@data) == 0) {
  stop("Expression data is not correctly set in the CellChat object.")
}

# Retry preprocessing steps
cellchat <- subsetData(cellchat)  # Subset the data to include only signaling genes
cellchat <- normalizeData(cellchat)  # Normalize the data
cellchat <- identifyOverExpressedGenes(cellchat)  # Identify over-expressed genes
cellchat <- identifyOverExpressedInteractions(cellchat)  # Identify over-expressed interactions
cellchat <- projectData(cellchat, PPI.human)  # Project data onto the PPI network

# The CellChat object is now preprocessed and ready for inferring cell-cell communication networks
