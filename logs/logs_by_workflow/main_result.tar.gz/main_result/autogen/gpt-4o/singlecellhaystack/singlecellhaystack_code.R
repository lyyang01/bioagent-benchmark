
# Load necessary library for handling R data files
library(tools)

# Load the single-cell RNA-seq dataset
# The dataset is assumed to be in RDA format, which is a common format for R data files
load('/mnt/data00/share_data/agent_benchmark/singlecellhaystack/scRNAseq_thymus.rda')

# Check the contents of the loaded data to ensure it has been loaded correctly
ls()  # This will list all objects in the current R environment


# Load necessary libraries for data manipulation and normalization
library(SingleCellExperiment)
library(scater)  # scater provides functions for normalization

# Inspect the structure of the loaded data
str(dat.expression)  # Check the structure of the expression data
str(dat.pca)         # Check the structure of the PCA data
str(dat.tsne)        # Check the structure of the t-SNE data

# Assuming 'dat.expression' is a matrix or data frame containing gene expression values
# Check if any preprocessing steps are needed, such as normalization or transformation

# Example: Normalizing the expression data if needed
# Here, we assume 'dat.expression' is a matrix with genes as rows and cells as columns
if (!is(dat.expression, "SingleCellExperiment")) {
  sce <- SingleCellExperiment(assays = list(counts = as.matrix(dat.expression)))
} else {
  sce <- dat.expression
}

# Perform normalization using a common method, such as log normalization
# This step is crucial for single-cell RNA-seq data to ensure comparability across cells
sce <- scater::logNormCounts(sce)

# Check the normalized data
assay(sce, "logcounts")[1:5, 1:5]  # Display a subset of the normalized data for verification


# It seems there was an issue with the variable name for the expression data.
# Let's ensure we have the correct variable for the normalized expression data.

# Extract the normalized expression data from the SingleCellExperiment object
expression_data <- assay(sce, "logcounts")

# Convert the PCA data frame to a matrix for use with singleCellHaystack
pca_coords <- as.matrix(dat.pca)

# Apply the haystack function to identify highly variable genes
# Here, we use the PCA coordinates and the normalized expression data
res.haystack <- haystack(x = pca_coords, expression = expression_data)

# Show the results of the haystack analysis
# This will sort the genes by significance and display them
show_result_haystack(res.haystack, n = 10)  # Display top 10 significant genes


# Extract the set of highly variable gene names from the haystack analysis results
# The results are stored in the 'res.haystack' object

# Use the show_result_haystack function to extract the results as a data frame
results_df <- show_result_haystack(res.haystack)

# Extract the gene names from the results
# Assuming the gene names are stored in the row names of the results data frame
highly_variable_genes <- rownames(results_df)

# Display the extracted gene names
print(highly_variable_genes)


# Define the path to save the results
output_path <- '/mnt/data00/share_data/results/autogen/gpt-4o/singlecellhaystack/agent_output/singlecellhaystack.RData'

# Save the extracted set of highly variable gene names
save(highly_variable_genes, file = output_path)

# Verify that the file has been saved correctly
if (file.exists(output_path)) {
  print("Results saved successfully.")
} else {
  print("Error: Results not saved.")
}


# Load the saved RData file to verify its contents
load('/mnt/data00/share_data/results/autogen/gpt-4o/singlecellhaystack/agent_output/singlecellhaystack.RData')

# Check the contents of the loaded data
print(highly_variable_genes)

# Verify the number of genes and a few gene names to ensure correctness
cat("Number of highly variable genes:", length(highly_variable_genes), "\n")
cat("Sample of highly variable genes:", head(highly_variable_genes), "\n")


# Save the documentation as a text file for future reference

# Define the documentation content
documentation_content <- "
# Documentation of the Process for Identifying Highly Variable Genes using singleCellHaystack

## Step 1: Load the Dataset
- Loaded the single-cell RNA-seq dataset from the specified RDA file.
- Verified the contents of the loaded data, which included 'dat.expression', 'dat.pca', and 'dat.tsne'.

## Step 2: Preprocess the Data
- Ensured the data was in the correct format for analysis.
- Converted the expression data into a SingleCellExperiment object.
- Applied log normalization to the expression data using the scater package.

## Step 3: Apply singleCellHaystack
- Used the singleCellHaystack package to analyze the dataset.
- Extracted PCA coordinates from the 'dat.pca' data frame.
- Applied the haystack function using PCA coordinates and normalized expression data to identify highly variable genes.

## Step 4: Extract Results
- Extracted the set of highly variable gene names from the haystack analysis results.
- Used the show_result_haystack function to obtain a data frame of results.

## Step 5: Save the Results
- Saved the extracted gene names as 'singlecellhaystack.RData' in the specified directory.

## Step 6: Verify the Output
- Loaded the saved RData file to verify its contents.
- Confirmed the presence of the expected highly variable gene names.

## Assumptions
- Assumed that the PCA data was correctly formatted and represented the necessary dimensionality reduction for the analysis.
- Assumed that the log normalization was appropriate for the expression data.

## Issues Encountered
- Initial errors in accessing PCA coordinates from the SingleCellExperiment object were resolved by using the 'dat.pca' data frame directly.
- Ensured correct variable names were used for expression data extraction.

## Conclusion
The process successfully identified and saved a set of highly variable genes from the single-cell RNA-seq dataset using the singleCellHaystack package. The results are stored for future analysis and validation.
"

# Define the path to save the documentation
doc_path <- '/mnt/data00/share_data/results/autogen/gpt-4o/singlecellhaystack/agent_output/documentation.txt'

# Write the documentation to a text file
writeLines(documentation_content, con = doc_path)

# Verify that the documentation file has been saved correctly
if (file.exists(doc_path)) {
  print("Documentation saved successfully.")
} else {
  print("Error: Documentation not saved.")
}
