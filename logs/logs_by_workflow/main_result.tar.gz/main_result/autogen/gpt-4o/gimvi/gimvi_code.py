
# Import necessary libraries
from scvi.data import smfish

# Load the spatial data using the smfish function
# The path provided is where the dataset is located
spatial_data = smfish('/mnt/data00/share_data/agent_benchmark/gimvi/')

# Check the loaded data
print(spatial_data)


# Import necessary libraries
from scvi.data import cortex

# Load the scRNA-seq data using the cortex function
# The path provided is where the dataset is located
scrna_data = cortex('/mnt/data00/share_data/agent_benchmark/gimvi/')

# Check the loaded data
print(scrna_data)


# Import necessary libraries
import scvi
from scvi.external import GIMVI

# Preprocess the spatial data
# Register the spatial data with gimVI setup
GIMVI.setup_anndata(spatial_data, batch_key='batch', labels_key='labels')

# Preprocess the scRNA-seq data
# Register the scRNA-seq data with gimVI setup without a batch key
GIMVI.setup_anndata(scrna_data, labels_key='labels')

# Note: The labels_key is assumed to be 'labels' for both datasets.
# Ensure that the datasets are normalized and filtered as needed before this step.
