
import anndata as ad

# Load the MERFISH dataset into an AnnData object
adata = ad.read_h5ad('/mnt/data00/share_data/agent_benchmark/squidpy/merfish.h5ad')

# Check the structure of the loaded data to ensure it contains spatial information
print(adata)


import squidpy as sq

# Check if the data needs preprocessing
# Squidpy requires spatial information, which is present in 'obsm' as 'spatial'
# Let's inspect the spatial data and check for any necessary preprocessing

# Check the spatial coordinates
print(adata.obsm['spatial'][:5])  # Print the first 5 spatial coordinates

# Check for missing values in spatial data
missing_values = adata.obsm['spatial'].isnull().sum()
print(f"Missing values in spatial data: {missing_values}")

# Check if normalization is needed
# Squidpy does not require normalization for neighborhood enrichment, but it's good to check the expression data
print(adata.X[:5])  # Print the first 5 rows of expression data

# If normalization is needed, uncomment the following line
# adata.X = adata.X / adata.X.sum(axis=1, keepdims=True) * 1e4  # Example normalization

# No specific filtering is required for neighborhood enrichment, but ensure data quality
# If filtering is needed, it can be done based on specific criteria like gene expression thresholds


import numpy as np

# Check the spatial coordinates
print(adata.obsm['spatial'][:5])  # Print the first 5 spatial coordinates

# Check for missing values in spatial data using NumPy
missing_values = np.isnan(adata.obsm['spatial']).sum()
print(f"Missing values in spatial data: {missing_values}")

# Check if normalization is needed
# Squidpy does not require normalization for neighborhood enrichment, but it's good to check the expression data
print(adata.X[:5])  # Print the first 5 rows of expression data

# If normalization is needed, uncomment the following line
# adata.X = adata.X / adata.X.sum(axis=1, keepdims=True) * 1e4  # Example normalization

# No specific filtering is required for neighborhood enrichment, but ensure data quality
# If filtering is needed, it can be done based on specific criteria like gene expression thresholds


import squidpy as sq

# First, compute the spatial neighbors
sq.gr.spatial_neighbors(adata, spatial_key='spatial')

# Perform neighborhood enrichment analysis
# We assume 'Cell_class' is the key in adata.obs that contains the cell type or class information
sq.gr.nhood_enrichment(adata, cluster_key='Cell_class')

# The results are stored in adata.uns['Cell_class_nhood_enrichment']['count']
# Let's check the results
print(adata.uns['Cell_class_nhood_enrichment']['count'])


import pandas as pd
import os

# Extract the neighborhood enrichment results
nhood_enrichment_results = adata.uns['Cell_class_nhood_enrichment']['count']

# Convert the results to a DataFrame
nhood_enrichment_df = pd.DataFrame(nhood_enrichment_results)

# Define the output path
output_path = '/mnt/data00/share_data/results/autogen/gpt-4o/squidpy/agent_output'
os.makedirs(output_path, exist_ok=True)

# Save the DataFrame to a CSV file
nhood_enrichment_df.to_csv(os.path.join(output_path, 'squidpy.csv'), index=False)

print(f"Neighborhood enrichment results saved to {os.path.join(output_path, 'squidpy.csv')}")


# Load the saved CSV file to verify its contents
saved_df = pd.read_csv(os.path.join(output_path, 'squidpy.csv'))

# Display the first few rows of the DataFrame to verify the contents
print(saved_df.head())

# Check if the shape of the saved DataFrame matches the expected results
print(f"Shape of the saved DataFrame: {saved_df.shape}")
