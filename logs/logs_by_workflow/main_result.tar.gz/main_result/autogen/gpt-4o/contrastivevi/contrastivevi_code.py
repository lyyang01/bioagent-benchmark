
import anndata as ad

# Load the dataset
# The dataset is stored in an h5ad file, which is a common format for single-cell RNA-seq data
adata = ad.read_h5ad('/mnt/data00/share_data/agent_benchmark/contrastivevi/norman_2019.h5ad')

# Verify the structure of the AnnData object
print(adata)


# Identify perturbed and non-perturbed cells
# 'gene_program' in 'obs' indicates whether a cell is perturbed or not
# 'Ctrl' indicates non-perturbed cells, any other value indicates perturbed cells

# Create a boolean mask for non-perturbed cells
non_perturbed_mask = adata.obs['gene_program'] == 'Ctrl'

# Create a boolean mask for perturbed cells
perturbed_mask = ~non_perturbed_mask

# Count the number of perturbed and non-perturbed cells
num_non_perturbed = non_perturbed_mask.sum()
num_perturbed = perturbed_mask.sum()

print(f"Number of non-perturbed cells: {num_non_perturbed}")
print(f"Number of perturbed cells: {num_perturbed}")


from scvi.external import ContrastiveVI

# Preprocess the data for ContrastiveVI
# We need to set up the AnnData object for ContrastiveVI
# Here, we assume that the raw count data is in the 'count' layer, and we use 'gene_program' as labels

# Setup the AnnData object for ContrastiveVI
ContrastiveVI.setup_anndata(
    adata,
    layer='count',  # Use the 'count' layer for raw count data
    labels_key='gene_program'  # Use 'gene_program' as the label information
)

# The data is now ready for ContrastiveVI analysis


import numpy as np

# Convert boolean masks to integer indices using np.where
background_indices = np.where(non_perturbed_mask)[0]
target_indices = np.where(perturbed_mask)[0]

# Train the ContrastiveVI model using integer indices
model.train(
    background_indices=background_indices,  # Indices of non-perturbed cells
    target_indices=target_indices,  # Indices of perturbed cells
    max_epochs=400,  # Number of training epochs
    accelerator='gpu',  # Use GPU for training if available
    devices='auto',  # Automatically select devices
    train_size=0.9,  # Proportion of data used for training
    early_stopping=True  # Enable early stopping
)

# The model is now trained and ready to extract insights


# Extract the latent representation from the trained model
salient_rep = model.get_latent_representation()

# Store the results in the 'obsm' attribute of the AnnData object
adata.obsm['salient_rep'] = salient_rep

# Verify that the results are stored correctly
print("Salient representation stored in adata.obsm['salient_rep']")
print(adata.obsm['salient_rep'].shape)


import pandas as pd

# Convert the salient representation to a DataFrame
salient_rep_df = pd.DataFrame(
    adata.obsm['salient_rep'],
    index=adata.obs.index
)

# Define the output file path
output_file_path = '/mnt/data00/share_data/results/autogen/gpt-4o/contrastivevi/agent_output/cellassign.csv'

# Save the DataFrame to a CSV file
salient_rep_df.to_csv(output_file_path)

print(f"Salient representation saved to {output_file_path}")


# Validate the saved results
# Load the CSV file to ensure it was saved correctly
loaded_salient_rep_df = pd.read_csv('/mnt/data00/share_data/results/autogen/gpt-4o/contrastivevi/agent_output/cellassign.csv', index_col=0)

# Check if the loaded data matches the original data
is_data_correct = loaded_salient_rep_df.equals(salient_rep_df)

print(f"Data validation successful: {is_data_correct}")

# Document the process
documentation = """
ContrastiveVI Analysis Documentation

1. Data Loading:
   - The dataset was loaded from 'norman_2019.h5ad' into an AnnData object.
   - The 'gene_program' parameter was used to distinguish between perturbed and non-perturbed cells.

2. Data Preprocessing:
   - The AnnData object was set up for ContrastiveVI using the 'count' layer and 'gene_program' as labels.

3. Model Training:
   - The ContrastiveVI model was initialized and trained using GPU acceleration.
   - Non-perturbed and perturbed cells were used as background and target indices, respectively.

4. Results Storage:
   - The salient latent representation was extracted and stored in 'obsm['salient_rep']'.

5. Results Export:
   - The salient representation was exported to 'cellassign.csv' in the specified output directory.

6. Validation:
   - The saved CSV file was validated to ensure it matches the original data.

Insights:
- The salient representation provides insights into perturbation-induced variations, potentially revealing gene functions and relationships.

"""

# Save the documentation to a text file
with open('/mnt/data00/share_data/results/autogen/gpt-4o/contrastivevi/agent_output/documentation.txt', 'w') as doc_file:
    doc_file.write(documentation)

print("Documentation saved to '/mnt/data00/share_data/results/autogen/gpt-4o/contrastivevi/agent_output/documentation.txt'")
