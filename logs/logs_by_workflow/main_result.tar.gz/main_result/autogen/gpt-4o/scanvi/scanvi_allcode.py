
import anndata as ad

# Load the input dataset
input_file_path = '/mnt/data00/share_data/agent_benchmark/scanvi/lung_atlas.h5ad'
adata = ad.read_h5ad(input_file_path)

# Check the loaded data
print(adata)


import scanpy as sc

# Preprocess the data without scaling
# Here, we will perform basic preprocessing steps such as normalization and log transformation

# Normalize the data
sc.pp.normalize_total(adata, target_sum=1e4)

# Logarithmize the data
sc.pp.log1p(adata)

# Check the preprocessed data
print(adata)


import scvi

# Setup the AnnData object for scANVI
scvi.model.SCVI.setup_anndata(
    adata, 
    layer='counts',  # Use the raw counts layer for scANVI
    batch_key='batch',  # Use batch information to handle batch effects
    labels_key='cell_type'  # Use cell type labels for supervised learning
)

# Initialize the SCVI model
scvi_model = scvi.model.SCVI(
    adata,
    n_hidden=128,  # Number of nodes per hidden layer
    n_latent=10,   # Dimensionality of the latent space
    n_layers=1,    # Number of hidden layers
    dropout_rate=0.1,  # Dropout rate for neural networks
    dispersion='gene',  # Dispersion parameter of NB is constant per gene across cells
    gene_likelihood='zinb',  # Zero-inflated negative binomial distribution
    latent_distribution='normal'  # Normal distribution for latent space
)

# Initialize the scANVI model from the SCVI model
scanvi_model = scvi.model.SCANVI.from_scvi_model(
    scvi_model,
    unlabeled_category='unlabeled',  # Specify the category for unlabeled cells
    labels_key='cell_type'  # Use the same labels key as SCVI setup
)

# Check the initialized model
print(scanvi_model)


# Train the scANVI model
scanvi_model.train(
    max_epochs=100,  # Set the maximum number of epochs for training
    accelerator='gpu',  # Use GPU for training if available
    devices='auto',  # Automatically select available devices
    train_size=0.9,  # Use 90% of the data for training
    validation_size=0.1,  # Use 10% of the data for validation
    batch_size=128,  # Set the batch size for training
    early_stopping=True  # Enable early stopping to prevent overfitting
)

# Check the training status
print("Training completed.")


# Perform atlas-level integration using the trained scANVI model
latent_representation = scanvi_model.get_latent_representation()

# Store the integration results in obsm['X_scanvi']
adata.obsm['X_scanvi'] = latent_representation

# Verify the integration results
print("Atlas-level integration completed and stored in obsm['X_scanvi'].")


# Define the output file path
output_file_path = '/mnt/data00/share_data/results/autogen/gpt-4o/scanvi/agent_output/scanvi.h5ad'

# Save the integrated AnnData object
adata.write_h5ad(output_file_path)

# Confirm the save operation
print(f"Integrated AnnData object saved to {output_file_path}.")


import os

# Verify the integration results in obsm['X_scanvi']
if 'X_scanvi' in adata.obsm:
    print("Integration results are correctly stored in obsm['X_scanvi'].")
else:
    print("Error: Integration results are not found in obsm['X_scanvi'].")

# Confirm the file is saved correctly
if os.path.exists(output_file_path):
    print(f"File is saved correctly at {output_file_path}.")
else:
    print(f"Error: File is not found at {output_file_path}.")
