
import pandas as pd

# Load the scRNA-seq data from the specified CSV file
scRNA_seq_data_path = '/mnt/data00/share_data/agent_benchmark/spage/SSp_exons_matrix.csv'
scRNA_seq_data = pd.read_csv(scRNA_seq_data_path)

# Display the first few rows of the data to verify loading
print(scRNA_seq_data.head())


import loompy

# Load the osmFISH spatial data from the specified LOOM file
osmFISH_data_path = '/mnt/data00/share_data/agent_benchmark/spage/osmFISH_SScortex_mouse_all_cells.loom'
osmFISH_data = loompy.connect(osmFISH_data_path)

# Display basic information about the data to verify loading
print("Number of genes:", osmFISH_data.shape[0])
print("Number of cells:", osmFISH_data.shape[1])

# Close the connection after loading
osmFISH_data.close()


import loompy
import numpy as np

# Reconnect to the osmFISH data
osmFISH_data = loompy.connect(osmFISH_data_path)

# Extract the metadata for filtering
cell_metadata = osmFISH_data.ca['Region']

# Define the cortical regions to filter
cortical_regions = ['Layer 2-3 lateral', 'Layer 2-3 medial', 'Layer 3-4', 'Layer 4', 'Layer 5', 'Layer 6', 'Pia Layer 1']

# Create a mask to filter cells belonging to the specified cortical regions
region_mask = np.isin(cell_metadata, cortical_regions)

# Filter the data based on the mask
filtered_osmFISH_data = osmFISH_data[:, region_mask]

# Display the number of cells after filtering
print("Number of cells after filtering:", filtered_osmFISH_data.shape[1])

# Close the connection
osmFISH_data.close()
