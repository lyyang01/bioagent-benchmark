
import scanpy as sc

# Load the spatial data for the anterior part of the mouse brain
anterior_data_path = '/mnt/data00/share_data/agent_benchmark/scanorama/V1_Mouse_Brain_Sagittal_Anterior/'
anterior_data = sc.read_10x_mtx(anterior_data_path, var_names='gene_symbols', cache=True)

# Check the loaded data
print(anterior_data)


import os

# Define the path to the anterior data directory
anterior_data_path = '/mnt/data00/share_data/agent_benchmark/scanorama/V1_Mouse_Brain_Sagittal_Anterior/'

# List all files in the directory to understand the structure
files_in_directory = os.listdir(anterior_data_path)
print("Files in the anterior data directory:", files_in_directory)


import scanpy as sc

# Load the spatial data for the anterior part of the mouse brain using the HDF5 file
anterior_data_path = '/mnt/data00/share_data/agent_benchmark/scanorama/V1_Mouse_Brain_Sagittal_Anterior/filtered_feature_bc_matrix.h5'
anterior_data = sc.read_10x_h5(anterior_data_path)

# Check the loaded data
print(anterior_data)


# Load the spatial data for the posterior part of the mouse brain using the HDF5 file
posterior_data_path = '/mnt/data00/share_data/agent_benchmark/scanorama/V1_Mouse_Brain_Sagittal_Posterior/filtered_feature_bc_matrix.h5'
posterior_data = sc.read_10x_h5(posterior_data_path)

# Check the loaded data
print(posterior_data)


# Ensure the data is in AnnData format (already loaded as AnnData objects)
# Check for missing values or inconsistencies in the anterior dataset
print("Checking for missing values in anterior dataset:")
print(anterior_data.isnull().sum())

# Check for missing values or inconsistencies in the posterior dataset
print("Checking for missing values in posterior dataset:")
print(posterior_data.isnull().sum())

# Address any issues found (e.g., making variable names unique)
anterior_data.var_names_make_unique()
posterior_data.var_names_make_unique()

# Verify the changes
print("Anterior dataset after making variable names unique:")
print(anterior_data.var_names[:10])

print("Posterior dataset after making variable names unique:")
print(posterior_data.var_names[:10])


import numpy as np

# Check for missing values in the anterior dataset
print("Checking for missing values in anterior dataset:")
missing_values_anterior = np.isnan(anterior_data.X).sum()
print(f"Missing values in anterior dataset: {missing_values_anterior}")

# Check for missing values in the posterior dataset
print("Checking for missing values in posterior dataset:")
missing_values_posterior = np.isnan(posterior_data.X).sum()
print(f"Missing values in posterior dataset: {missing_values_posterior}")

# Address any issues found (e.g., making variable names unique)
anterior_data.var_names_make_unique()
posterior_data.var_names_make_unique()

# Verify the changes
print("Anterior dataset after making variable names unique:")
print(anterior_data.var_names[:10])

print("Posterior dataset after making variable names unique:")
print(posterior_data.var_names[:10])


# Convert the expression data to float to check for NaNs
anterior_data.X = anterior_data.X.astype(float)
posterior_data.X = posterior_data.X.astype(float)

# Check for missing values in the anterior dataset
print("Checking for missing values in anterior dataset:")
missing_values_anterior = np.isnan(anterior_data.X).sum()
print(f"Missing values in anterior dataset: {missing_values_anterior}")

# Check for missing values in the posterior dataset
print("Checking for missing values in posterior dataset:")
missing_values_posterior = np.isnan(posterior_data.X).sum()
print(f"Missing values in posterior dataset: {missing_values_posterior}")

# Address any issues found (e.g., making variable names unique)
anterior_data.var_names_make_unique()
posterior_data.var_names_make_unique()

# Verify the changes
print("Anterior dataset after making variable names unique:")
print(anterior_data.var_names[:10])

print("Posterior dataset after making variable names unique:")
print(posterior_data.var_names[:10])


from scipy.sparse import issparse

# Function to check for missing values in a potentially sparse matrix
def check_missing_values(adata):
    if issparse(adata.X):
        # Convert to dense format for checking
        data_dense = adata.X.toarray()
    else:
        data_dense = adata.X
    
    # Check for missing values
    missing_values = np.isnan(data_dense).sum()
    return missing_values

# Check for missing values in the anterior dataset
print("Checking for missing values in anterior dataset:")
missing_values_anterior = check_missing_values(anterior_data)
print(f"Missing values in anterior dataset: {missing_values_anterior}")

# Check for missing values in the posterior dataset
print("Checking for missing values in posterior dataset:")
missing_values_posterior = check_missing_values(posterior_data)
print(f"Missing values in posterior dataset: {missing_values_posterior}")

# Address any issues found (e.g., making variable names unique)
anterior_data.var_names_make_unique()
posterior_data.var_names_make_unique()

# Verify the changes
print("Anterior dataset after making variable names unique:")
print(anterior_data.var_names[:10])

print("Posterior dataset after making variable names unique:")
print(posterior_data.var_names[:10])


import scanorama

# List of AnnData objects to integrate
adatas = [anterior_data, posterior_data]

# Use Scanorama to integrate the datasets
# We will use the integrate_scanpy function for simplicity
integrated_data = scanorama.integrate_scanpy(adatas, dimred=100, hvg=False)

# Store the integration results in the AnnData object’s obsm attribute under the key 'X_scanorama'
integrated_data.obsm['X_scanorama'] = integrated_data.obsm['X_scanorama']

# Verify the integration
print("Integration complete. Shape of integrated data:", integrated_data.obsm['X_scanorama'].shape)


# Use Scanorama to integrate the datasets using correct_scanpy
integrated_adatas = scanorama.correct_scanpy(adatas, return_dimred=True, dimred=100, hvg=False)

# Store the integration results in the AnnData object’s obsm attribute under the key 'X_scanorama'
for i, adata in enumerate(integrated_adatas):
    adata.obsm['X_scanorama'] = adata.obsm['X_scanorama']

# Verify the integration
for i, adata in enumerate(integrated_adatas):
    print(f"Integration complete for dataset {i}. Shape of integrated data:", adata.obsm['X_scanorama'].shape)


import os
import pandas as pd

# Define the output directory
output_dir = '/mnt/data00/share_data/results/autogen/gpt-4o/scanorama/agent_output'
os.makedirs(output_dir, exist_ok=True)

# Extract and save the integrated data for each dataset
for i, adata in enumerate(integrated_adatas):
    # Extract the integrated data
    integrated_data = adata.obsm['X_scanorama']
    
    # Convert to DataFrame for saving
    integrated_df = pd.DataFrame(integrated_data, index=adata.obs_names)
    
    # Define the output file path
    output_file = os.path.join(output_dir, f'scanorama_dataset_{i}.csv')
    
    # Save the DataFrame to a CSV file
    integrated_df.to_csv(output_file)
    print(f"Integrated data for dataset {i} saved to {output_file}")


# Load and verify the contents of the saved CSV files
for i in range(2):
    # Define the file path
    file_path = f'/mnt/data00/share_data/results/autogen/gpt-4o/scanorama/agent_output/scanorama_dataset_{i}.csv'
    
    # Load the CSV file into a DataFrame
    integrated_df = pd.read_csv(file_path, index_col=0)
    
    # Display the first few rows of the DataFrame to verify its contents
    print(f"Contents of scanorama_dataset_{i}.csv:")
    print(integrated_df.head())
    print("\n")


# Define the documentation content
documentation_content = """
Integration Process Documentation

1. Data Loading:
   - Loaded spatial data for the anterior and posterior parts of the mouse brain using Scanpy's read_10x_h5 function.
   - Ensured data was in AnnData format, which is compatible with Scanorama.

2. Data Preprocessing:
   - Checked for missing values in the expression matrices. No missing values were found.
   - Made variable names unique to avoid conflicts during integration.

3. Data Integration:
   - Used Scanorama's correct_scanpy function to integrate the datasets.
   - Stored the integration results in the obsm attribute under the key 'X_scanorama'.

4. Saving Results:
   - Extracted the integrated data and saved it as CSV files for each dataset.

5. Observations and Issues:
   - The expression matrices were initially in a sparse format, requiring conversion to dense format for certain operations.
   - Variable names were not unique initially, which was resolved using var_names_make_unique().

6. Verification:
   - Verified the contents of the saved CSV files to ensure the integration process was successful.

This documentation provides a detailed overview of the integration process and highlights key steps and considerations.
"""

# Define the path for saving the documentation
documentation_path = '/mnt/data00/share_data/results/autogen/gpt-4o/scanorama/agent_output/integration_process_documentation.txt'

# Save the documentation to a text file
with open(documentation_path, 'w') as doc_file:
    doc_file.write(documentation_content)

print(f"Documentation saved to {documentation_path}")
