
import scanpy as sc

# Load the spatial transcriptomics dataset
data_path = '/mnt/data00/share_data/agent_benchmark/sedr/V1_Human_Lymph_Node/'
adata = sc.read_visium(data_path)

# Check the loaded data
print(adata)


import scanpy as sc

# Load the spatial transcriptomics dataset
data_path = '/mnt/data00/share_data/agent_benchmark/sedr/V1_Human_Lymph_Node/'
adata = sc.read_visium(data_path)

# Preprocessing: Normalize the data
# Log-normalize the data to make the gene expression values comparable
sc.pp.normalize_total(adata, target_sum=1e4)
sc.pp.log1p(adata)

# Handle missing values
# In spatial transcriptomics, missing values can be due to dropout events
# Here, we assume missing values are represented as zeros and will be imputed later
# Check for missing values
missing_values = (adata.X == 0).sum()
print(f"Number of missing values (dropouts): {missing_values}")

# The data is now preprocessed and ready for imputation with SEDR


import torch
import SEDR

# Step 1: Construct a neighborhood graph
k_neighbors = 12  # Number of nearest neighbors
graph_dict = SEDR.graph_construction(adata, k_neighbors)

# Step 2: Extract the expression matrix from AnnData
expression_matrix = adata.X.toarray() if hasattr(adata.X, 'toarray') else adata.X

# Step 3: Initialize the SEDR model
sedr_model = SEDR.Sedr(expression_matrix, graph_dict, mode='imputation')

# Step 4: Train the SEDR model
sedr_model.train_with_dec()

# Step 5: Reconstruct the gene expression data
imputed_data = sedr_model.recon()

# Store the imputed data in the AnnData object
adata.obsm['de_feat'] = imputed_data

# Check the imputed data
print("Imputation completed. Imputed data shape:", imputed_data.shape)


# Store the imputed data in the AnnData object
adata.obsm['de_feat'] = imputed_data

# Check the stored data
print("Imputed data stored in obsm['de_feat'].")


import pandas as pd

# Convert the imputed data to a DataFrame
imputed_df = pd.DataFrame(adata.obsm['de_feat'], index=adata.obs_names, columns=adata.var_names)

# Define the output path
output_path = '/mnt/data00/share_data/results/autogen/gpt-4o/sedr/agent_output/sedr.csv'

# Save the DataFrame as a CSV file
imputed_df.to_csv(output_path)

print(f"Imputed results saved as 'sedr.csv' in {output_path}.")


import pandas as pd

# Load the saved CSV file
output_path = '/mnt/data00/share_data/results/autogen/gpt-4o/sedr/agent_output/sedr.csv'
imputed_df = pd.read_csv(output_path, index_col=0)

# Validate the file format
print("CSV file format validated.")

# Check data consistency
# Ensure the dimensions match the original data
assert imputed_df.shape == adata.obsm['de_feat'].shape, "Data dimensions do not match."

# Check for any missing values in the imputed data
missing_values_after_imputation = imputed_df.isnull().sum().sum()
assert missing_values_after_imputation == 0, "There are missing values in the imputed data."

print("Data consistency validated. No missing values found.")

# Additional validation steps can include checking specific gene expression patterns or statistical properties
# For example, checking the range of values to ensure they are biologically plausible
min_value, max_value = imputed_df.min().min(), imputed_df.max().max()
print(f"Value range in imputed data: {min_value} to {max_value}")

print("Validation completed successfully.")
