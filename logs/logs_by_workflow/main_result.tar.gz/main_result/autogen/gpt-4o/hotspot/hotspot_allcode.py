
import scanpy as sc

# Load the Slide-seq data into an AnnData object
adata = sc.read_h5ad('/mnt/data00/share_data/agent_benchmark/hotspot/rodriques_slideseq.h5ad')

# Check the structure of the loaded data
print(adata)


import scanpy as sc

# Normalize the data
sc.pp.normalize_total(adata, target_sum=1e4)
# Logarithmize the data
sc.pp.log1p(adata)

# Scale the data to unit variance and zero mean
sc.pp.scale(adata)

# Check for missing values and handle them if necessary
# In this case, we assume the data is complete, but you can add imputation steps if needed

# Check for outliers
# Here, we assume the data is preprocessed to remove outliers, but you can add filtering steps if needed

# Print the summary of the preprocessed data
print(adata)


import hotspot

# Initialize the Hotspot object
# We will use the 'spatial' coordinates from adata.obsm as the latent space
hs = hotspot.Hotspot(
    adata,
    model='danb',  # Depth-Adjusted Negative Binomial model
    latent_obsm_key='spatial'  # Use spatial coordinates for cell-cell similarities
)

# Create the KNN graph
hs.create_knn_graph(weighted_graph=False, n_neighbors=30, neighborhood_factor=3, approx_neighbors=True)

# Print a summary to verify initialization
print("Hotspot object initialized and KNN graph created.")


import scanpy as sc
import hotspot

# Filter out genes with all zero counts
sc.pp.filter_genes(adata, min_counts=1)

# Re-initialize the Hotspot object
hs = hotspot.Hotspot(
    adata,
    model='danb',  # Depth-Adjusted Negative Binomial model
    latent_obsm_key='spatial'  # Use spatial coordinates for cell-cell similarities
)

# Create the KNN graph
hs.create_knn_graph(weighted_graph=False, n_neighbors=30, neighborhood_factor=3, approx_neighbors=True)

# Print a summary to verify initialization
print("Hotspot object initialized and KNN graph created.")


# Compute local autocorrelations to identify spatially variable genes
results = hs.compute_autocorrelations(jobs=4)  # Use 4 parallel jobs for faster computation

# Display the top results
print(results.head())

# The results DataFrame contains columns: 'C' (autocorrelation coefficients), 'Z' (Z-score), 'Pval' (P-values), and 'FDR' (Q-values)


# Ensure the data is in the correct format
# Convert the data to a dense format if it's sparse
if not isinstance(adata.X, np.ndarray):
    adata.X = adata.X.toarray()

# Re-run the Hotspot analysis
results = hs.compute_autocorrelations(jobs=4)  # Use 4 parallel jobs for faster computation

# Display the top results
print(results.head())


import numpy as np

# Ensure the data is in the correct format
# Convert the data to a dense format if it's sparse
if not isinstance(adata.X, np.ndarray):
    adata.X = adata.X.toarray()

# Re-run the Hotspot analysis
results = hs.compute_autocorrelations(jobs=4)  # Use 4 parallel jobs for faster computation

# Display the top results
print(results.head())


import numpy as np
import pandas as pd

# Ensure the data is in the correct format
# Convert the data to a dense format if it's sparse
if not isinstance(adata.X, np.ndarray):
    adata.X = adata.X.toarray()

# Check for NaN values and replace them with zeros
adata.X = np.nan_to_num(adata.X)

# Re-run the Hotspot analysis
results = hs.compute_autocorrelations(jobs=4)  # Use 4 parallel jobs for faster computation

# Display the top results
print(results.head())


import numpy as np
import pandas as pd

# Ensure the data is in the correct format
# Convert the data to a dense format if it's sparse
if not isinstance(adata.X, np.ndarray):
    adata.X = adata.X.toarray()

# Convert the data to float type to ensure compatibility
adata.X = adata.X.astype(np.float64)

# Check for NaN values and replace them with zeros
adata.X = np.nan_to_num(adata.X)

# Re-run the Hotspot analysis
results = hs.compute_autocorrelations(jobs=4)  # Use 4 parallel jobs for faster computation

# Display the top results
print(results.head())


import numpy as np
import pandas as pd

# Ensure the data is in the correct format
# Convert the data to a dense format if it's sparse
if not isinstance(adata.X, np.ndarray):
    adata.X = adata.X.toarray()

# Convert the data to float type to ensure compatibility
adata.X = adata.X.astype(np.float64)

# Check for NaN values and replace them with zeros
adata.X = np.nan_to_num(adata.X)

# Check for any infinite values and replace them with zeros
adata.X[np.isinf(adata.X)] = 0

# Re-run the Hotspot analysis
results = hs.compute_autocorrelations(jobs=4)  # Use 4 parallel jobs for faster computation

# Display the top results
print(results.head())


import numpy as np
import pandas as pd

# Ensure the data is in the correct format
# Convert the data to a dense format if it's sparse
if not isinstance(adata.X, np.ndarray):
    adata.X = adata.X.toarray()

# Convert the data to float type to ensure compatibility
adata.X = adata.X.astype(np.float64)

# Check for NaN values and replace them with zeros
adata.X = np.nan_to_num(adata.X)

# Check for any infinite values and replace them with zeros
adata.X[np.isinf(adata.X)] = 0

# Re-run the Hotspot analysis
results = hs.compute_autocorrelations(jobs=4)  # Use 4 parallel jobs for faster computation

# Display the top results
print(results.head())


import numpy as np
import pandas as pd

# Ensure the data is in the correct format
# Convert the data to a dense format if it's sparse
if not isinstance(adata.X, np.ndarray):
    adata.X = adata.X.toarray()

# Convert the data to float type to ensure compatibility
adata.X = adata.X.astype(np.float64)

# Check for NaN values and replace them with zeros
adata.X = np.nan_to_num(adata.X)

# Check for any infinite values and replace them with zeros
adata.X[np.isinf(adata.X)] = 0

# Re-run the Hotspot analysis
results = hs.compute_autocorrelations(jobs=4)  # Use 4 parallel jobs for faster computation

# Display the top results
print(results.head())


import numpy as np
import pandas as pd

# Ensure the data is in the correct format
# Convert the data to a dense format if it's sparse
if not isinstance(adata.X, np.ndarray):
    adata.X = adata.X.toarray()

# Convert the data to float type to ensure compatibility
adata.X = adata.X.astype(np.float64)

# Check for NaN values and replace them with zeros
adata.X = np.nan_to_num(adata.X)

# Check for any infinite values and replace them with zeros
adata.X[np.isinf(adata.X)] = 0

# Re-run the Hotspot analysis
results = hs.compute_autocorrelations(jobs=4)  # Use 4 parallel jobs for faster computation

# Display the top results
print(results.head())


import numpy as np
import pandas as pd

# Ensure the data is in the correct format
# Convert the data to a dense format if it's sparse
if not isinstance(adata.X, np.ndarray):
    adata.X = adata.X.toarray()

# Convert the data to float type to ensure compatibility
adata.X = adata.X.astype(np.float64)

# Check for NaN values and replace them with zeros
adata.X = np.nan_to_num(adata.X)

# Check for any infinite values and replace them with zeros
adata.X[np.isinf(adata.X)] = 0

# Re-run the Hotspot analysis
results = hs.compute_autocorrelations(jobs=4)  # Use 4 parallel jobs for faster computation

# Display the top results
print(results.head())
