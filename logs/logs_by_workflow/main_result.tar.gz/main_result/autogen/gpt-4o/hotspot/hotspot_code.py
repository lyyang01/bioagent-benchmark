
import scanpy as sc

# Load the Slide-seq data into an AnnData object
adata = sc.read_h5ad('/mnt/data00/share_data/agent_benchmark/hotspot/rodriques_slideseq.h5ad')

# Check the structure of the loaded data
print(adata)


import scanpy as sc

# Normalize the data
sc.pp.normalize_total(adata, target_sum=1e4)
# Logarithmize the data
sc.pp.log1p(adata)

# Scale the data to unit variance and zero mean
sc.pp.scale(adata)

# Check for missing values and handle them if necessary
# In this case, we assume the data is complete, but you can add imputation steps if needed

# Check for outliers
# Here, we assume the data is preprocessed to remove outliers, but you can add filtering steps if needed

# Print the summary of the preprocessed data
print(adata)


import scanpy as sc
import hotspot

# Filter out genes with all zero counts
sc.pp.filter_genes(adata, min_counts=1)

# Re-initialize the Hotspot object
hs = hotspot.Hotspot(
    adata,
    model='danb',  # Depth-Adjusted Negative Binomial model
    latent_obsm_key='spatial'  # Use spatial coordinates for cell-cell similarities
)

# Create the KNN graph
hs.create_knn_graph(weighted_graph=False, n_neighbors=30, neighborhood_factor=3, approx_neighbors=True)

# Print a summary to verify initialization
print("Hotspot object initialized and KNN graph created.")
