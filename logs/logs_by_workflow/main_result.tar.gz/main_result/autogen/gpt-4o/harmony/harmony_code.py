
import anndata as ad

# Load the AnnData object from the specified location
adata = ad.read_h5ad('/mnt/data00/share_data/agent_benchmark/harmony/lung_atlas.h5ad')

# Check the loaded data
print(adata)


import scanpy as sc

# Preprocessing steps for Harmony integration

# Step 1: Normalize the data
# Normalize the data to 10,000 reads per cell, so that counts become comparable among cells
sc.pp.normalize_total(adata, target_sum=1e4)

# Step 2: Logarithmize the data
# Logarithmize the data to stabilize the variance
sc.pp.log1p(adata)

# Step 3: Identify highly variable genes
# Select the top 2000 highly variable genes for further analysis
sc.pp.highly_variable_genes(adata, n_top_genes=2000, subset=True)

# Step 4: Scale the data
# Scale each gene to unit variance and zero mean
sc.pp.scale(adata, max_value=10)

# Step 5: Perform PCA
# Perform PCA to reduce dimensionality before Harmony integration
sc.tl.pca(adata, svd_solver='arpack')

# Check the preprocessed data
print(adata)


import scanpy.external as sce

# Perform Harmony integration using the 'batch' key
# This will align the data across different batches using the PCA results
sce.pp.harmony_integrate(adata, key='batch', basis='X_pca', adjusted_basis='X_harmony')

# Check the integrated data
print(adata.obsm['X_harmony'])


# Save the integrated AnnData object to the specified output path
output_path = '/mnt/data00/share_data/results/autogen/gpt-4o/harmony/agent_output/harmony.h5ad'
adata.write(output_path)

# Confirm the file has been saved
print(f"Integrated data saved to {output_path}")


# Load the saved AnnData object to verify its contents
loaded_adata = ad.read_h5ad('/mnt/data00/share_data/results/autogen/gpt-4o/harmony/agent_output/harmony.h5ad')

# Check if 'X_harmony' is present in the loaded data
if 'X_harmony' in loaded_adata.obsm:
    print("Verification successful: 'X_harmony' is present in the loaded data.")
else:
    print("Verification failed: 'X_harmony' is not present in the loaded data.")
