
import anndata as ad

# Load the spatial transcriptomics data
spatial_data_path = '/mnt/data00/share_data/agent_benchmark/tangram/visium_fluo_adata_crop.h5ad'
spatial_data = ad.read_h5ad(spatial_data_path)

# Load the scRNA-seq data
scrna_data_path = '/mnt/data00/share_data/agent_benchmark/tangram/sc_mouse_cortex.h5ad'
scrna_data = ad.read_h5ad(scrna_data_path)

# Check the loaded data
print("Spatial Data:", spatial_data)
print("scRNA-seq Data:", scrna_data)


import scanpy as sc

# Ensure common genes between the datasets
common_genes = spatial_data.var_names.intersection(scrna_data.var_names)
spatial_data = spatial_data[:, common_genes]
scrna_data = scrna_data[:, common_genes]

# Normalize the spatial data
sc.pp.normalize_total(spatial_data, target_sum=1e4)
sc.pp.log1p(spatial_data)

# Normalize the scRNA-seq data
sc.pp.normalize_total(scrna_data, target_sum=1e4)
sc.pp.log1p(scrna_data)

# Scale the data
sc.pp.scale(spatial_data)
sc.pp.scale(scrna_data)

# Check the preprocessed data
print("Preprocessed Spatial Data:", spatial_data)
print("Preprocessed scRNA-seq Data:", scrna_data)


from scvi.external import Tangram
import mudata

# Create a MuData object with both spatial and scRNA-seq data
mdata = mudata.MuData({
    "sp": spatial_data,
    "sc": scrna_data
})

# Setup Tangram with the MuData object
Tangram.setup_mudata(
    mdata,
    density_prior_key='rna_count_based',  # Use RNA count based density prior
    modalities={"density_prior_key": "sp", "sc_layer": "sc", "sp_layer": "sp"}
)

# Initialize Tangram with the scRNA-seq data
tangram = Tangram(scrna_data)

# Train the Tangram model
tangram.train(max_epochs=1000, accelerator='auto', devices='auto', lr=0.1)

# Get the mapper matrix
mapper_matrix = tangram.get_mapper_matrix()

# Project cell annotations from scRNA-seq to spatial data
spatial_data.obsm["tangram_cts"] = tangram.project_cell_annotations(
    scrna_data, spatial_data, mapper_matrix, scrna_data.obs["cell_subclass"]
)

# Check the results
print("Tangram Mapping Results:", spatial_data.obsm["tangram_cts"])


from scvi.external import Tangram
import mudata

# Check if 'total_counts' can be used as a density prior
if 'total_counts' in spatial_data.obs:
    density_prior_key = 'total_counts'
else:
    # Create a density prior based on total counts if it doesn't exist
    spatial_data.obs['density_prior'] = spatial_data.obs['total_counts']
    density_prior_key = 'density_prior'

# Create a MuData object with both spatial and scRNA-seq data
mdata = mudata.MuData({
    "sp": spatial_data,
    "sc": scrna_data
})

# Setup Tangram with the MuData object
Tangram.setup_mudata(
    mdata,
    density_prior_key=density_prior_key,  # Use the available density prior
    modalities={"density_prior_key": "sp", "sc_layer": "sc", "sp_layer": "sp"}
)

# Initialize Tangram with the scRNA-seq data
tangram = Tangram(scrna_data)

# Train the Tangram model
tangram.train(max_epochs=1000, accelerator='auto', devices='auto', lr=0.1)

# Get the mapper matrix
mapper_matrix = tangram.get_mapper_matrix()

# Project cell annotations from scRNA-seq to spatial data
spatial_data.obsm["tangram_cts"] = tangram.project_cell_annotations(
    scrna_data, spatial_data, mapper_matrix, scrna_data.obs["cell_subclass"]
)

# Check the results
print("Tangram Mapping Results:", spatial_data.obsm["tangram_cts"])


from scvi.external import Tangram
import mudata

# Setup the AnnData objects for Tangram
Tangram.setup_anndata(scrna_data)
Tangram.setup_anndata(spatial_data)

# Create a MuData object with both spatial and scRNA-seq data
mdata = mudata.MuData({
    "sp": spatial_data,
    "sc": scrna_data
})

# Setup Tangram with the MuData object
Tangram.setup_mudata(
    mdata,
    density_prior_key='total_counts',  # Use total counts as density prior
    modalities={"density_prior_key": "sp", "sc_layer": "sc", "sp_layer": "sp"}
)

# Initialize Tangram with the scRNA-seq data
tangram = Tangram(scrna_data)

# Train the Tangram model
tangram.train(max_epochs=1000, accelerator='auto', devices='auto', lr=0.1)

# Get the mapper matrix
mapper_matrix = tangram.get_mapper_matrix()

# Project cell annotations from scRNA-seq to spatial data
spatial_data.obsm["tangram_cts"] = tangram.project_cell_annotations(
    scrna_data, spatial_data, mapper_matrix, scrna_data.obs["cell_subclass"]
)

# Check the results
print("Tangram Mapping Results:", spatial_data.obsm["tangram_cts"])


from scvi.external import Tangram
import mudata

# Setup the AnnData objects for Tangram
Tangram.setup_anndata(scrna_data)
Tangram.setup_anndata(spatial_data)

# Create a MuData object with both spatial and scRNA-seq data
mdata = mudata.MuData({
    "sp": spatial_data,
    "sc": scrna_data
})

# Setup Tangram with the MuData object
Tangram.setup_mudata(
    mdata,
    density_prior_key='total_counts',  # Use total counts as density prior
    modalities={"density_prior_key": "sp", "sc_layer": "sc", "sp_layer": "sp"}
)

# Initialize Tangram with the scRNA-seq data
tangram = Tangram(scrna_data)

# Train the Tangram model
tangram.train(max_epochs=1000, accelerator='auto', devices='auto', lr=0.1)

# Get the mapper matrix
mapper_matrix = tangram.get_mapper_matrix()

# Project cell annotations from scRNA-seq to spatial data
spatial_data.obsm["tangram_cts"] = tangram.project_cell_annotations(
    scrna_data, spatial_data, mapper_matrix, scrna_data.obs["cell_subclass"]
)

# Check the results
print("Tangram Mapping Results:", spatial_data.obsm["tangram_cts"])


from scvi.external import Tangram
import mudata

# Setup the AnnData objects for Tangram
Tangram.setup_anndata(scrna_data)
Tangram.setup_anndata(spatial_data)

# Create a MuData object with both spatial and scRNA-seq data
mdata = mudata.MuData({
    "sp": spatial_data,
    "sc": scrna_data
})

# Setup Tangram with the MuData object
Tangram.setup_mudata(
    mdata,
    density_prior_key='total_counts',  # Use total counts as density prior
    modalities={"density_prior_key": "sp", "sc_layer": "sc", "sp_layer": "sp"}
)

# Initialize Tangram with the scRNA-seq data
tangram = Tangram(scrna_data)

# Train the Tangram model
tangram.train(max_epochs=1000, accelerator='auto', devices='auto', lr=0.1)

# Get the mapper matrix
mapper_matrix = tangram.get_mapper_matrix()

# Project cell annotations from scRNA-seq to spatial data
spatial_data.obsm["tangram_cts"] = tangram.project_cell_annotations(
    scrna_data, spatial_data, mapper_matrix, scrna_data.obs["cell_subclass"]
)

# Check the results
print("Tangram Mapping Results:", spatial_data.obsm["tangram_cts"])
