
import anndata as ad

# Load the spatial transcriptomics data
spatial_data_path = '/mnt/data00/share_data/agent_benchmark/tangram/visium_fluo_adata_crop.h5ad'
spatial_data = ad.read_h5ad(spatial_data_path)

# Load the scRNA-seq data
scrna_data_path = '/mnt/data00/share_data/agent_benchmark/tangram/sc_mouse_cortex.h5ad'
scrna_data = ad.read_h5ad(scrna_data_path)

# Check the loaded data
print("Spatial Data:", spatial_data)
print("scRNA-seq Data:", scrna_data)


import scanpy as sc

# Ensure common genes between the datasets
common_genes = spatial_data.var_names.intersection(scrna_data.var_names)
spatial_data = spatial_data[:, common_genes]
scrna_data = scrna_data[:, common_genes]

# Normalize the spatial data
sc.pp.normalize_total(spatial_data, target_sum=1e4)
sc.pp.log1p(spatial_data)

# Normalize the scRNA-seq data
sc.pp.normalize_total(scrna_data, target_sum=1e4)
sc.pp.log1p(scrna_data)

# Scale the data
sc.pp.scale(spatial_data)
sc.pp.scale(scrna_data)

# Check the preprocessed data
print("Preprocessed Spatial Data:", spatial_data)
print("Preprocessed scRNA-seq Data:", scrna_data)
