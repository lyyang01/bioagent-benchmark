
import scanpy as sc
import os

# Path to 10X scATAC-seq filtered_peak_bc_matrix directory
input_dir = '/mnt/data00/share_data/agent_benchmark/poissonvi/atac_pbmc_5k.untar/filtered_peak_bc_matrix'

# Load 10X scATAC-seq data as AnnData object
# This will read the matrix.mtx, barcodes.tsv, and peaks/features.tsv files
adata = sc.read_10x_mtx(input_dir, var_names='gene_symbols', make_unique=True)

# Biological context:
# - Rows: peaks (genomic regions)
# - Columns: cells
# - Values: fragment counts (quantitative accessibility)

# Quality control: filter out low-quality cells and peaks
# 1. Filter cells with very low total counts (likely empty droplets or low-quality cells)
sc.pp.filter_cells(adata, min_counts=1000)  # adjust threshold as needed for scATAC-seq
# 2. Filter peaks detected in very few cells (likely noise)
sc.pp.filter_genes(adata, min_cells=10)     # adjust threshold as needed for scATAC-seq

# Save the filtered AnnData object for downstream analysis
os.makedirs('/mnt/data00/share_data/results/autogen/gpt-4.1/poissonvi/agent_output', exist_ok=True)
adata.write_h5ad('/mnt/data00/share_data/results/autogen/gpt-4.1/poissonvi/agent_output/filtered_atac_pbmc_5k.h5ad')

# The AnnData object is now ready for PoissonVI and contains a filtered count matrix


import scanpy as sc
import os

# Check the files in the directory to determine the correct file names and compression
input_dir = '/mnt/data00/share_data/agent_benchmark/poissonvi/atac_pbmc_5k.untar/filtered_peak_bc_matrix'
print("Files in input directory:", os.listdir(input_dir))

# Try loading with .gz extension if present
# 10X scATAC-seq data may use 'features.tsv.gz' and 'matrix.mtx.gz' instead of uncompressed files
adata = sc.read_10x_mtx(input_dir, var_names='gene_symbols', make_unique=True)

# Quality control: filter out low-quality cells and peaks
sc.pp.filter_cells(adata, min_counts=1000)  # adjust threshold as needed for scATAC-seq
sc.pp.filter_genes(adata, min_cells=10)     # adjust threshold as needed for scATAC-seq

# Save the filtered AnnData object for downstream analysis
os.makedirs('/mnt/data00/share_data/results/autogen/gpt-4.1/poissonvi/agent_output', exist_ok=True)
adata.write_h5ad('/mnt/data00/share_data/results/autogen/gpt-4.1/poissonvi/agent_output/filtered_atac_pbmc_5k.h5ad')


import os

input_dir = '/mnt/data00/share_data/agent_benchmark/poissonvi/atac_pbmc_5k.untar/filtered_peak_bc_matrix'

# List all files in the input directory to diagnose file naming and compression
files = os.listdir(input_dir)
print("Files in input directory:", files)


import scanpy as sc
import os

input_dir = '/mnt/data00/share_data/agent_benchmark/poissonvi/atac_pbmc_5k.untar/filtered_peak_bc_matrix'

# Load 10X scATAC-seq data using uncompressed files
# Use var_names='gene_symbols' to use the second column of features.tsv (peak names)
adata = sc.read_10x_mtx(input_dir, var_names='gene_symbols', make_unique=True)

# Biological context:
# - Rows: peaks (genomic regions)
# - Columns: cells
# - Values: fragment counts (quantitative accessibility)

# Quality control: filter out low-quality cells and peaks
# 1. Filter cells with very low total counts (likely empty droplets or low-quality cells)
sc.pp.filter_cells(adata, min_counts=1000)  # Cells with <1000 fragments are removed
# 2. Filter peaks detected in very few cells (likely noise)
sc.pp.filter_genes(adata, min_cells=10)     # Peaks in <10 cells are removed

# Save the filtered AnnData object for downstream analysis
os.makedirs('/mnt/data00/share_data/results/autogen/gpt-4.1/poissonvi/agent_output', exist_ok=True)
adata.write_h5ad('/mnt/data00/share_data/results/autogen/gpt-4.1/poissonvi/agent_output/filtered_atac_pbmc_5k.h5ad')


import scanpy as sc
import anndata as ad
import pandas as pd
import scipy.io
import scipy.sparse
import os

input_dir = '/mnt/data00/share_data/agent_benchmark/poissonvi/atac_pbmc_5k.untar/filtered_peak_bc_matrix'

# Manually load the uncompressed 10X files since scanpy.read_10x_mtx expects .gz files in some versions
matrix = scipy.io.mmread(os.path.join(input_dir, "matrix.mtx")).T.tocsr()  # Transpose to cells x peaks
barcodes = pd.read_csv(os.path.join(input_dir, "barcodes.tsv"), header=None)[0].values
features = pd.read_csv(os.path.join(input_dir, "features.tsv"), header=None, sep='\t')

# Use peak names as var_names
peak_names = features[1].values

# Construct AnnData object
adata = ad.AnnData(X=matrix)
adata.obs_names = barcodes
adata.var_names = peak_names

# Quality control: filter out low-quality cells and peaks
sc.pp.filter_cells(adata, min_counts=1000)  # Remove cells with <1000 fragments
sc.pp.filter_genes(adata, min_cells=10)     # Remove peaks in <10 cells

# Save the filtered AnnData object for downstream analysis
os.makedirs('/mnt/data00/share_data/results/autogen/gpt-4.1/poissonvi/agent_output', exist_ok=True)
adata.write_h5ad('/mnt/data00/share_data/results/autogen/gpt-4.1/poissonvi/agent_output/filtered_atac_pbmc_5k.h5ad')


import scanpy as sc
import scvi

# Load the filtered AnnData object
adata = sc.read_h5ad('/mnt/data00/share_data/results/autogen/gpt-4.1/poissonvi/agent_output/filtered_atac_pbmc_5k.h5ad')

# PoissonVI (scvi-tools) expects:
# - adata.X: raw count matrix (cells x peaks)
# - adata.obs: cell metadata (can be empty, but batch/covariate columns can be added if needed)
# - adata.var: peak metadata (can be empty, but peak names should be present)
# - No need for special layers unless you want to use a specific one

# Setup AnnData for PoissonVI (using Poisson likelihood)
# If you have batch or covariate information, add the relevant keys in adata.obs and specify batch_key, etc.
scvi.model.PoissonVI.setup_anndata(adata)

# Save the prepared AnnData object (optional, for reproducibility)
adata.write_h5ad('/mnt/data00/share_data/results/autogen/gpt-4.1/poissonvi/agent_output/filtered_atac_pbmc_5k_poissonvi_ready.h5ad')


import scanpy as sc
import scvi

# Load the filtered AnnData object
adata = sc.read_h5ad('/mnt/data00/share_data/results/autogen/gpt-4.1/poissonvi/agent_output/filtered_atac_pbmc_5k.h5ad')

# PoissonVI is implemented as scvi.model.SCVI with gene_likelihood='poisson'
# Prepare AnnData for SCVI/PoissonVI
scvi.model.SCVI.setup_anndata(adata)

# Save the prepared AnnData object (optional, for reproducibility)
adata.write_h5ad('/mnt/data00/share_data/results/autogen/gpt-4.1/poissonvi/agent_output/filtered_atac_pbmc_5k_poissonvi_ready.h5ad')


import scanpy as sc
import scvi

# Load the prepared AnnData object
adata = sc.read_h5ad('/mnt/data00/share_data/results/autogen/gpt-4.1/poissonvi/agent_output/filtered_atac_pbmc_5k_poissonvi_ready.h5ad')

# Initialize SCVI model with Poisson likelihood (PoissonVI)
model = scvi.model.SCVI(adata, gene_likelihood='poisson')

# Train the model (use GPU if available for speed)
model.train(accelerator='auto', devices='auto')

# Extract the latent representation
latent = model.get_latent_representation()

# Store the latent representation in obsm['X_poissonvi']
adata.obsm['X_poissonvi'] = latent

# Save the updated AnnData object for downstream analysis and export
adata.write_h5ad('/mnt/data00/share_data/results/autogen/gpt-4.1/poissonvi/agent_output/filtered_atac_pbmc_5k_poissonvi_latent.h5ad')


import scanpy as sc
import scvi

# Load the filtered AnnData object
adata = sc.read_h5ad('/mnt/data00/share_data/results/autogen/gpt-4.1/poissonvi/agent_output/filtered_atac_pbmc_5k.h5ad')

# Setup AnnData for SCVI/PoissonVI (must be done in the same session as model initialization)
scvi.model.SCVI.setup_anndata(adata)

# Initialize SCVI model with Poisson likelihood (PoissonVI)
model = scvi.model.SCVI(adata, gene_likelihood='poisson')

# Train the model (use GPU if available for speed)
model.train(accelerator='auto', devices='auto')

# Extract the latent representation
latent = model.get_latent_representation()

# Store the latent representation in obsm['X_poissonvi']
adata.obsm['X_poissonvi'] = latent

# Save the updated AnnData object for downstream analysis and export
adata.write_h5ad('/mnt/data00/share_data/results/autogen/gpt-4.1/poissonvi/agent_output/filtered_atac_pbmc_5k_poissonvi_latent.h5ad')


import scanpy as sc
import pandas as pd

# Load the AnnData object with PoissonVI latent representation
adata = sc.read_h5ad('/mnt/data00/share_data/results/autogen/gpt-4.1/poissonvi/agent_output/filtered_atac_pbmc_5k_poissonvi_latent.h5ad')

# Extract the latent representation from obsm
latent_df = pd.DataFrame(
    adata.obsm['X_poissonvi'],
    index=adata.obs_names
)

# Save as CSV
latent_df.to_csv('/mnt/data00/share_data/results/autogen/gpt-4.1/poissonvi/agent_output/poissonvi.csv')


import scanpy as sc
import scvi
import numpy as np
import pandas as pd

# Load the AnnData object with latent representation
adata = sc.read_h5ad('/mnt/data00/share_data/results/autogen/gpt-4.1/poissonvi/agent_output/filtered_atac_pbmc_5k_poissonvi_latent.h5ad')

# If no cluster/group info, perform clustering on the PoissonVI latent space
if 'leiden' not in adata.obs:
    # Use the latent space for clustering
    adata.obsm['X_pca'] = adata.obsm['X_poissonvi']
    sc.pp.neighbors(adata, use_rep='X_poissonvi')
    sc.tl.leiden(adata, key_added='leiden')

# Setup AnnData for SCVI again (required for differential expression)
scvi.model.SCVI.setup_anndata(adata, labels_key='leiden')

# Re-initialize the model (must be same session as setup)
model = scvi.model.SCVI(adata, gene_likelihood='poisson')

# Differential accessibility analysis between clusters
# Compare all clusters to each other (one-vs-rest for each cluster)
de_results = []
for cluster in adata.obs['leiden'].unique():
    res = model.differential_expression(
        groupby="leiden",
        group1=cluster,
        mode="change",  # log fold change and p-value
        delta=0.5,      # minimum log fold change threshold
        batch_correction=False
    )
    res['cluster'] = cluster
    de_results.append(res)

# Concatenate all results
de_df = pd.concat(de_results, keys=adata.obs['leiden'].unique(), names=['cluster', 'row'])

# Save the results
de_df.to_csv('/mnt/data00/share_data/results/autogen/gpt-4.1/poissonvi/agent_output/poissonvi_differential_accessibility.csv')

# Biological note:
# - This identifies peaks (regions) that are differentially accessible between clusters found in the latent space.
# - Results include log fold change, p-value, and other statistics for each peak.


# The file 'poissonvi_differential_accessibility.csv' has already been saved in the correct output directory.
# For documentation, create a simple README.txt to describe the file.

readme_content = """\
poissonvi_differential_accessibility.csv
----------------------------------------
This file contains the results of differential accessibility analysis for scATAC-seq peaks
using PoissonVI (SCVI with gene_likelihood='poisson').

- Each row corresponds to a peak (genomic region).
- Results are grouped by clusters identified in the PoissonVI latent space (Leiden clustering).
- Columns include log fold change, p-value, and other statistics for each peak in each cluster.

File generated by PoissonVI pipeline.
"""

with open('/mnt/data00/share_data/results/autogen/gpt-4.1/poissonvi/agent_output/README.txt', 'w') as f:
    f.write(readme_content)
