
# Load the scRNA-seq dataset from the provided .rda file location
# Biological context: This file is expected to contain a gene expression matrix and possibly metadata for single-cell RNA-seq analysis.

# Set the path to the input .rda file
input_rda_path <- "/mnt/data00/share_data/agent_benchmark/singlecellhaystack/scRNAseq_thymus.rda"

# Load the .rda file into the R environment
load(input_rda_path)

# List loaded objects to confirm successful import
print(ls())


# Inspect the structure of the loaded objects to ensure compatibility with singleCellHaystack

# singleCellHaystack expects:
# - x: a matrix of cell coordinates (e.g., PCA or t-SNE)
# - expression: a matrix of gene expression (genes as rows, cells as columns)

# Check the structure of each loaded object
str(dat.expression)  # Should be a matrix: genes (rows) x cells (columns)
str(dat.pca)         # Should be a matrix or data.frame: cells (rows) x PC dimensions (columns)
str(dat.tsne)        # Should be a matrix or data.frame: cells (rows) x tSNE dimensions (columns)

# Print dimensions for clarity
cat("Expression matrix dimensions (genes x cells):", dim(dat.expression), "\n")
cat("PCA matrix dimensions (cells x PCs):", dim(dat.pca), "\n")
cat("tSNE matrix dimensions (cells x tSNE dims):", dim(dat.tsne), "\n")


# Apply singleCellHaystack to identify highly variable genes using PCA coordinates

library(singleCellHaystack)

# Biological context:
# - 'dat.pca' provides the cell coordinates in PCA space (cells x PCs)
# - 'dat.expression' is the gene expression matrix (genes x cells)
# - haystack will identify genes with spatially variable expression patterns in the reduced PCA space

# Transpose dat.pca to matrix if needed (haystack expects a matrix, not a data.frame)
pca_matrix <- as.matrix(dat.pca)

# Run haystack analysis
haystack_result <- haystack(
  x = pca_matrix,           # cell coordinates (cells x PCs)
  expression = dat.expression # gene expression (genes x cells)
)

# Save the result object for further processing
save(haystack_result, file = "/mnt/data00/share_data/results/autogen/gpt-4.1/singlecellhaystack/agent_output/haystack_result.RData")


# Extract the list of highly variable genes from the haystack_result object

# Biological context:
# - Highly variable genes are those with significant spatial expression patterns in the PCA space
# - show_result_haystack returns a data.frame with gene names and statistics, sorted by significance

# Load the result if not already in memory
if (!exists("haystack_result")) {
  load("/mnt/data00/share_data/results/autogen/gpt-4.1/singlecellhaystack/agent_output/haystack_result.RData")
}

# Retrieve all results, sorted by significance (lowest p-value first)
haystack_table <- show_result_haystack(haystack_result)

# Extract gene names (all, or you can filter by p-value threshold if desired)
highly_variable_genes <- rownames(haystack_table)

# Print the number of highly variable genes detected
cat("Number of genes analyzed:", length(highly_variable_genes), "\n")


# Save the set of highly variable gene names as an RData file

output_path <- "/mnt/data00/share_data/results/autogen/gpt-4.1/singlecellhaystack/agent_output/singlecellhaystack.RData"

# Save the gene names vector
save(highly_variable_genes, file = output_path)
