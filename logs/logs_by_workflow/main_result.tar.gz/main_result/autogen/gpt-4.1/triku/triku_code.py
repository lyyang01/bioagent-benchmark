
# Step 1: Load the AnnData object (single-cell RNA-seq data)
import scanpy as sc

# Biological context: AnnData is the standard data structure for single-cell omics data in Python.
input_path = '/mnt/data00/share_data/agent_benchmark/triku/pbmc3k_raw.h5ad'
pbmc = sc.read_h5ad(input_path)

# Confirm loading by printing shape (cells x genes)
print(f"Loaded AnnData object with shape: {pbmc.shape}")


# Recommended preprocessing for Triku feature selection on single-cell RNA-seq data:
# 1. Filter out low-quality cells and genes (e.g., genes expressed in very few cells)
# 2. Normalize the data (e.g., total-count normalization per cell)
# 3. Log-transform the data (log1p)

import scanpy as sc

# Filter genes expressed in less than 3 cells (common threshold)
sc.pp.filter_genes(pbmc, min_cells=3)

# Filter cells with very low gene counts (optional, e.g., less than 200 genes)
sc.pp.filter_cells(pbmc, min_genes=200)

# Normalize total counts per cell to 1e4 (CPM-like normalization)
sc.pp.normalize_total(pbmc, target_sum=1e4)

# Log-transform the data (log1p for biological interpretability)
sc.pp.log1p(pbmc)

# Biological note: These steps ensure that technical biases are minimized and that Triku receives biologically meaningful input.
print("Preprocessing complete. Data shape after filtering:", pbmc.shape)


# Triku requires a neighborhood graph to be computed first (sc.pp.neighbors).
# This step computes a k-nearest neighbors graph of cells, which is essential for Triku's local expression analysis.

import scanpy as sc

# Compute PCA for neighborhood graph construction (recommended for scRNA-seq)
sc.pp.pca(pbmc, n_comps=50)

# Compute the neighborhood graph (default n_neighbors=15 is typical for scRNA-seq)
sc.pp.neighbors(pbmc, n_pcs=50, n_neighbors=15)

# Now re-run Triku
import triku
pbmc.raw = pbmc  # Ensure .raw is set for use_raw=True
triku.tl.triku(pbmc, use_raw=True)

# Confirm Triku results
print("Triku feature selection and dimension reduction complete. Shape of X_triku:", pbmc.obsm['X_triku'].shape)


# The Triku results are already stored in pbmc.obsm['X_triku'] by default after running triku.tl.triku.
# No further action is needed for this step, but we can confirm the storage:

assert 'X_triku' in pbmc.obsm, "Triku results not found in pbmc.obsm['X_triku']"
print("Confirmed: Triku dimension reduction results are stored in pbmc.obsm['X_triku']")


import numpy as np
import pandas as pd
import os

# Output directory and file path
output_dir = '/mnt/data00/share_data/results/autogen/gpt-4.1/triku/agent_output'
os.makedirs(output_dir, exist_ok=True)
output_file = os.path.join(output_dir, 'triku.csv')

# Extract the Triku dimension reduction matrix
X_triku = pbmc.obsm['X_triku']
# If it's a sparse matrix, convert to dense
if hasattr(X_triku, "toarray"):
    X_triku = X_triku.toarray()
elif hasattr(X_triku, "data"):
    X_triku = X_triku.data

# Save as CSV
pd.DataFrame(X_triku).to_csv(output_file, index=False)
print(f"Triku dimension reduction results saved to {output_file}")


import os

output_dir = '/mnt/data00/share_data/results/autogen/gpt-4.1/triku/agent_output'
output_file = os.path.join(output_dir, 'triku.csv')

# Verify that 'triku.csv' exists
if os.path.isfile(output_file):
    print(f"Verified: '{output_file}' exists.")
else:
    raise FileNotFoundError(f"Output file '{output_file}' not found.")

# If there are other required output files, list and check them here.
# For this task, only 'triku.csv' is required.
