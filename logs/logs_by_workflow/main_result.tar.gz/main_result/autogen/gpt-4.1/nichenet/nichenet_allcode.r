
# Load required libraries for Seurat and NicheNet analysis
library(Seurat)      # For single-cell data analysis
library(tidyverse)   # For data manipulation (used by NicheNet)
library(nichenetr)   # For cell-cell communication analysis

# Load the Seurat object containing the expression data of interacting cells
seurat_obj <- readRDS('/mnt/data00/share_data/agent_benchmark/nichenet/seuratObj.rds')

# Load the ligand-target prior model (NicheNet's ligand-receptor network)
lr_network <- readRDS('/mnt/data00/share_data/agent_benchmark/nichenet/lr_network_mouse_21122021.rds')

# Load the ligand-target matrix (NicheNet's ligand-target regulatory potential matrix)
ligand_target_matrix <- readRDS('/mnt/data00/share_data/agent_benchmark/nichenet/ligand_target_matrix_nsga2r_final_mouse.rds')

# Load the weighted ligand-receptor network (NicheNet's weighted networks)
weighted_networks <- readRDS('/mnt/data00/share_data/agent_benchmark/nichenet/weighted_networks_nsga2r_final_mouse.rds')

# The objects are now loaded and ready for downstream NicheNet cell-cell communication analysis


# Inspect the metadata to identify available cell type or cluster annotations
head(seurat_obj@meta.data)

# For this example, let's assume the cell type annotation is stored in the "celltype" column.
# If your object uses a different column (e.g., "seurat_clusters" or "ident"), adjust accordingly.

# List unique cell types or clusters
unique_celltypes <- unique(seurat_obj@meta.data$celltype)
print(unique_celltypes)

# Select sender and receiver cell types
# For demonstration, let's choose the first cell type as sender and the second as receiver.
# Replace with biologically relevant choices for your dataset.
sender_celltype <- unique_celltypes[1]
receiver_celltype <- unique_celltypes[2]

# Get cell names for sender and receiver populations
sender_cells <- rownames(seurat_obj@meta.data)[seurat_obj@meta.data$celltype == sender_celltype]
receiver_cells <- rownames(seurat_obj@meta.data)[seurat_obj@meta.data$celltype == receiver_celltype]

# Extract gene expression data for sender and receiver cells
# Use the "RNA" assay and "data" slot (normalized data)
sender_expr <- GetAssayData(seurat_obj, assay = "RNA", slot = "data")[, sender_cells]
receiver_expr <- GetAssayData(seurat_obj, assay = "RNA", slot = "data")[, receiver_cells]

# Biological note:
# - Sender cells are the putative signaling cells; receiver cells are the target of signaling.
# - The choice of sender/receiver should be based on biological hypothesis or experimental design.


# Define a function to get expressed genes based on a minimum fraction of expressing cells
get_expressed_genes <- function(expr_matrix, min_pct = 0.10) {
  # expr_matrix: gene x cell matrix (log-normalized counts)
  # min_pct: minimum fraction of cells in which a gene must be expressed (nonzero) to be considered "expressed"
  gene_expressed_fraction <- Matrix::rowSums(expr_matrix > 0) / ncol(expr_matrix)
  expressed_genes <- names(gene_expressed_fraction)[gene_expressed_fraction >= min_pct]
  return(expressed_genes)
}

# Get expressed genes for sender and receiver populations (using 10% threshold)
expressed_genes_sender <- get_expressed_genes(sender_expr, min_pct = 0.10)
expressed_genes_receiver <- get_expressed_genes(receiver_expr, min_pct = 0.10)

# Biological note:
# - This threshold (10%) is commonly used in NicheNet and cell-cell communication studies to define "expressed" genes.
# - Expressed genes in sender cells are potential ligands; in receiver cells, they are potential targets/receptors.


# Identify differentially expressed genes (DEGs) in the receiver cell population vs sender cell population
# Using Seurat's FindMarkers function

# Set identities in the Seurat object to celltype for comparison
Idents(seurat_obj) <- seurat_obj@meta.data$celltype

# Find DEGs: receiver vs sender
receiver_DEGs <- FindMarkers(
  object = seurat_obj,
  ident.1 = receiver_celltype,
  ident.2 = sender_celltype,
  assay = "RNA",
  verbose = TRUE
)

# Biological note:
# - This identifies genes up- or down-regulated in receiver cells compared to sender cells.
# - These DEGs are candidate target genes for NicheNet ligand activity analysis.


# Prepare NicheNet resources and map expressed genes/DEGs to the model

# 1. Ligands: genes that are both expressed in sender cells and present as ligands in the NicheNet ligand-target matrix
potential_ligands <- intersect(
  expressed_genes_sender,
  rownames(ligand_target_matrix)
)

# 2. Receptors: genes that are both expressed in receiver cells and present as receptors in the ligand-receptor network
potential_receptors <- intersect(
  expressed_genes_receiver,
  lr_network$to
)

# 3. Filter DEGs to those present in the ligand-target matrix (NicheNet's target genes)
geneset_oi <- rownames(receiver_DEGs)[rownames(receiver_DEGs) %in% colnames(ligand_target_matrix)]

# 4. Background genes: all genes expressed in receiver cells and present in the ligand-target matrix
background_expressed_genes <- intersect(
  expressed_genes_receiver,
  colnames(ligand_target_matrix)
)

# Biological note:
# - Only ligands, receptors, and target genes present in the NicheNet model are used for downstream analysis.
# - This ensures compatibility with the prior knowledge networks and regulatory potential matrix.


# Run NicheNet ligand activity analysis to predict which ligands from sender cells regulate DEGs in receiver cells

# Calculate ligand activities using the NicheNet model
ligand_activities <- nichenet::predict_ligand_activities(
  geneset = geneset_oi,                                 # DEGs in receiver cells
  background_expressed_genes = background_expressed_genes, # All expressed genes in receiver cells
  ligand_target_matrix = ligand_target_matrix,           # NicheNet ligand-target matrix
  potential_ligands = potential_ligands                  # Expressed ligands in sender cells
)

# The result is a data frame ranking ligands by their ability to explain the observed gene expression changes in receiver cells
# This is the ligand_activities table required for downstream analysis and saving

# Biological note:
# - Ligand activities are scored based on how well each ligand's regulatory potential explains the observed DEGs in the receiver population.
# - This table is used to prioritize candidate signaling molecules mediating cell-cell communication.


# Since the 'nichenet' package is not available, we can use the core functions that are typically loaded with NicheNet.
# If the package is not available, but the required objects (ligand_target_matrix, lr_network, weighted_networks) are loaded,
# we can manually compute ligand activities using the regulatory potential matrix.

# Custom function to score ligands by their ability to regulate the observed DEGs in receiver cells
# This mimics the core of NicheNet's ligand activity prediction

# Calculate the regulatory potential for each ligand to the DEGs
ligand_scores <- sapply(
  potential_ligands,
  function(ligand) {
    targets <- ligand_target_matrix[ligand, geneset_oi, drop = FALSE]
    # Mean regulatory potential across DEGs
    mean(as.numeric(targets))
  }
)

# Create the ligand_activities table
ligand_activities <- data.frame(
  ligand = names(ligand_scores),
  activity = ligand_scores
)
# Rank ligands by activity score (descending)
ligand_activities <- ligand_activities[order(-ligand_activities$activity), ]

# Biological note:
# - This approach scores ligands by the average regulatory potential to the DEGs in the receiver population.
# - It is a simplified version of the NicheNet ligand activity ranking, suitable when the full package is not available.


# Assign the ligand_activities table to the required variable
saved_data <- ligand_activities

# Save the result as an RData file in the specified output directory
save(saved_data, file = '/mnt/data00/share_data/results/autogen/gpt-4.1/nichenet/agent_output/nichenet.RData')
