
# Step 1: Load the spatial transcriptomics and scRNA-seq data using anndata

import anndata as ad

# Load spatial transcriptomics data (10X Visium, scATACseq sampled from 5K PBMCs)
spatial_adata = ad.read_h5ad('/mnt/data00/share_data/agent_benchmark/tangram/visium_fluo_adata_crop.h5ad')

# Load scRNA-seq reference data (mouse cortex)
scrna_adata = ad.read_h5ad('/mnt/data00/share_data/agent_benchmark/tangram/sc_mouse_cortex.h5ad')

# Check the loaded data shapes for confirmation
print("Spatial data shape:", spatial_adata.shape)
print("scRNA-seq data shape:", scrna_adata.shape)


# Correction: The error is due to an incorrect attempt to use the return value of sc.pp.highly_variable_genes,
# which is None (it modifies the AnnData object in place). The correct approach is to use the 'highly_variable'
# column in .var after running the function.

import scanpy as sc

# 1. Normalize both datasets (log1p normalization is standard for Tangram)
sc.pp.normalize_total(scrna_adata, target_sum=1e4)
sc.pp.log1p(scrna_adata)

sc.pp.normalize_total(spatial_adata, target_sum=1e4)
sc.pp.log1p(spatial_adata)

# 2. Find highly variable genes in scRNA-seq (Tangram recommends using variable genes from scRNA-seq)
sc.pp.highly_variable_genes(scrna_adata, flavor='seurat', n_top_genes=3000)

# 3. Filter both datasets to the intersection of highly variable genes and genes present in both datasets
hvg = scrna_adata.var['highly_variable']
hvg_genes = scrna_adata.var_names[hvg]
shared_genes = [gene for gene in hvg_genes if gene in spatial_adata.var_names]

scrna_adata = scrna_adata[:, shared_genes].copy()
spatial_adata = spatial_adata[:, shared_genes].copy()

# 4. Check that the gene order matches
assert all(scrna_adata.var_names == spatial_adata.var_names), "Gene order mismatch between scRNA-seq and spatial data"

print("Preprocessing complete. Shared genes:", len(shared_genes))


# Correction: The cell type annotation key in scrna_adata.obs is not 'cell_type'.
# Let's print the available columns to identify the correct key for cell type annotation.

print("Available columns in scRNA-seq obs:", scrna_adata.obs.columns)


# Check which column contains the required cell type labels by printing unique values
columns_to_check = ['cell_class', 'cell_subclass', 'cell_cluster']

for col in columns_to_check:
    print(f"Unique values in '{col}':")
    print(scrna_adata.obs[col].unique())
    print("-" * 40)


# Correction: The columns in spatial_adata.obs may have been renamed or formatted by Tangram.
# Let's print all columns in spatial_adata.obs to identify the exact column names for the mapped cell types.

print("Columns in spatial_adata.obs after Tangram projection:")
print(list(spatial_adata.obs.columns))

# Let's also print a sample of the first few rows to inspect the column names and values.
print(spatial_adata.obs.head())


# According to Tangram's workflow, after running tg.map_cells_to_space and tg.project_cell_annotations,
# the cell type mapping results are typically stored in spatial_adata.obsm['tangram_ct_pred'] (or similar),
# not directly in spatial_adata.obs. Each column in this matrix corresponds to a cell type.

# Let's check the keys in spatial_adata.obsm to find the Tangram cell type prediction matrix.
print("Keys in spatial_adata.obsm:", spatial_adata.obsm.keys())

# If 'tangram_ct_pred' or similar exists, extract the relevant columns for the seven cell types and
# add them to spatial_adata.obs for downstream use and saving.
if 'tangram_ct_pred' in spatial_adata.obsm:
    ct_pred = spatial_adata.obsm['tangram_ct_pred']
    # Ensure the columns are in the same order as cell_types_of_interest and exist in ct_pred
    cols_to_save = [ct for ct in cell_types_of_interest if ct in ct_pred.columns]
    spatial_adata.obs[cols_to_save] = ct_pred[cols_to_save]
    print("Added cell type columns to spatial_adata.obs:", cols_to_save)
else:
    print("Tangram cell type prediction matrix not found in spatial_adata.obsm. Available keys:", spatial_adata.obsm.keys())


# Extract the required columns and save as CSV
output_path = '/mnt/data00/share_data/results/autogen/gpt-4.1/tangram/agent_output/tangram.csv'
cell_types_of_interest = ['L2/3 IT', 'L4', 'L5 IT', 'L5 PT', 'L6 CT', 'L6 IT', 'L6b']

# Save only the required columns
spatial_adata.obs[cell_types_of_interest].to_csv(output_path)

print(f"Saved Tangram mapping results to {output_path}")
