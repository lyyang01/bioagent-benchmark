
# Step 1: Load the spatial transcriptomics and scRNA-seq data using anndata

import anndata as ad

# Load spatial transcriptomics data (10X Visium, scATACseq sampled from 5K PBMCs)
spatial_adata = ad.read_h5ad('/mnt/data00/share_data/agent_benchmark/tangram/visium_fluo_adata_crop.h5ad')

# Load scRNA-seq reference data (mouse cortex)
scrna_adata = ad.read_h5ad('/mnt/data00/share_data/agent_benchmark/tangram/sc_mouse_cortex.h5ad')

# Check the loaded data shapes for confirmation
print("Spatial data shape:", spatial_adata.shape)
print("scRNA-seq data shape:", scrna_adata.shape)


# Step 2: Preprocess the spatial and scRNA-seq AnnData objects for Tangram mapping

import scanpy as sc

# Biological context:
# Tangram requires both spatial and scRNA-seq data to be normalized and have matching gene sets.
# Standard preprocessing includes normalization and filtering for highly variable genes.

# 1. Normalize both datasets (log1p normalization is standard for Tangram)
sc.pp.normalize_total(scrna_adata, target_sum=1e4)
sc.pp.log1p(scrna_adata)

sc.pp.normalize_total(spatial_adata, target_sum=1e4)
sc.pp.log1p(spatial_adata)

# 2. Find highly variable genes in scRNA-seq (Tangram recommends using variable genes from scRNA-seq)
sc.pp.highly_variable_genes(scrna_adata, flavor='seurat', n_top_genes=3000)
# Filter both datasets to the intersection of highly variable genes and genes present in both datasets
shared_genes = scrna_adata.var[sc.pp.highly_variable_genes(scrna_adata, flavor='seurat', n_top_genes=3000)]['highly_variable']
shared_genes = scrna_adata.var_names[shared_genes]
shared_genes = [gene for gene in shared_genes if gene in spatial_adata.var_names]

scrna_adata = scrna_adata[:, shared_genes]
spatial_adata = spatial_adata[:, shared_genes]

# 3. (Optional) Check that the gene order matches
assert all(scrna_adata.var_names == spatial_adata.var_names), "Gene order mismatch between scRNA-seq and spatial data"

# The AnnData objects are now preprocessed and ready for Tangram mapping.
print("Preprocessing complete. Shared genes:", len(shared_genes))


# Correction: The error is due to an incorrect attempt to use the return value of sc.pp.highly_variable_genes,
# which is None (it modifies the AnnData object in place). The correct approach is to use the 'highly_variable'
# column in .var after running the function.

import scanpy as sc

# 1. Normalize both datasets (log1p normalization is standard for Tangram)
sc.pp.normalize_total(scrna_adata, target_sum=1e4)
sc.pp.log1p(scrna_adata)

sc.pp.normalize_total(spatial_adata, target_sum=1e4)
sc.pp.log1p(spatial_adata)

# 2. Find highly variable genes in scRNA-seq (Tangram recommends using variable genes from scRNA-seq)
sc.pp.highly_variable_genes(scrna_adata, flavor='seurat', n_top_genes=3000)

# 3. Filter both datasets to the intersection of highly variable genes and genes present in both datasets
hvg = scrna_adata.var['highly_variable']
hvg_genes = scrna_adata.var_names[hvg]
shared_genes = [gene for gene in hvg_genes if gene in spatial_adata.var_names]

scrna_adata = scrna_adata[:, shared_genes].copy()
spatial_adata = spatial_adata[:, shared_genes].copy()

# 4. Check that the gene order matches
assert all(scrna_adata.var_names == spatial_adata.var_names), "Gene order mismatch between scRNA-seq and spatial data"

print("Preprocessing complete. Shared genes:", len(shared_genes))


# Step 3: Run Tangram to map scRNA-seq cell types onto spatial transcriptomics data
# Focus on the cell types: 'L2/3 IT', 'L4', 'L5 IT', 'L5 PT', 'L6 CT', 'L6 IT', 'L6b'

import tangram as tg

# Biological context:
# Tangram maps cell types from scRNA-seq onto spatial transcriptomics data, estimating the spatial distribution of each cell type.
# We focus on the specified excitatory neuron subtypes.

# 1. Ensure cell type annotation is present in scRNA-seq data
celltype_key = 'cell_type'  # This is a common key; adjust if the actual key is different
if celltype_key not in scrna_adata.obs.columns:
    print("Available columns in scRNA-seq obs:", scrna_adata.obs.columns)
    raise ValueError("Cell type annotation not found in scRNA-seq data.")

# 2. Subset scRNA-seq data to only the cell types of interest
cell_types_of_interest = ['L2/3 IT', 'L4', 'L5 IT', 'L5 PT', 'L6 CT', 'L6 IT', 'L6b']
scrna_adata_sub = scrna_adata[scrna_adata.obs[celltype_key].isin(cell_types_of_interest)].copy()

# 3. Run Tangram mapping (GPU acceleration if available)
# Tangram expects the AnnData objects to be preprocessed and gene-matched (already done)
tg.pp_adatas(scrna_adata_sub, spatial_adata, genes=None)  # genes=None: use intersection

# Map cell types (mode='cells' for cell-level, mode='clusters' for cell type-level)
# Here, we use 'clusters' to map cell types
tangram_result = tg.map_cells_to_space(
    scrna_adata_sub,
    spatial_adata,
    mode='clusters',
    cluster_label=celltype_key,
    device='cuda'  # Use GPU if available; fallback to 'cpu' if not
)

# Project the result to get cell type proportions per spatial spot
tg.project_cell_annotations(
    tangram_result,
    annotation=celltype_key,
    cluster_labels=cell_types_of_interest
)

# The result is now stored in spatial_adata.obs with columns for each cell type
print("Tangram mapping complete. Columns in spatial_adata.obs:", spatial_adata.obs.columns)


# Correction: The cell type annotation key in scrna_adata.obs is not 'cell_type'.
# Let's print the available columns to identify the correct key for cell type annotation.

print("Available columns in scRNA-seq obs:", scrna_adata.obs.columns)


# Check which column contains the required cell type labels by printing unique values
columns_to_check = ['cell_class', 'cell_subclass', 'cell_cluster']

for col in columns_to_check:
    print(f"Unique values in '{col}':")
    print(scrna_adata.obs[col].unique())
    print("-" * 40)


import tangram as tg

# Define the cell types of interest
cell_types_of_interest = ['L2/3 IT', 'L4', 'L5 IT', 'L5 PT', 'L6 CT', 'L6 IT', 'L6b']

# Subset scRNA-seq data to only the specified cell types using 'cell_subclass'
scrna_adata_sub = scrna_adata[scrna_adata.obs['cell_subclass'].isin(cell_types_of_interest)].copy()

# Ensure gene matching (already done, but Tangram recommends running this)
tg.pp_adatas(scrna_adata_sub, spatial_adata, genes=None)

# Run Tangram mapping (mode='clusters' for cell type-level mapping)
tangram_result = tg.map_cells_to_space(
    scrna_adata_sub,
    spatial_adata,
    mode='clusters',
    cluster_label='cell_subclass',
    device='cuda'  # Use GPU if available; fallback to 'cpu' if not
)

# Project the cell type annotations onto the spatial data for the seven cell types
tg.project_cell_annotations(
    tangram_result,
    annotation='cell_subclass',
    cluster_labels=cell_types_of_interest
)

# Confirm the columns are present in spatial_adata.obs
print("Tangram mapping complete. Columns in spatial_adata.obs:")
print(spatial_adata.obs.columns)


# Correction: The function tg.project_cell_annotations does not accept 'cluster_labels' as an argument.
# Instead, it uses 'annotation' to specify the column with cell type labels.
# After projection, all cell type columns will be added to spatial_adata.obs.
# We will then extract only the columns of interest.

# Project the cell type annotations onto the spatial data
tg.project_cell_annotations(
    tangram_result,
    annotation='cell_subclass'
)

# Confirm the columns are present in spatial_adata.obs and print the first few rows for the cell types of interest
print("Tangram mapping complete. Columns in spatial_adata.obs:")
print(spatial_adata.obs.columns)

# Show the first few rows for the seven cell types
print(spatial_adata.obs[cell_types_of_interest].head())


# Correction: The function tg.project_cell_annotations requires both the mapping result and the spatial AnnData object.
# The correct call is tg.project_cell_annotations(tangram_result, spatial_adata, annotation='cell_subclass')

# Project the cell type annotations onto the spatial data
tg.project_cell_annotations(
    tangram_result,
    spatial_adata,
    annotation='cell_subclass'
)

# Confirm the columns are present in spatial_adata.obs and print the first few rows for the cell types of interest
print("Tangram mapping complete. Columns in spatial_adata.obs:")
print(spatial_adata.obs.columns)

# Show the first few rows for the seven cell types
print(spatial_adata.obs[cell_types_of_interest].head())


# Correction: The columns in spatial_adata.obs may have been renamed or formatted by Tangram.
# Let's print all columns in spatial_adata.obs to identify the exact column names for the mapped cell types.

print("Columns in spatial_adata.obs after Tangram projection:")
print(list(spatial_adata.obs.columns))

# Let's also print a sample of the first few rows to inspect the column names and values.
print(spatial_adata.obs.head())


# According to Tangram's workflow, after running tg.map_cells_to_space and tg.project_cell_annotations,
# the cell type mapping results are typically stored in spatial_adata.obsm['tangram_ct_pred'] (or similar),
# not directly in spatial_adata.obs. Each column in this matrix corresponds to a cell type.

# Let's check the keys in spatial_adata.obsm to find the Tangram cell type prediction matrix.
print("Keys in spatial_adata.obsm:", spatial_adata.obsm.keys())

# If 'tangram_ct_pred' or similar exists, extract the relevant columns for the seven cell types and
# add them to spatial_adata.obs for downstream use and saving.
if 'tangram_ct_pred' in spatial_adata.obsm:
    ct_pred = spatial_adata.obsm['tangram_ct_pred']
    # Ensure the columns are in the same order as cell_types_of_interest and exist in ct_pred
    cols_to_save = [ct for ct in cell_types_of_interest if ct in ct_pred.columns]
    spatial_adata.obs[cols_to_save] = ct_pred[cols_to_save]
    print("Added cell type columns to spatial_adata.obs:", cols_to_save)
else:
    print("Tangram cell type prediction matrix not found in spatial_adata.obsm. Available keys:", spatial_adata.obsm.keys())


# Extract the required columns and save as CSV
output_path = '/mnt/data00/share_data/results/autogen/gpt-4.1/tangram/agent_output/tangram.csv'
cell_types_of_interest = ['L2/3 IT', 'L4', 'L5 IT', 'L5 PT', 'L6 CT', 'L6 IT', 'L6b']

# Save only the required columns
spatial_adata.obs[cell_types_of_interest].to_csv(output_path)

print(f"Saved Tangram mapping results to {output_path}")
