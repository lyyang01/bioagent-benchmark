
# The error suggests that atlas_geom_df.dtypes is empty, indicating that the geometry.txt file may not have loaded correctly.
# Let's inspect the first few lines of both files to determine their structure and ensure correct loading.
# We'll also handle the case where the file is empty or has an unexpected format.

import pandas as pd
import os

scRNAseq_path = '/mnt/data00/share_data/agent_benchmark/novosparc/datasets/drosophila_scRNAseq/dge_normalized.txt'
atlas_geom_path = '/mnt/data00/share_data/agent_benchmark/novosparc/datasets/bdtnp/geometry.txt'
output_dir = '/mnt/data00/share_data/results/autogen/gpt-4.1/novosparc/agent_output'
os.makedirs(output_dir, exist_ok=True)

# Preview the first few lines of each file to determine their structure
def preview_file(filepath, n=5):
    with open(filepath, 'r') as f:
        lines = [next(f) for _ in range(n)]
    return lines

scRNAseq_preview = preview_file(scRNAseq_path)
atlas_geom_preview = preview_file(atlas_geom_path)

# Save previews for inspection
with open(os.path.join(output_dir, 'scRNAseq_preview.txt'), 'w') as f:
    f.writelines(scRNAseq_preview)
with open(os.path.join(output_dir, 'atlas_geom_preview.txt'), 'w') as f:
    f.writelines(atlas_geom_preview)

print("Preview of scRNA-seq file saved to scRNAseq_preview.txt")
print("Preview of atlas geometry file saved to atlas_geom_preview.txt")
print("Please inspect these files to determine the correct loading parameters (e.g., header, index_col, delimiter).")


# Read and display the contents of the preview files to determine the correct loading parameters

output_dir = '/mnt/data00/share_data/results/autogen/gpt-4.1/novosparc/agent_output'
scRNAseq_preview_file = os.path.join(output_dir, 'scRNAseq_preview.txt')
atlas_geom_preview_file = os.path.join(output_dir, 'atlas_geom_preview.txt')

# Display scRNA-seq preview
print("===== scRNA-seq Preview =====")
with open(scRNAseq_preview_file, 'r') as f:
    print(f.read())

# Display atlas geometry preview
print("===== Atlas Geometry Preview =====")
with open(atlas_geom_preview_file, 'r') as f:
    print(f.read())


# The previous message was a template, not executable code.
# Here is the correct code to display the contents of the atlas geometry preview file for analysis.

output_dir = '/mnt/data00/share_data/results/autogen/gpt-4.1/novosparc/agent_output'
atlas_geom_preview_file = os.path.join(output_dir, 'atlas_geom_preview.txt')

print("===== Atlas Geometry File Preview =====")
with open(atlas_geom_preview_file, 'r') as f:
    for line in f:
        print(line.strip())


import pandas as pd

atlas_geom_path = '/mnt/data00/share_data/agent_benchmark/novosparc/datasets/bdtnp/geometry.txt'

# Load the atlas geometry file with space as delimiter, header in first row, no index column
atlas_geom_df = pd.read_csv(atlas_geom_path, sep=' ', header=0)

# Confirm successful loading and display the first few rows
print("Atlas geometry file loaded successfully. First 5 rows:")
print(atlas_geom_df.head())

# Save for downstream steps
output_dir = '/mnt/data00/share_data/results/autogen/gpt-4.1/novosparc/agent_output'
atlas_geom_df.to_pickle(f"{output_dir}/atlas_geom_df.pkl")


import pandas as pd

scRNAseq_path = '/mnt/data00/share_data/agent_benchmark/novosparc/datasets/drosophila_scRNAseq/dge_normalized.txt'

# Load the scRNA-seq gene expression matrix
# Assumption: tab-delimited, first row is header (cell/sample names), first column is gene names (row index)
scRNAseq_df = pd.read_csv(scRNAseq_path, sep='\t', header=0, index_col=0)

# Confirm successful loading: show shape and first few rows
print(f"scRNA-seq gene expression matrix loaded successfully. Shape: {scRNAseq_df.shape}")
print("First 5 rows:")
print(scRNAseq_df.head())

# Save for downstream steps
output_dir = '/mnt/data00/share_data/results/autogen/gpt-4.1/novosparc/agent_output'
scRNAseq_df.to_pickle(f"{output_dir}/scRNAseq_df.pkl")


import os

# Load previously saved dataframes
output_dir = '/mnt/data00/share_data/results/autogen/gpt-4.1/novosparc/agent_output'
scRNAseq_df = pd.read_pickle(f"{output_dir}/scRNAseq_df.pkl")
atlas_geom_df = pd.read_pickle(f"{output_dir}/atlas_geom_df.pkl")

# Gather statistics
num_genes = scRNAseq_df.shape[0]
num_cells = scRNAseq_df.shape[1]
num_spatial_locations = atlas_geom_df.shape[0]

# novoSpaRc requires that the number of cells (scRNA-seq profiles) matches the number of spatial locations (atlas)
cells_match = num_cells == num_spatial_locations

# Prepare report
report = (
    f"scRNA-seq gene expression matrix:\n"
    f"  Number of genes: {num_genes}\n"
    f"  Number of cells: {num_cells}\n\n"
    f"Atlas geometry:\n"
    f"  Number of spatial locations: {num_spatial_locations}\n\n"
    f"Do the number of cells and spatial locations match? {'YES' if cells_match else 'NO'}\n"
    f"\n"
    f"Note: novoSpaRc requires the number of cells in the scRNA-seq data to match the number of spatial locations in the atlas geometry for direct mapping.\n"
    f"Gene names in scRNA-seq data are assumed to be compatible with novoSpaRc (standard gene symbols as row indices).\n"
)

# Save report
report_path = os.path.join(output_dir, 'consistency_report.txt')
with open(report_path, 'w') as f:
    f.write(report)

# Print summary
print(report)
print(f"Report saved to {report_path}")


import numpy as np

# Load scRNA-seq data
output_dir = '/mnt/data00/share_data/results/autogen/gpt-4.1/novosparc/agent_output'
scRNAseq_df = pd.read_pickle(f"{output_dir}/scRNAseq_df.pkl")

# 1. Select top 1000 highly variable genes (by variance across cells)
gene_variances = scRNAseq_df.var(axis=1)
top_genes = gene_variances.sort_values(ascending=False).head(1000).index
scRNAseq_hvg = scRNAseq_df.loc[top_genes]

# 2. Apply z-score scaling (mean=0, std=1) across cells for each gene
scRNAseq_scaled = scRNAseq_hvg.sub(scRNAseq_hvg.mean(axis=1), axis=0)
scRNAseq_scaled = scRNAseq_scaled.div(scRNAseq_hvg.std(axis=1).replace(0, np.nan), axis=0)
scRNAseq_scaled = scRNAseq_scaled.fillna(0)  # Replace NaNs from zero std with 0

# 3. Save the processed matrix
scRNAseq_scaled.to_pickle(f"{output_dir}/scRNAseq_processed.pkl")

# 4. Report
print(f"Number of highly variable genes selected: {scRNAseq_scaled.shape[0]}")
print(f"Processed and scaled matrix saved as 'scRNAseq_processed.pkl' in {output_dir}")


import numpy as np
import pandas as pd
import os

output_dir = '/mnt/data00/share_data/results/autogen/gpt-4.1/novosparc/agent_output'

# Load processed scRNA-seq matrix (genes x cells)
scRNAseq_processed = pd.read_pickle(os.path.join(output_dir, 'scRNAseq_processed.pkl'))
# Transpose to cells x genes for novoSpaRc
expression_matrix = scRNAseq_processed.T.values  # shape: (cells, genes)

# Load atlas geometry (locations x 3)
atlas_geom_df = pd.read_pickle(os.path.join(output_dir, 'atlas_geom_df.pkl'))
locations_matrix = atlas_geom_df[['xcoord', 'ycoord', 'zcoord']].values  # shape: (locations, 3)

# Confirm shapes
print(f"Expression matrix shape (cells x genes): {expression_matrix.shape}")
print(f"Locations matrix shape (locations x 3): {locations_matrix.shape}")

# Save as .npy files for downstream novoSpaRc use
np.save(os.path.join(output_dir, 'novosparc_expression.npy'), expression_matrix)
np.save(os.path.join(output_dir, 'novosparc_locations.npy'), locations_matrix)


# The error indicates that Tissue.reconstruct() requires the positional argument 'alpha_linear'.
# alpha_linear controls the trade-off between gene expression similarity and spatial smoothness (0 = only smoothness, 1 = only expression).
# A typical value is 0.5 for balanced reconstruction, but you may adjust as needed.

import scanpy as sc
import novosparc
import numpy as np
import pandas as pd
import os

output_dir = '/mnt/data00/share_data/results/autogen/gpt-4.1/novosparc/agent_output'
scRNAseq_path = os.path.join(output_dir, 'scRNAseq_processed.pkl')
atlas_geom_path = os.path.join(output_dir, 'atlas_geom_df.pkl')

# Load processed data
scRNAseq_df = pd.read_pickle(scRNAseq_path)  # genes x cells
atlas_geom_df = pd.read_pickle(atlas_geom_path)

# Transpose to cells x genes for AnnData
adata = sc.AnnData(scRNAseq_df.T)
adata.var_names = scRNAseq_df.index
adata.obs_names = scRNAseq_df.columns

# Prepare spatial coordinates (locations x 3)
locations = atlas_geom_df[['xcoord', 'ycoord', 'zcoord']].values

# Run novoSpaRc spatial reconstruction
tissue = novosparc.cm.Tissue(
    dataset=adata,
    locations=locations,
    atlas_matrix=None,
    markers_to_use=None,
    output_folder=output_dir
)

# Run the reconstruction with alpha_linear=0.5 (typical balanced value)
tissue.reconstruct(alpha_linear=0.5)

# Save AnnData object with spatial mapping for downstream analysis/visualization
adata.write(os.path.join(output_dir, 'novosparc_reconstructed.h5ad'))

print("novoSpaRc spatial reconstruction complete. All outputs saved to:", output_dir)


# The assignment matrix attribute may have a different name or may be stored in a different way in this version of novoSpaRc.
# Let's inspect all attributes of the Tissue object to find the correct one.
# We'll print all attribute names and their types/sizes if possible.

attrs = dir(tissue)
print("Attributes of the Tissue object:")
for attr in attrs:
    if not attr.startswith('_'):
        try:
            val = getattr(tissue, attr)
            if isinstance(val, np.ndarray):
                print(f"{attr}: ndarray, shape={val.shape}")
            elif isinstance(val, (list, tuple)):
                print(f"{attr}: {type(val).__name__}, len={len(val)}")
            elif isinstance(val, (pd.DataFrame, pd.Series)):
                print(f"{attr}: {type(val).__name__}, shape={val.shape}")
            else:
                print(f"{attr}: {type(val).__name__}")
        except Exception as e:
            print(f"{attr}: could not access ({e})")


import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import os

output_dir = '/mnt/data00/share_data/results/autogen/gpt-4.1/novosparc/agent_output'

# 1. Save cell-to-location assignment matrix (cells x locations)
np.save(os.path.join(output_dir, 'novosparc_assignment_matrix_gw.npy'), tissue.gw)

# 2. Save reconstructed spatial gene expression matrix (genes x locations)
np.save(os.path.join(output_dir, 'novosparc_reconstructed_expression_sdge.npy'), tissue.sdge)

# Also save as CSV: genes as rows, locations as columns
gene_names = tissue.gene_names
location_indices = [f"loc_{i}" for i in range(tissue.sdge.shape[1])]
recon_expr_df = pd.DataFrame(tissue.sdge, index=gene_names, columns=location_indices)
recon_expr_df.to_csv(os.path.join(output_dir, 'novosparc_reconstructed_expression_sdge.csv'))

# 3. Generate and save a spatial plot for the first gene
gene_to_plot = gene_names[0]
gene_idx = 0
locations = tissue.locations  # shape: (n_locations, 3)
x, y, z = locations[:, 0], locations[:, 1], locations[:, 2]
expr = tissue.sdge[gene_idx, :]  # expression for the first gene across all locations

plt.figure(figsize=(8, 6))
sc = plt.scatter(x, y, c=expr, cmap='viridis', s=10)
plt.colorbar(sc, label=f'Expression of {gene_to_plot}')
plt.xlabel('xcoord')
plt.ylabel('ycoord')
plt.title(f'Spatial reconstruction: {gene_to_plot}')
plt.tight_layout()
plt.savefig(os.path.join(output_dir, f'novosparc_spatial_plot_{gene_to_plot}.png'))
plt.close()

print("Assignment matrix, reconstructed expression, and spatial plot saved to:", output_dir)


# The error occurs because get_moran_pvals expects the input expression matrix to be (locations, genes), not (genes, locations).
# We need to transpose the expression data for each gene to shape (locations, 1).

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import os
import novosparc

output_dir = '/mnt/data00/share_data/results/autogen/gpt-4.1/novosparc/agent_output'

gene_names = tissue.gene_names
locations = tissue.locations  # (n_locations, 3)
x, y, z = locations[:, 0], locations[:, 1], locations[:, 2]
sdge = tissue.sdge  # (n_genes, n_locations)

# Plot spatial expression for the top 3 genes
for i in range(3):
    gene = gene_names[i]
    expr = sdge[i, :]
    plt.figure(figsize=(8, 6))
    sc = plt.scatter(x, y, c=expr, cmap='viridis', s=10)
    plt.colorbar(sc, label=f'Expression of {gene}')
    plt.xlabel('xcoord')
    plt.ylabel('ycoord')
    plt.title(f'Spatial reconstruction: {gene}')
    plt.tight_layout()
    plt.savefig(os.path.join(output_dir, f'novosparc_spatial_plot_{gene}.png'))
    plt.close()

# Compute Moran's I spatial correlation for the top 3 genes using novoSpaRc's analysis tools
moran_results = []
for i in range(3):
    gene = gene_names[i]
    expr = sdge[i, :].reshape(-1, 1)  # shape (locations, 1)
    # Compute Moran's I and p-value
    moran_i, pval = novosparc.an.get_moran_pvals(expr, locations, npermut=100, n_neighbors=8)
    moran_results.append({'gene': gene, 'moran_I': moran_i[0], 'p_value': pval[0]})

# Save Moran's I results
moran_df = pd.DataFrame(moran_results)
moran_df.to_csv(os.path.join(output_dir, 'novosparc_moransI_top3.csv'), index=False)

print("Spatial plots and Moran's I statistics for top 3 genes saved to:", output_dir)


import os

output_dir = '/mnt/data00/share_data/results/autogen/gpt-4.1/novosparc/agent_output'
summary_path = os.path.join(output_dir, 'novosparc_run_summary.txt')

# Gather parameters and results
num_cells = tissue.num_cells
num_locations = tissue.num_locations
num_genes = tissue.num_genes
alpha_linear = tissue.alpha_linear

summary = f"""
novoSpaRc Spatial Reconstruction Run Summary
===========================================

Parameters:
-----------
Number of single cells (scRNA-seq): {num_cells}
Number of spatial locations (atlas): {num_locations}
Number of genes used: {num_genes}
alpha_linear: {alpha_linear}

Steps Performed:
----------------
1. Data Preparation:
   - Loaded normalized Drosophila scRNA-seq matrix and atlas geometry.
   - Selected top 1000 highly variable genes.
   - Z-score scaled gene expression across cells.

2. Preprocessing:
   - Matched gene set for novoSpaRc input.
   - Formatted data as AnnData (cells x genes) and numpy arrays.

3. Spatial Reconstruction:
   - Ran novoSpaRc with all cells and all spatial locations.
   - Used alpha_linear={alpha_linear} for balanced mapping.

4. Output Generation:
   - Saved cell-to-location assignment matrix (gw).
   - Saved reconstructed spatial gene expression matrix (sdge) as .npy and .csv.
   - Generated spatial plots for the top 3 highly variable genes.

5. Quality Assessment:
   - Computed Moran's I spatial correlation for the top 3 genes.
   - Saved Moran's I results as CSV.

Summary of Results:
-------------------
- Assignment matrix: novosparc_assignment_matrix_gw.npy
- Reconstructed expression: novosparc_reconstructed_expression_sdge.npy, .csv
- Spatial plots: novosparc_spatial_plot_[GENE].png (for top 3 genes)
- Moran's I statistics: novosparc_moransI_top3.csv

Warnings/Notes:
---------------
- RuntimeWarnings about invalid values in Moran's I calculation may indicate some genes have little spatial structure or constant expression.
- The number of cells (1297) did not match the number of spatial locations (6078); novoSpaRc handled this via probabilistic mapping.
- All outputs are saved in: {output_dir}

"""

with open(summary_path, 'w') as f:
    f.write(summary.strip())

print(f"Run summary saved to {summary_path}")
