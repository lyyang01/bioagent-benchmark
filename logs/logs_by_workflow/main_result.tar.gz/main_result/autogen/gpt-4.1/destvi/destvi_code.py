
# Step 1: Load scRNA-seq and spatial transcriptomics datasets using anndata

import anndata as ad

# Load scRNA-seq data (reference)
sc_adata = ad.read_h5ad('/mnt/data00/share_data/agent_benchmark/destvi/scRNA-LN-compressed.h5ad')

# Load spatial transcriptomics data (target)
st_adata = ad.read_h5ad('/mnt/data00/share_data/agent_benchmark/destvi/ST-LN-compressed.h5ad')

# Biological context:
# sc_adata: single-cell RNA-seq data, used as reference for cell type signatures
# st_adata: spatial transcriptomics data, to be deconvolved into cell type proportions

print(f"scRNA-seq data shape: {sc_adata.shape}")
print(f"Spatial data shape: {st_adata.shape}")


# Step 2: Preprocess scRNA-seq and spatial data for DestVI

import numpy as np

# 1. Ensure cell type annotations are present in scRNA-seq data
# DestVI expects a cell type annotation column in sc_adata.obs, commonly named 'cell_type' or similar.
# Let's check for common keys and print available columns for user awareness.
print("sc_adata.obs columns:", sc_adata.obs.columns)
# If needed, update 'cell_type_key' below to match the correct column name.
cell_type_key = None
for key in ['cell_type', 'celltypes', 'CellType', 'cell_types', 'celltype']:
    if key in sc_adata.obs.columns:
        cell_type_key = key
        break
if cell_type_key is None:
    raise ValueError("No cell type annotation found in sc_adata.obs. Please check the annotation column.")

# 2. Match genes between scRNA-seq and spatial data
# DestVI requires that both AnnData objects have the same set/order of genes (var_names)
common_genes = np.intersect1d(sc_adata.var_names, st_adata.var_names)
print(f"Number of common genes: {len(common_genes)}")
sc_adata = sc_adata[:, common_genes].copy()
st_adata = st_adata[:, common_genes].copy()

# 3. (Optional) Filtering: For DestVI, it's typical to use raw counts, so no log-normalization or scaling is needed.
# If raw counts are in a specific layer, set that layer as default.
# Here, we assume counts are in .X. If not, update accordingly.

# 4. (Optional) Remove cells with missing cell type annotation
sc_adata = sc_adata[~sc_adata.obs[cell_type_key].isna()].copy()

# 5. (Optional) Ensure AnnData objects are backed by integer counts (DestVI expects counts)
if not np.issubdtype(sc_adata.X.dtype, np.integer):
    print("Warning: sc_adata.X is not integer counts. DestVI expects raw counts.")
if not np.issubdtype(st_adata.X.dtype, np.integer):
    print("Warning: st_adata.X is not integer counts. DestVI expects raw counts.")

# Biological assumptions:
# - sc_adata.obs[cell_type_key] contains cell type labels for each cell
# - Both datasets are filtered to the same set of genes for compatibility

print("Preprocessing complete. Ready for DestVI setup.")


# Step 3: Set up CondSCVI and DestVI for spatial deconvolution

import scvi
from scvi.model import CondSCVI, DestVI

# Register scRNA-seq data with CondSCVI, using the cell type annotation key 'cell_types'
# This step prepares the AnnData object for use with CondSCVI, storing cell type labels internally
CondSCVI.setup_anndata(sc_adata, labels_key='cell_types')

# Initialize the CondSCVI model (default parameters are generally suitable for most use cases)
condscvi_model = CondSCVI(sc_adata)

# Register spatial data for DestVI (no labels needed, just ensure raw counts are used)
DestVI.setup_anndata(st_adata)

# Biological notes:
# - sc_adata is registered with cell type labels for supervised learning in CondSCVI
# - st_adata is registered for DestVI, which will use the trained CondSCVI model as a reference

print("CondSCVI and DestVI setup complete.")


# Step 4: Train the CondSCVI model

# Train the CondSCVI model for 300 epochs using GPU if available
condscvi_model.train(
    max_epochs=300,         # Recommended number of epochs for robust training
    accelerator='auto',     # Use GPU if available for faster training
    devices='auto',         # Use all available devices
    batch_size=128,         # Default batch size
    train_size=1.0,         # Use all data for training (no validation split)
    shuffle_set_split=True  # Shuffle data before splitting
)

# Biological note:
# - This step learns cell type-specific gene expression profiles from the scRNA-seq reference data.
print("CondSCVI model training complete.")


# Step 5: Set up and train the DestVI model

# Initialize DestVI model using the trained CondSCVI model as reference
destvi_model = DestVI.from_rna_model(st_adata, condscvi_model)

# Train the DestVI model for 2000 epochs using GPU if available
destvi_model.train(
    max_epochs=2000,        # Recommended number of epochs for DestVI
    accelerator='auto',     # Use GPU if available
    devices='auto',         # Use all available devices
    batch_size=128,         # Default batch size
    train_size=1.0,         # Use all data for training
    shuffle_set_split=True  # Shuffle data before splitting
)

# Biological note:
# - DestVI learns to deconvolve spatial transcriptomics spots into cell type proportions using the reference learned by CondSCVI.
print("DestVI model training complete.")


# Step 6: Estimate cell type proportions for each spatial spot using the trained DestVI model

# Get cell type proportions for each spot
proportions = destvi_model.get_proportions()

# Store the resulting DataFrame in st_adata.obsm['proportions']
st_adata.obsm['proportions'] = proportions

# Biological note:
# - Each row in 'proportions' corresponds to a spatial spot, and each column to a cell type.
# - These values represent the estimated fraction of each cell type in each spot.

print("Cell type proportions estimated and stored in st_adata.obsm['proportions'].")


# Step 7 (retry): Check available cell type columns and extract the correct ones

# List available columns in the proportions DataFrame
print("Available cell type columns:", st_adata.obsm['proportions'].columns.tolist())

# Let's try to find the closest matching columns for 'B cells', 'CD8 T cells', and 'Monocytes'
# This is necessary because cell type names may differ (e.g., 'B cell', 'CD8+ T cell', 'Monocyte', etc.)
import difflib

available_cols = st_adata.obsm['proportions'].columns.tolist()
target_names = ['B cells', 'CD8 T cells', 'Monocytes']

# Find best matches for each target name
matched_cols = []
for name in target_names:
    match = difflib.get_close_matches(name, available_cols, n=1)
    if match:
        matched_cols.append(match[0])
    else:
        print(f"Warning: No close match found for '{name}' in available columns.")

print("Matched columns for extraction:", matched_cols)

# Extract and save only if all matches are found
if len(matched_cols) == len(target_names):
    proportions_selected = st_adata.obsm['proportions'][matched_cols]
    proportions_selected.to_csv(output_path)
    print(f"Selected cell type proportions saved to {output_path}")
else:
    print("Could not find all requested cell types in the proportions DataFrame. Please check the available columns above.")


# Step 8 (fix): Only reference df if the file exists

import pandas as pd

# Check if the output file exists
if os.path.exists(output_path):
    df = pd.read_csv(output_path, index_col=0)
    print(f"'destvi.csv' found at {output_path}")
    print("Columns in output file:", df.columns.tolist())
    print("First few rows of the output file:")
    print(df.head())
else:
    print(f"Output file {output_path} does not exist.")
    df = None

# Document mapping and discrepancies
requested = ['B cells', 'CD8 T cells', 'Monocytes']
available = st_adata.obsm['proportions'].columns.tolist()
matched = []
not_found = []

for req in requested:
    match = difflib.get_close_matches(req, available, n=1)
    if match:
        matched.append((req, match[0]))
    else:
        not_found.append(req)

print("\nSummary of cell type mapping:")
for req, match in matched:
    print(f"Requested: '{req}' -> Used: '{match}'")
if not_found:
    print("The following requested cell types were NOT found in the available columns:")
    for nf in not_found:
        print(f" - {nf}")

# Save a documentation txt file summarizing the mapping and discrepancies
doc_path = os.path.join(output_dir, 'destvi_output_summary.txt')
with open(doc_path, 'w') as f:
    f.write("Cell type extraction summary for destvi.csv\n")
    f.write("=========================================\n")
    f.write(f"Requested cell types: {requested}\n")
    f.write(f"Available columns: {available}\n\n")
    f.write("Mapping used:\n")
    for req, match in matched:
        f.write(f"  Requested: '{req}' -> Used: '{match}'\n")
    if not_found:
        f.write("\nThe following requested cell types were NOT found in the available columns:\n")
        for nf in not_found:
            f.write(f"  - {nf}\n")
    if df is not None:
        f.write("\nColumns in output file:\n")
        f.write(f"{df.columns.tolist()}\n")
        f.write("\nFirst few rows of the output file:\n")
        f.write(df.head().to_string())
    else:
        f.write("\nNo output file was generated.\n")
print(f"Summary documentation saved to {doc_path}")
