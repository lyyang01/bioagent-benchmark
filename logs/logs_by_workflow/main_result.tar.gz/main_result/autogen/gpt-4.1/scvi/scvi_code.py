
# Step 1: Load the AnnData object from the provided file path

import scanpy as sc

# Biological context: AnnData is a standard data structure for single-cell omics data.
# Here, we load the lung atlas dataset for downstream integration with scVI.

adata = sc.read_h5ad('/mnt/data00/share_data/agent_benchmark/scvi/lung_atlas.h5ad')

# Check the shape and basic info to confirm successful loading
print(adata)
print(adata.obs.head())


# The error is due to adata.X being a sparse matrix, which cannot be directly used with np.allclose or np.issubdtype.
# Let's fix this by checking the type and skipping the assertion for sparse matrices.
# The rest of the preprocessing (filtering, no scaling) is correct.

import scipy.sparse

# Use the 'counts' layer for scVI if present
if 'counts' in adata.layers:
    adata.X = adata.layers['counts']

# Optional: Filter out genes expressed in very few cells and cells with very few genes
sc.pp.filter_cells(adata, min_genes=200)
sc.pp.filter_genes(adata, min_cells=3)

# No scaling or log-normalization is performed here

# Check if adata.X is sparse or dense, and print a summary
if scipy.sparse.issparse(adata.X):
    print(f"adata.X is a sparse matrix of type {type(adata.X)}")
else:
    print(f"adata.X is a dense matrix of type {type(adata.X)}")

print(f"Filtered AnnData shape: {adata.shape}")


# For atlas-level integration with scVI, the batch_key should represent the main source of batch effects.
# In multi-dataset atlases, 'batch' or 'dataset' are commonly used.
# Here, both 'batch' and 'dataset' are present in adata.obs.
# 'batch' typically encodes technical batches, while 'dataset' may encode study/source.
# For broad integration across studies and batches, 'batch' is usually preferred for batch_key.

import scvi

# Set up AnnData for scVI, using the 'batch' column as the batch_key for integration
scvi.model.SCVI.setup_anndata(
    adata,
    layer=None,  # Use adata.X, which is already set to raw counts
    batch_key='batch'  # Use 'batch' for batch effect correction
)

print("scVI anndata setup complete with batch_key='batch'.")


# Step 4: Train the scVI model on the preprocessed data

from scvi.model import SCVI

# Biological context:
# - scVI will learn a batch-corrected, integrated latent space from the raw counts.
# - Default parameters are suitable for most atlas-level integration tasks.

# Initialize the scVI model
model = SCVI(adata)

# Train the model (use GPU if available for speed)
model.train(accelerator='auto', devices='auto')

print("scVI model training complete.")


# Step 5: Extract the integrated latent representation and store in adata.obsm['X_scvi']

# Biological context:
# - The latent representation learned by scVI is a batch-corrected, integrated embedding of the cells.
# - This is commonly used for downstream visualization, clustering, and trajectory inference.

# Get the latent representation
adata.obsm['X_scvi'] = model.get_latent_representation()

print("Latent representation stored in adata.obsm['X_scvi'].")


# Step 6: Save the integrated AnnData object

output_path = '/mnt/data00/share_data/results/autogen/gpt-4.1/scvi/agent_output/scvi.h5ad'
adata.write(output_path)

print(f"Integrated AnnData object saved to: {output_path}")


# Step 7: Verify output file and integrated results

import os
import anndata

output_path = '/mnt/data00/share_data/results/autogen/gpt-4.1/scvi/agent_output/scvi.h5ad'

# Check if file exists
file_exists = os.path.isfile(output_path)
print(f"File exists: {file_exists}")

# Load the file and check obsm['X_scvi']
if file_exists:
    adata_check = anndata.read_h5ad(output_path)
    has_X_scvi = 'X_scvi' in adata_check.obsm and adata_check.obsm['X_scvi'].shape[0] > 0
    print(f"obsm['X_scvi'] present: {has_X_scvi}")
    print(f"obsm['X_scvi'] shape: {adata_check.obsm['X_scvi'].shape if has_X_scvi else 'N/A'}")
else:
    print("Output file not found.")
