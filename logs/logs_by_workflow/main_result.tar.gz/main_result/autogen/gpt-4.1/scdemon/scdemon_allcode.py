
# Step 1: Load the PBMC3K dataset using scanpy

import scanpy as sc

# Load the PBMC3K single-cell RNA-seq dataset
# This dataset contains 3k Peripheral Blood Mononuclear Cells (PBMCs)
adata = sc.datasets.pbmc3k()

# Save the raw AnnData object for reproducibility and downstream steps
adata.write('/mnt/data00/share_data/results/autogen/gpt-4.1/scdemon/agent_output/pbmc3k_raw.h5ad')


# Step 2: Preprocess the loaded PBMC3K dataset using scdemon's recipe_full

import scanpy as sc
import scdemon

# Load the raw data (already saved in previous step)
adata = sc.read('/mnt/data00/share_data/results/autogen/gpt-4.1/scdemon/agent_output/pbmc3k_raw.h5ad')

# Apply scdemon's recipe_full preprocessing
# This function performs normalization, feature selection, and scaling suitable for co-expression analysis
adata_prep = scdemon.recipe_full(adata)

# Save the preprocessed AnnData object for downstream analysis
adata_prep.write('/mnt/data00/share_data/results/autogen/gpt-4.1/scdemon/agent_output/pbmc3k_prep_scdemon.h5ad')


# Correction: scdemon.recipe_full modifies the AnnData object in place and returns None.
# Therefore, we should not assign its output to a new variable.
# Instead, call the function directly on the loaded AnnData object.

import scanpy as sc
import scdemon

# Load the raw data
adata = sc.read('/mnt/data00/share_data/results/autogen/gpt-4.1/scdemon/agent_output/pbmc3k_raw.h5ad')

# Preprocess in place (modifies adata directly)
scdemon.recipe_full(adata)

# Save the preprocessed AnnData object for downstream analysis
adata.write('/mnt/data00/share_data/results/autogen/gpt-4.1/scdemon/agent_output/pbmc3k_prep_scdemon.h5ad')


# Step 3: Compute co-expression modules using scdemon

import scanpy as sc
import scdemon

# Load the preprocessed data
adata = sc.read('/mnt/data00/share_data/results/autogen/gpt-4.1/scdemon/agent_output/pbmc3k_prep_scdemon.h5ad')

# Initialize scdemon modules object
# Biological note: k=100 is a common default for SVD components, filter_expr=0.05 removes lowly expressed genes
mod = scdemon.modules(adata, suffix="pbmc3k", k=100, filter_expr=0.05)

# Setup the module object (filters genes, computes SVD/PCA, etc.)
mod.setup()

# Create the gene-gene co-expression graph and perform Leiden clustering to define modules
# Biological note: 'bivariate' method is robust for single-cell data, resolution=1.0 is a standard clustering resolution
mod.make_graph("main_graph", method="bivariate", resolution=1.0)

# Extract modules as a dictionary (module_id: list of genes)
modules_dict = mod.get_modules("main_graph", print_modules=False)

# Save module assignments as a DataFrame (gene-to-module mapping)
assignments_df = mod.get_module_assignment("main_graph")
assignments_df.to_csv('/mnt/data00/share_data/results/autogen/gpt-4.1/scdemon/agent_output/pbmc3k_gene_module_assignments.tsv', sep='\t')

# Save the full module list (one file per module, or as a DataFrame)
mod.save_modules("main_graph", filedir='/mnt/data00/share_data/results/autogen/gpt-4.1/scdemon/agent_output/', as_df=True)

# Save a summary of the number of modules and genes per module
summary = assignments_df['leiden'].value_counts().sort_index()
summary.to_csv('/mnt/data00/share_data/results/autogen/gpt-4.1/scdemon/agent_output/pbmc3k_module_summary.tsv', sep='\t')

# Optionally, save the modules_dict as a pickle for downstream use
import pickle
with open('/mnt/data00/share_data/results/autogen/gpt-4.1/scdemon/agent_output/pbmc3k_modules_dict.pkl', 'wb') as f:
    pickle.dump(modules_dict, f)


# Correction: The column name in the assignments DataFrame may not be 'leiden'.
# Let's inspect the columns and use the correct one for module assignment.
# We'll also add a print statement to save the column names for debugging.

import scanpy as sc
import scdemon

# Load the preprocessed data
adata = sc.read('/mnt/data00/share_data/results/autogen/gpt-4.1/scdemon/agent_output/pbmc3k_prep_scdemon.h5ad')

# Initialize and setup modules as before
mod = scdemon.modules(adata, suffix="pbmc3k", k=100, filter_expr=0.05)
mod.setup()
mod.make_graph("main_graph", method="bivariate", resolution=1.0)

# Get module assignments DataFrame
assignments_df = mod.get_module_assignment("main_graph")
assignments_df.to_csv('/mnt/data00/share_data/results/autogen/gpt-4.1/scdemon/agent_output/pbmc3k_gene_module_assignments.tsv', sep='\t')

# Print and save the column names for debugging
with open('/mnt/data00/share_data/results/autogen/gpt-4.1/scdemon/agent_output/pbmc3k_assignment_columns.txt', 'w') as f:
    f.write(str(assignments_df.columns.tolist()))

# Use the first column for module assignment summary (usually the only column)
module_col = assignments_df.columns[0]
summary = assignments_df[module_col].value_counts().sort_index()
summary.to_csv('/mnt/data00/share_data/results/autogen/gpt-4.1/scdemon/agent_output/pbmc3k_module_summary.tsv', sep='\t')

# Save modules as before
mod.save_modules("main_graph", filedir='/mnt/data00/share_data/results/autogen/gpt-4.1/scdemon/agent_output/', as_df=True)

# Optionally, save the modules_dict as a pickle for downstream use
import pickle
modules_dict = mod.get_modules("main_graph", print_modules=False)
with open('/mnt/data00/share_data/results/autogen/gpt-4.1/scdemon/agent_output/pbmc3k_modules_dict.pkl', 'wb') as f:
    pickle.dump(modules_dict, f)


# Step 5: Document and summarize the results for easy interpretation

import pandas as pd

output_dir = '/mnt/data00/share_data/results/autogen/gpt-4.1/scdemon/agent_output'

# Load the module summary and assignments
summary = pd.read_csv(f'{output_dir}/pbmc3k_module_summary.tsv', sep='\t', header=None)
assignments = pd.read_csv(f'{output_dir}/pbmc3k_gene_module_assignments.tsv', sep='\t', index_col=0)

# Prepare a summary text file
with open(f'{output_dir}/pbmc3k_module_summary.txt', 'w') as f:
    f.write("PBMC3K Co-expression Module Analysis (scdemon)\n")
    f.write("============================================\n\n")
    f.write("Output files:\n")
    f.write("- pbmc3k_gene_module_assignments.tsv: Gene-to-module assignments (tab-separated)\n")
    f.write("- pbmc3k_module_summary.tsv: Number of genes per module (tab-separated)\n")
    f.write("- pbmc3k_modules_dict.pkl: Python dictionary of modules (module_id: list of genes)\n")
    f.write("- pbmc3k_assignment_columns.txt: Column names of the assignment file (for reference)\n")
    f.write("- pbmc3k_module_summary.txt: This summary file\n\n")
    f.write("Key findings:\n")
    f.write(f"- Total modules detected: {summary.shape[0]}\n")
    f.write(f"- Total genes assigned: {assignments.shape[0]}\n\n")
    f.write("Number of genes per module:\n")
    for idx, row in summary.iterrows():
        f.write(f"  Module {row[0]}: {row[1]} genes\n")
    f.write("\n")
    f.write("Modules can be further analyzed for functional enrichment or marker gene overlap.\n")
    f.write("All files are organized in the output directory for downstream analysis.\n")
